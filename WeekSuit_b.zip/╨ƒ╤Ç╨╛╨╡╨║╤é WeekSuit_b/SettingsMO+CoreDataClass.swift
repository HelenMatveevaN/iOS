//
//  SettingsMO+CoreDataClass.swift
//  WeekSuit_b
//
//  Created by Helen Matveeva on 01.06.17.
//  Copyright © 2017 Helen Matveeva. All rights reserved.
//

import Foundation
import CoreData

@objc(SettingsMO)
public class SettingsMO: NSManagedObject {
    convenience init() {
        self.init(entity: CoreDataManager.instance.entityForName(entityName: "Settings"), insertInto: CoreDataManager.instance.managedObjectContext)
    }
}
