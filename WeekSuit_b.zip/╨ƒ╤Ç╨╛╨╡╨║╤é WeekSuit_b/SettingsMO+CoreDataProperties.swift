//
//  SettingsMO+CoreDataProperties.swift
//  WeekSuit_b
//
//  Created by Helen Matveeva on 23.06.17.
//  Copyright © 2017 Helen Matveeva. All rights reserved.
//

import Foundation
import CoreData


extension SettingsMO {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<SettingsMO> {
        return NSFetchRequest<SettingsMO>(entityName: "Settings")
    }

    @NSManaged public var cityName: String?
    @NSManaged public var maxTemp: Int16
    @NSManaged public var minTemp: Int16
    @NSManaged public var photoArhMode: String?
    @NSManaged public var recommMode: String?
    @NSManaged public var sex: String?
    @NSManaged public var weekDayChoosed: Int16

}
