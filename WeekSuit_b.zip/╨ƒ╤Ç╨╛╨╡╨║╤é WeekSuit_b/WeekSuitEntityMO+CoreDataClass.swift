//
//  WeekSuitEntityMO+CoreDataClass.swift
//  WeekSuit_b
//
//  Created by Helen Matveeva on 16.05.17.
//  Copyright © 2017 Helen Matveeva. All rights reserved.
//

import Foundation
import CoreData

@objc(WeekSuitEntityMO)
public class WeekSuitEntityMO: NSManagedObject {
    convenience init() {
        self.init(entity: CoreDataManager.instance.entityForName(entityName: "WeekSuitEntity"), insertInto: CoreDataManager.instance.managedObjectContext)
    }
}
