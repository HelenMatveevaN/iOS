//
//  WeekSuitEntityMO+CoreDataProperties.swift
//  WeekSuit_b
//
//  Created by iMac on 16.06.17.
//  Copyright © 2017 Helen Matveeva. All rights reserved.
//

import Foundation
import CoreData


extension WeekSuitEntityMO {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<WeekSuitEntityMO> {
        return NSFetchRequest<WeekSuitEntityMO>(entityName: "WeekSuitEntity")
    }

    @NSManaged public var dt: NSDate?
    @NSManaged public var forecastFullStr: String?
    @NSManaged public var forecastIconStr: String?
    @NSManaged public var forecastShortStr: String?
    @NSManaged public var photo: NSData?
    @NSManaged public var descr: String?

}
