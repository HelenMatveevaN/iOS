<?php
    //http://helenmatveeva.000webhostapp.com/api.php?param=category.sex.tempmin.tempmax
    $mysqli = new mysqli("localhost", "id1391386_helenmatveeva", "ktyjxtr031981", "id1391386_suitsdb");
    
     if ($mysqli->connect_errno) {
        echo "MySQL connection is wrong: (" . $mysqli->connect_errno . ") " . $mysqli->connect_error;
    }
    //echo $mysqli->host_info . "\n";

    //get in-paremeters
    $p = $_GET['param']; 
    $params = explode('.', $p);

    //my_sqlis_load_photo_from_photo_arh
   /*http://helenmatveeva.000webhostapp.com/api_suits.php?param='F'.'OFFICE'.2.2
	$params[0]  - sex
	$params[1]  - id_category (include 'ALL')
	$params[2] - tempmin
	$params[3] - tempmax
	*/
    $res0 = $mysqli->query("SELECT count(*) as cnt FROM Suits WHERE tempmin <= tempmax AND sex = $params[0] AND (id_category = $params[1] AND $params[1] != 'ALL' OR $params[1] = 'ALL') AND tempmin <= $params[3] AND tempmax  >= $params[2]");
    $cntAll = 0;
    while ($row0 = $res0->fetch_assoc()) {
      $cntAll = $row0['cnt'];
    }
    $rownum = 1; //счетчик: обрабатывается 1я запись
    $res = $mysqli->query("SELECT id_category, sex, pic_url, tempmin, tempmax FROM Suits WHERE tempmin <= tempmax AND sex = $params[0] AND (id_category = $params[1] AND $params[1] != 'ALL' OR $params[1] = 'ALL') AND tempmin   <= $params[3] AND tempmax  >= $params[2]");
    echo '{"list":[';	
    while ($row = $res->fetch_assoc()) {
        $strzap = ",";
        if ($rownum ==  $cntAll) $strzap = "";
        echo json_encode($row) . $strzap;
        $rownum = $rownum + 1; //переключаем счетчик
    }
    echo "]}";
?>
