<?php
    //http://helenmatveeva.000webhostapp.com/api.php?param=category.sex.tempmin.tempmax
    $mysqli = new mysqli("localhost", "id1391386_helenmatveeva", "ktyjxtr031981", "id1391386_suitsdb");
    
     if ($mysqli->connect_errno) {
        echo "MySQL-connection is wrong: (" . $mysqli->connect_errno . ") " . $mysqli->connect_error;
    }
    //echo $mysqli->host_info . "\n";

    //get in-parameters
    $p = $_GET['param']; 
    $params = explode('.', $p);

    //my_sql
   /*http://helenmatveeva.000webhostapp.com/api_categ.php
	*/
    $res0 = $mysqli->query("SELECT count(*) as cnt FROM Category");
    $cntAll = 0;
    while ($row0 = $res0->fetch_assoc()) {
      $cntAll = $row0['cnt'];
    }
    $rownum = 1; //обрабатывается 1я запись
    $res = $mysqli->query("SELECT id, name, name_eng FROM Category");
    echo '{"list":[';
    while ($row = $res->fetch_assoc()) {
        $strzap = ",";
        if ($rownum ==  $cntAll) $strzap = "";
        echo json_encode($row) . $strzap;
        $rownum = $rownum + 1;
    }
    echo "]}";
?>
