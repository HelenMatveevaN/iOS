//
//  VC_PhotoArh.swift
//  WeekSuit_b
//
//  Created by Helen Matveeva on 08.05.17.
//  Copyright © 2017 Helen Matveeva. All rights reserved.
// В окне collection view получает фото из фото-альбома
//

import UIKit
import Photos
import CoreData

class VC_PhotoArh: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    var dayWeatherStr = ""
    let modeDflt = "DEFAULT"
    let modeChoose = "CHOOSE"
    var photoArhMode = "DEFAULT"
    // DEFAULT / CHOOSE - возможны 2 режима работы
    //DEFAULT - просмотр по умолчанию (кнопка "Назад" - видна)
    //CHOOSE  - просмотр в режиме "Выбор" (после выбора фото - автоматический возврат в главное окно)
    //в обоих режимах выбор фото должен сигнализироваться дополнительной подсветкой
    
    var isWeekDaySet = 0 //выбран день недели
    var _weekMinTemp = -99 //взять из БД
    var _weekMaxTemp =  99 //взять из БД

    let albumTitle = "WeekSuit" //название альбома с фотоархивом
    
    let fontSize28 = UIFont(name: "Helvetica", size: CGFloat(28))
    let fontSize20 = UIFont(name: "Helvetica", size: CGFloat(20))
    let fontSize18 = UIFont(name: "Helvetica", size: CGFloat(18))
    
    @IBOutlet weak var BackBtn: UIButton!
    @IBOutlet weak var PhotoArhiveLbl: UILabel!
    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var DayWeatherStrLabel: UILabel!
    var imageArray = [UIImage]()
    
    var arrDatesWeatherStr      =  ["","","","","","",""] //объявление+инициализация
    var cntPhotos = 0
    
    var is_iPad = "N"
    var CV_wdth = 0
    var CV_hght = 0
    var cellSize = CGSize()
    var layout = UICollectionViewFlowLayout()
    let emptyPic = #imageLiteral(resourceName: "emptyIcon.png")
    
    //до загрузки вью
    override func viewWillAppear(_ animated: Bool) {
        
        self.loadFromCoreData()//загрузка данных из CoreData (в т.ч. заполним массив погоды-дат на 7 дней (из БД))
        
        //iPhone or iPad?
        is_iPad = self.getIsIPad()
        
        if is_iPad == "Y" {
            CV_wdth = 350
            CV_hght = 350
        } else {
            CV_wdth = 250
            CV_hght = 250
        }
        
        cellSize = CGSize(width:self.CV_wdth , height:self.CV_hght)
        layout.scrollDirection = .vertical //.horizontal
        layout.itemSize = cellSize
        layout.sectionInset = UIEdgeInsets(top: 1, left: 1, bottom: 1, right: 1)
        layout.minimumLineSpacing = 1.0
        layout.minimumInteritemSpacing = 1.0
        self.collectionView.setCollectionViewLayout(layout, animated: true)
        self.DayWeatherStrLabel.text = self.dayWeatherStr
    }
    
    //после загрузки вью
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //обязательно для CollectionView in ViewController
        collectionView.delegate = self
        collectionView.dataSource = self
        
        //add - распознавание жестов
        self.collectionView.addGestureRecognizer(UILongPressGestureRecognizer(target: self, action: #selector(longPress)))
        
        self.imageArray.removeAll()
        
        DispatchQueue.global(qos: .userInitiated).async {
            self.grabPhotos()
            // Bounce back to the main thread to update the UI
            DispatchQueue.main.async {
                self.collectionView.reloadData()
            }
        }
    }
    
    //выставить шрифты в зависимости от типа устройства ----------------------------------------------------------
    func setFontInterface(isPad: String){
        if isPad == "Y" {
            self.PhotoArhiveLbl.font = fontSize28
            self.BackBtn.titleLabel?.font =  fontSize20
            self.DayWeatherStrLabel.font = fontSize18
        }
    }
    
    //определить тип устройства - iPad или iPhone?
    func getIsIPad() -> String {
        //iPhone or iPad?
        is_iPad = "N"
        let deviceIdiom = UIScreen.main.traitCollection.userInterfaceIdiom
        switch (deviceIdiom) {
        case .pad: is_iPad = "Y"
        default:   is_iPad = "N" }
        self.setFontInterface(isPad: is_iPad)
        return is_iPad
    }
    
    //получить данные из фото-альбома (альбом создается в VC_Main.swift
    func grabPhotos() {

        let assets = self.getAssetsFromAlbum(albumName: albumTitle)
        
        if assets.count > 0 {
            for photoNum in (0...assets.count-1){
                let options1 = PHImageRequestOptions()
                options1.isSynchronous = true
                PHCachingImageManager().requestImage(
                    for: assets[photoNum],
                    targetSize: cellSize ,
                    contentMode: .aspectFit,
                    options: options1,
                    resultHandler: { (image, info) in
                        if (image == nil) {
                            print("Error loading image")
                            print("\(String(describing: info))")
                        } else {
                            self.imageArray.append(image!)
                        }
                })
            }
        }
        
    }//func grabPhotos()
    
    //получить фото из папки приложения
    func getAssetsFromAlbum(albumName: String) -> [PHAsset] {
        
        let options = PHFetchOptions()
        // Bug from Apple since 9.1, use workaround
        //options.predicate = NSPredicate(format: "title = %@", albumName)
        options.sortDescriptors = [ NSSortDescriptor(key: "creationDate", ascending: true) ]
        
        let collection: PHFetchResult = PHAssetCollection.fetchAssetCollections(with: .album, subtype: .any, options: nil)
        
        for k in 0 ..< collection.count {
            let obj:AnyObject! = collection.object(at: k)
            if obj.title == albumName {
                if let assCollection = obj as? PHAssetCollection {
                    let results = PHAsset.fetchAssets(in: assCollection, options: options)
                    var assets = [PHAsset]()
                    
                    results.enumerateObjects(using: { (obj, index, stop) in
                        
                        //if 
                        let asset = obj
                        //{
                        assets.append(asset)
                        //}
                    })
                    
                    return assets
                }
            }
        }
        return [PHAsset]()
    }
    
    //обработка жеста long press на фото в CollectionView
    func longPress(sender: UIPinchGestureRecognizer){
        if (sender.state == UIGestureRecognizerState.ended) {
            if photoArhMode == modeDflt {
                if let indexPath = self.collectionView?.indexPathForItem(at: sender.location(in: self.collectionView)) {
                    
                    let alertController = UIAlertController(
                        title: nil,
                        message: NSLocalizedString("Select day of the week", comment: "Выберите день недели")
                        , preferredStyle: .actionSheet)
                    
                    //Кнопки дней недели - устанавливаем фото в соответствующий день недели
                    let photoIdxPathRow = indexPath.row; var dayOfWeek = 0
                    let dayWeek1 = UIAlertAction(title: self.arrDatesWeatherStr[0], style: .default){(action) in dayOfWeek = 0
                        self.setPhotoToWeekDay(dayWeek: dayOfWeek, protoRowNum: photoIdxPathRow)  }
                    let dayWeek2 = UIAlertAction(title: self.arrDatesWeatherStr[1], style: .default){(action) in dayOfWeek = 1
                        self.setPhotoToWeekDay(dayWeek: dayOfWeek, protoRowNum: photoIdxPathRow)  }
                    let dayWeek3 = UIAlertAction(title: self.arrDatesWeatherStr[2], style: .default){(action) in dayOfWeek = 2
                        self.setPhotoToWeekDay(dayWeek: dayOfWeek, protoRowNum: photoIdxPathRow)  }
                    let dayWeek4 = UIAlertAction(title: self.arrDatesWeatherStr[3], style: .default){(action) in dayOfWeek = 3
                        self.setPhotoToWeekDay(dayWeek: dayOfWeek, protoRowNum: photoIdxPathRow)  }
                    let dayWeek5 = UIAlertAction(title: self.arrDatesWeatherStr[4], style: .default){(action) in dayOfWeek = 4
                        self.setPhotoToWeekDay(dayWeek: dayOfWeek, protoRowNum: photoIdxPathRow)  }
                    let dayWeek6 = UIAlertAction(title: self.arrDatesWeatherStr[5], style: .default){(action) in dayOfWeek = 5
                        self.setPhotoToWeekDay(dayWeek: dayOfWeek, protoRowNum: photoIdxPathRow)  }
                    let dayWeek7 = UIAlertAction(title: self.arrDatesWeatherStr[6], style: .default){(action) in dayOfWeek = 6
                        self.setPhotoToWeekDay(dayWeek: dayOfWeek, protoRowNum: photoIdxPathRow)  }
                    
                    //Кнопка "отмена"
                    let cancelAction = UIAlertAction(title: NSLocalizedString("Cancel",comment: "cancel button"), style: .cancel){(action) in}
                    
                    alertController.addAction(dayWeek1);alertController.addAction(dayWeek2);alertController.addAction(dayWeek3);alertController.addAction(dayWeek4);alertController.addAction(dayWeek5);alertController.addAction(dayWeek6);alertController.addAction(dayWeek7);alertController.addAction(cancelAction)
                    
                    if self.is_iPad == "Y" {
                        if let popoverPresentationController = alertController.popoverPresentationController {
                            popoverPresentationController.sourceView = self.view}
                    }
                    
                    //отобразим все кнопки в меню
                    self.present(alertController, animated: true, completion: nil)
                }
                else {
                    //print("collection view was tapped")
                    //клик внутри collection view (не на фото) не обрабатываем
                }
            }//if photoArhMode == modeDflt
            if photoArhMode == modeChoose {
                if let indexPath = self.collectionView?.indexPathForItem(at: sender.location(in: self.collectionView)) {
                    
                    //сообщение
                    let alertController = UIAlertController(title: nil, message: NSLocalizedString("photo selected", comment: "фото выбрано alert"), preferredStyle: .actionSheet)
                    
                    let dayOfWeek = self.isWeekDaySet;let photoIdxPathRow = indexPath.row
                    let okAction = UIAlertAction(title: "OK",style: .default){(action) in
                            //Кнопки дней недели - устанавливаем фото в соответствующий день недели
                            self.setPhotoToWeekDay(dayWeek: dayOfWeek, protoRowNum: photoIdxPathRow)
                            //автоматический возврат в главное окно
                            DispatchQueue.main.async(execute: {
                            self.performSegue(withIdentifier: "segueArhToMain", sender: self)})
                    }
                    
                    //Кнопка "отмена"
                    let cancelAction = UIAlertAction(title: NSLocalizedString("Cancel",     comment: "cancel button"), style: .cancel){(action) in}
                    
                    alertController.addAction(okAction);alertController.addAction(cancelAction)
                    if self.is_iPad == "Y" {
                        if let popoverPresentationController = alertController.popoverPresentationController {
                            popoverPresentationController.sourceView = self.view}
                    }
                    self.present(alertController, animated: true, completion: nil)
                }
                else {
                    //print("collection view was tapped")
                    //клик внутри collection view (не на фото) не обрабатываем
                }
            } //if photoArhMode == modeChoose
        }
    }

    
    //присвоим считанное из ячейки CV фото в качестве фото дня недели
    func setPhotoToWeekDay(dayWeek: Int, protoRowNum: Int){
        
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "WeekSuitEntity")
        do {
            let results = try CoreDataManager.instance.managedObjectContext.fetch(fetchRequest)
            var dayWee = 0
            for result in results as! [WeekSuitEntityMO] {
                if dayWee == dayWeek {
                    let data = UIImagePNGRepresentation(imageArray[protoRowNum]) as NSData?
                    result.photo = data
                }
                dayWee = dayWee + 1
            }
            CoreDataManager.instance.saveContext()
        } catch {
            print("error=\(error)")
        }
    }
    
    //получить информацию о днях недели + погоде
    func loadFromCoreData(){
        
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "WeekSuitEntity")
        do {
            let results = try CoreDataManager.instance.managedObjectContext.fetch(fetchRequest)
            var i = 0
            for result in results as! [WeekSuitEntityMO] {
                let dt = result.dt
                let dtStr = self.getDateString(dt! as Date)
                let weatherStr = result.forecastShortStr!
                let weatherIconStr = result.forecastIconStr!
                self.arrDatesWeatherStr[i] = "\(dtStr) \(weatherStr) \(weatherIconStr)"
                i = i+1
            }
        } catch {
            print("error=\(error)")
        }
        
        //входные параметры
        self._weekMinTemp = -99 //взять из БД
        self._weekMaxTemp =  99 //взять из БД
        
        let fetchRequestS = NSFetchRequest<NSFetchRequestResult>(entityName: "Settings")
        do {
            let resultsS = try CoreDataManager.instance.managedObjectContext.fetch(fetchRequestS)
            for result in resultsS as! [SettingsMO] {
                self.photoArhMode = result.photoArhMode!
                self.isWeekDaySet = Int(result.weekDayChoosed)
                self._weekMinTemp = Int(result.minTemp)
                self._weekMaxTemp = Int(result.maxTemp)
            }
        } catch {
            print("error=\(error)")
        }
        
        //Строка под заголовком "Рекомендации"
        dayWeatherStr = ""
        if photoArhMode == modeDflt && (_weekMaxTemp == 99) == false {dayWeatherStr = "ALL: \(_weekMinTemp)/\(_weekMaxTemp) ℃"}
        if photoArhMode == modeChoose {dayWeatherStr = "\(self.arrDatesWeatherStr[self.isWeekDaySet])"}

    }
    
    
    //--получить дату в формате
    func getDateString(_ date :Date) -> String {
        let formatter = DateFormatter()
        
        formatter.dateFormat = "dd.MM"
        let dateFormat = formatter.string(from: date)
        
        formatter.dateFormat = "EE"
        var dayFormat = formatter.string(from: date)
        
        if dayFormat == "Mon" {dayFormat = NSLocalizedString("Mon", comment: "Mon day") } //пн
        if dayFormat == "Tue" {dayFormat = NSLocalizedString("Tue", comment: "Tue day") } //вт
        if dayFormat == "Wed" {dayFormat = NSLocalizedString("Wed", comment: "Wed day") } //ср
        if dayFormat == "Thu" {dayFormat = NSLocalizedString("Thu", comment: "Thu day") } //cht
        if dayFormat == "Fri" {dayFormat = NSLocalizedString("Fri", comment: "Fri day") } //pt
        if dayFormat == "Sat" {dayFormat = NSLocalizedString("Sat", comment: "Sat day") } //sb
        if dayFormat == "Sun" {dayFormat = NSLocalizedString("Sun", comment: "Sun day") } //вс
        
        return dateFormat + " " + dayFormat
    }//func getDateString
    
    // MARK: UICollectionViewDataSource
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of items
        return imageArray.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CustomCell", for: indexPath) as! CustomCell
        cell.layer.borderWidth = 3
        cell.myImage.contentMode = UIViewContentMode.scaleAspectFit //фото во весь размер
        cell.myImage.image = self.imageArray[indexPath.row]

        //THIS IS VERY IMPORTANT
        cell.layer.shouldRasterize = true
        cell.layer.rasterizationScale = UIScreen.main.scale
        
        return cell
    }
    
}
