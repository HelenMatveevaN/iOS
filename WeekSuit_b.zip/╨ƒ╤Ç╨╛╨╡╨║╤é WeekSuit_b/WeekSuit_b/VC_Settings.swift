//
//  VC_Settings.swift
//  WeekSuit_b
//
//  Created by Helen Matveeva on 10.05.17.
//  Copyright © 2017 Helen Matveeva. All rights reserved.
//

import UIKit
import CoreData

class VC_Settings: UIViewController {

    var is_iPad = "Y"
    let fontSize28 = UIFont(name: "Helvetica", size: CGFloat(28))
    let fontSize20 = UIFont(name: "Helvetica", size: CGFloat(20))
    
    @IBOutlet weak var SettingsLbl: UILabel!
    @IBOutlet weak var BackBtn: UIButton!
    @IBOutlet weak var SwitchSex: UISwitch!
    @IBOutlet weak var SexLabel: UILabel!
    
    @IBAction func CheckSwitch(_ sender: UISwitch) {
        var sex = "F"
        if self.SwitchSex.isOn {sex = "F"}
        else                   {sex = "M"}
        
        //сохранение настроек
        let fetchRequest1 = NSFetchRequest<NSFetchRequestResult>(entityName: "Settings")
        do {
            let results = try CoreDataManager.instance.managedObjectContext.fetch(fetchRequest1)
            if results.count == 0 {
                let managedObject = SettingsMO()
                managedObject.sex = sex
            }
            else {
                for result in results as! [SettingsMO] {
                    result.sex = sex
                }
            }
            CoreDataManager.instance.saveContext()
        } catch {
            print("error=\(error)")
        }
        
    }
    //до загрузки вью
    override func viewWillAppear(_ animated: Bool) {
        //iPhone or iPad?
        is_iPad = self.getIsIPad()
        self.setFontInterface(isPad: is_iPad)
        
        //загружаем долговременные данные на экран
        setSwitchSex()
    }
    
    //выставить шрифты в зависимости от типа устройства ----------------------------------------------------------
    func setFontInterface(isPad: String){
        if isPad == "Y" {
            self.SettingsLbl.font = fontSize28
            self.BackBtn.titleLabel?.font =  fontSize20
            self.SexLabel.font = fontSize20
        }
    }
    
    //определить тип устройства - iPad или iPhone?
    func getIsIPad() -> String {
        //iPhone or iPad?
        is_iPad = "N"
        let deviceIdiom = UIScreen.main.traitCollection.userInterfaceIdiom
        switch (deviceIdiom) {
        case .pad: is_iPad = "Y"
        default:   is_iPad = "N" }
        self.setFontInterface(isPad: is_iPad)
        return is_iPad
    }
    
    func setSwitchSex(){
        //загрузка настроек
        let fetchRequest1 = NSFetchRequest<NSFetchRequestResult>(entityName: "Settings")
        do {
            let results = try CoreDataManager.instance.managedObjectContext.fetch(fetchRequest1)
            for result in results as! [SettingsMO] {
                if result.sex == "F" {self.SwitchSex.setOn(true, animated: false)}
                if result.sex == "M" {self.SwitchSex.setOn(false, animated: false)}
            }
        } catch {
            print("error=\(error)")
        }

        
    }

}
