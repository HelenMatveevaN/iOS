//
//  CustomRecommCell.swift
//  WeekSuit_b
//
//  Created by Helen Matveeva on 01.06.17.
//  Copyright © 2017 Helen Matveeva. All rights reserved.
//

import UIKit

class CustomRecommCell: UICollectionViewCell {
    @IBOutlet weak var ImageRecomm: UIImageView!
}
