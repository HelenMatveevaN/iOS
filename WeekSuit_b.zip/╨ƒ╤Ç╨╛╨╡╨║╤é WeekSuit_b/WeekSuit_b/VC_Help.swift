//
//  SecondViewController.swift
//  WeekSuit
//
//  Created by Helen Matveeva on 01.08.16.
//  Copyright © 2016 Helen Matveeva. All rights reserved.
//

import UIKit

class VC_Help: UIViewController {
    
    @IBOutlet weak var HelpTextView: UITextView!
    @IBOutlet weak var BackBtn: UIButton!
    @IBOutlet weak var HelpLabel: UILabel!
    
    var is_iPad = "Y"
    let fontSize28 = UIFont(name: "Helvetica", size: CGFloat(28))
    let fontSize20 = UIFont(name: "Helvetica", size: CGFloat(20))

    override func viewDidLoad() {
        //для того, чтобы скролл отображался вверху текста
        HelpTextView.isScrollEnabled = false
    }
    
    override func viewDidAppear(_ animated: Bool){
        //включаем скролл после загрузки textView
        HelpTextView.isScrollEnabled = true
    }
    
    //до загрузки вью
    override func viewWillAppear(_ animated: Bool) {
        //iPhone or iPad?
        is_iPad = self.getIsIPad()
        self.setFontInterface(isPad: is_iPad)
        self.setHelpText()
    }
    
    //выставить шрифты в зависимости от типа устройства ----------------------------------------------------------
    func setFontInterface(isPad: String){
        if isPad == "Y" {
            self.HelpLabel.font = fontSize28
            self.BackBtn.titleLabel?.font =  fontSize20
            self.HelpTextView.font = fontSize20
        }
    }
    
    //определить тип устройства - iPad или iPhone?
    func getIsIPad() -> String {
        //iPhone or iPad?
        is_iPad = "N"
        let deviceIdiom = UIScreen.main.traitCollection.userInterfaceIdiom
        switch (deviceIdiom) {
        case .pad: is_iPad = "Y"
        default:   is_iPad = "N" }
        self.setFontInterface(isPad: is_iPad)
        return is_iPad
    }
    
    func setHelpText(){
        self.HelpTextView.text = NSLocalizedString("Week Suits application - trainer for planning outfits for all 7 days of the week, based on weather forecast. Week Suits can become your trusty assistant for creating a contemporary wardrobe for the week.\n\n Planning outfits in advance, you can get rid of spontaneous (and not always appropriate) clothing combinations, save time, simplify morning work preparation, and prepare yourself for solemn or important activities. The app will help people who are experiencing difficulties selecting outfits.\n\nPlan your outfit for the week according to local weather forecast. If there are changes in the forecast, adjust accordingly.\n- Start new week or update weather forecast;\n- Create outfit list according to weather forecast (with text or photo);\n- Shape your outfit collection in “Photo-archive”;\n- Use “Recomendations” to get tips on contemporary outfits and good matches.\n***\n How to use the app \n1. Launch the app. Allow it to access your location, your photos (if you haven't already).\nWith first launch you will see a blank page with a title “Week Suits”. Here you need to create a new week.\n2. Press button “update data”, in the menu choose “Start a new week”.\nColorful boxes on top of the page will be filled with dates of 7 days, starting with tomorrow. If you have internet access, under the dates weather info will be shown. For example, 13/24 degrees Celsius, which indicates minimum/maximum temperature of that day.\n3. Now you can create a list of outfits for that week. 3.1 Click date for which you want to plan an outfit.\nOutfit for the day might contain text and photo.\n3.2 With keyboard, type name of an outfit in the field “Choose outfit name” (amount of symbols - unlimited)\nFor example: “to office: blue jeans; white shirt; blue sweater; black sneakers; umbrella.”\n3.3 Choose outfit photo, from “Recomendations” or “Photo-archive”. Or take a photo with a camera.\nTo do that click on page “Outfits of the week” 1 time on the image under outfit name and hold 1 second or longer. From appeared menu select “Photo-archive”, “Recommendations” or “Camera”.\na) Select “Camera”. Allow the app to access camera of your device. Take a photo and select “use photo” or “retake”. As a result photo will be memorised for a selected day and will automatically be saved in main album of your device (“Camera rool” or “Photo Stream”)\nb) Select “Photo-archive”. If archive is empty, go to album of your device, find automatically created album “WeekSuit” and place in it photos of outfits you see fit. After that, in Photo-archive of the app will be displayed photos from that album.\nIn order to select photos in photo-archive of WeekSuit(b), click the photo, holding 1 second ot longer. Press Ok in appeared menu. Weather information on top of the page with title “Photo-archive” will help you select a photo.\nAs the result the photo will be memorised for a selected day.\nc) Select “Recommendations”. With internet conncetion, photos will be loaded from outside source, according to selected gender and weather forecast for a selected day day. (It is possible to choose gender in “Settings”, by pressing button “Settings” on the bottom of the main page “Week Suits”.)\nIt is possible to select outfit category on top of the page In album “Recomendations”.\nFor example, “What to wear: on a date”. In order to do that, click the grey field on the top of the page “Recommendations” and select outfit category, press button “Done”.\nIn order to select photos on the page “Recommendations”, click the photo, holding for 1 second or longer. Press “Ok” in the appeared menu.\nWeather forecast information on the top of the page under the title “Photo’archive” will help you select a photo.\nAs a result a photo wll be memorised for selected day. 4. Repeat actions 3.1-3.3 for other dates of week.\n5. You can update weather forecast at any time. To do that, press “Update data” on the main page Week Suits, select “update weather forecast” in the menu. Weather forecast will update for today and future dates. If you found that weather forecast is significantly different from previous values, add/remove certain accessories from outfit names (for example: umbrella, scarf, glows e.t.c.) or replace outfit photo with a better fit.\nIf you found that the week for which you planned outfits has ended, start a new one. In order to do that press button “Update data”, select “start new week” in the menu. Correct list of outfits in accordance to 3.1-3.3.\n6. Photo-outfit for a week day can be selected in photo-archive or page of recommendations, proceeding to them using buttons “Photo-archive” or “Recommendations” at the bottom of the main page (“Week Suits”).\nIn order to select photo, click it, holding for 1 second or longer. Choose day of week in the appeared menu. Weather forecast information on the top of the page under the title “Photo’archive” will help you select a photo.\nAs the result the photo will be memorised for selected day of week. 7. Misc info\nPhoto-outfit recommendations update automatically according to weather forecast and trends.\nWeather Forecast Source: http://openweathermap.org", comment: "Help Text View") //здесь должна быть справка о том, как пользоваться программо1
    }
    
}
