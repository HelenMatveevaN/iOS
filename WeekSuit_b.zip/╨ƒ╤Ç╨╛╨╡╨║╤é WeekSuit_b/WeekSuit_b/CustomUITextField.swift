//
//  CustomUITextField.swift
//  WeekDish
//
//  Created by Helen Matveeva on 21.02.17.
//  Copyright © 2017 Helen Matveeva. All rights reserved.
//

import Foundation
import UIKit

class CustomUITextField: UITextField {

    /*
    // источник реализации решения: http://stackoverflow.com/questions/29596043/how-to-disable-pasting-in-a-textfield-in-swift
    }
    */
    
    open override func canPerformAction(_ action: Selector, withSender sender: Any?) -> Bool {
        if  action == #selector(UIResponderStandardEditActions.paste(_:)) ||
            action == #selector(UIResponderStandardEditActions.select(_:)) ||
            action == #selector(UIResponderStandardEditActions.selectAll(_:)) ||
            action == #selector(UIResponderStandardEditActions.copy(_:)) ||
            action == #selector(UIResponderStandardEditActions.cut(_:))
        {
            return false
        }
        return super.canPerformAction(action, withSender: sender)
    }

}
