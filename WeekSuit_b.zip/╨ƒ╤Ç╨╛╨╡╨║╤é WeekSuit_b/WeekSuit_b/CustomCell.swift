//
//  CustomCell.swift
//  WeekSuit_b
//
//  Created by Helen Matveeva on 22.05.17.
//  Copyright © 2017 Helen Matveeva. All rights reserved.
//

import UIKit

class CustomCell: UICollectionViewCell {
    @IBOutlet weak var myImage: UIImageView!
}
