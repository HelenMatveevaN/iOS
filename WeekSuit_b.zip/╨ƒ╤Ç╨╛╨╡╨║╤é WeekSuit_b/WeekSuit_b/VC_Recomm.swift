//
//  VC_Recomm.swift
//  WeekSuit_b
//
//  Created by iMac on 01.05.17.
//  Copyright © 2017 Helen Matveeva. All rights reserved.
//

import UIKit
import CoreData

class VC_Recomm: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource, UIPickerViewDelegate, UIPickerViewDataSource {
    
    var dayWeatherStr = ""
    let modeDflt = "DEFAULT"
    let modeChoose = "CHOOSE"
    var recommMode = "DEFAULT"
    // DEFAULT / CHOOSE - возможны 2 режима работы
    //DEFAULT - просмотр по умолчанию (кнопка "Назад" - видна)
    //CHOOSE  - просмотр в режиме "Выбор" (после выбора фото - автоматический возврат в главное окно)
    //в обоих режимах выбор фото должен сигнализироваться дополнительной подсветкой
    
    var isWeekDaySet = 0 //выбран день недели
    
    //объявляю picker категорий
    let categPickerView: UIPickerView = UIPickerView()
    var categPickerItemNum = 0
    var categCodeDefault = "ALL"
    
    var _sex = "" //взять из БД
    var _weekMinTemp = -99 //взять из БД
    var _weekMaxTemp =  99 //взять из БД
    var _categcod = "ALL"

    var is_iPad = "N"
    var CV_wdth = 0
    var CV_hght = 0
    var cellSize = CGSize()
    var layout = UICollectionViewFlowLayout()
    let emptyPic = #imageLiteral(resourceName: "emptyIcon.png")
    
    let fontSize28 = UIFont(name: "Helvetica", size: CGFloat(28))
    let fontSize20 = UIFont(name: "Helvetica", size: CGFloat(20))
    let fontSize18 = UIFont(name: "Helvetica", size: CGFloat(18))
    
    var arrCategoryCode = [String]() //пустой массив для скачивания справочника категорий костюмов (рекомендации)
    var arrCategoryName = [String]()
    var arrSuitsUrl     = [String]()
    var imageCache = [String:UIImage]()
    var arrDatesWeatherStr      =  ["","","","","","",""] //объявление+инициализация
    
    @IBOutlet weak var BackBtn: UIButton!
    @IBOutlet weak var RecommLabel: UILabel!
    @IBOutlet weak var CategNameTextFld: CustomUITextField! //расширенный спец.тип, в котором запрещены операции cut,copy,paste
    @IBOutlet weak var CollectionView: UICollectionView!
    @IBOutlet weak var DayWeatherStrLabel: UILabel!
    
    //до загрузки вью
    override func viewWillAppear(_ animated: Bool) {
        
        self.loadFromCoreData()//загрузка данных из CoreData (в т.ч. заполним массив погоды-дат на 7 дней (из БД))
       
        //iPhone or iPad?
        is_iPad = self.getIsIPad()
        
        if is_iPad == "Y" {
            CV_wdth = 350
            CV_hght = 350
        } else {
            CV_wdth = 250
            CV_hght = 250
        }
        
        //print(UIDevice.current.orientation)
        
        //параметры для ячеек CollectionView
        cellSize = CGSize(width:self.CV_wdth , height:self.CV_hght)
        layout.scrollDirection = .vertical //.horizontal
        layout.itemSize = cellSize
        layout.sectionInset = UIEdgeInsets(top: 2, left: 2, bottom: 2, right: 2)
        layout.minimumLineSpacing = 0
        layout.minimumInteritemSpacing = 0
        self.CollectionView.setCollectionViewLayout(layout, animated: true)
        self.DayWeatherStrLabel.text = self.dayWeatherStr
        //print("------------------------------------")
        //print(_sex)
        //print(_weekMaxTemp)
        //print(_weekMinTemp)
    }
    
    //после загрузки вью
    override func viewDidLoad() {
        
        super.viewDidLoad()
       
        self.createPicker()
        self.categPickerView.delegate = self
        self.categPickerView.dataSource = self
        CategNameTextFld.delegate = self as? UITextFieldDelegate
        
        self.CollectionView.delegate = self
        self.CollectionView.dataSource = self
        
        //add - распознавание жестов
        self.CollectionView.addGestureRecognizer(UILongPressGestureRecognizer(target: self, action: #selector(longPress)))
        
        //работа с API
        /*
        сайт разработчика: http://helen-matveeva.ucoz.net (на котором размещу фотки)
        сайт для api: helenmatveeva.000webhostapp.com
        php и mysql: https://ru.000webhost.com/members/website/list
        */
        
        DispatchQueue.global(qos: .userInitiated).async {
            self.arrCategoryCode.removeAll()
            self.arrCategoryName.removeAll()

            let allCategStr = NSLocalizedString("All categories", comment: "All categ string")
            self.arrCategoryCode.append(self.categCodeDefault)
            self.CategNameTextFld.text = allCategStr
            self.arrCategoryName.append(allCategStr)
            
            //загрузка категорий в программу (список категорий одинаков для муж/жен)
            var url = URL(string: "http://helenmatveeva.000webhostapp.com/api_categ.php")
            URLSession.shared.dataTask(with: url!) { (data, response, error) in
                
                if error != nil {
                    print(error as Any)
                    return
                }
                
                let json = try? JSONSerialization.jsonObject(with: data!, options: .mutableContainers)
                let appLangCode = Locale.current.languageCode! //en/ru - язык на устройстве в соотв-е с настройками
                
                //{} в фигурных скобках это dictionary:
                if let dictionary = json as? [String: Any] {
                    //[] в квадратных скобках эт о array:
                    if let arrList = dictionary["list"] as? [Any] {
                        for list in arrList { //считываю категории из api (справочника в mySql)
                            if let dictionaryList = list as? [String: Any] {
                                let _categCode = dictionaryList["id"] as! String
                                self.arrCategoryCode.append(_categCode)
                                //--
                                var _categName = ""
                                if appLangCode == "ru" {_categName = dictionaryList["name"] as! String}
                                if appLangCode == "en" {_categName = dictionaryList["name_eng"] as! String}
                                self.arrCategoryName.append(_categName)
                            }
                        }
                    }
                }
                }.resume()
            
            self.loadSettings() //загрузим из Settings инф-ю в self._sex, ...
            if self.categPickerItemNum <= 0
            { self._categcod = self.categCodeDefault}
            else
            { self._categcod = self.arrCategoryCode[self.categPickerItemNum] } //загрузка кода категории из picker-а

            
            print("---------------------------------")
            print(self._sex)
            print(self._weekMinTemp)
            print(self._weekMaxTemp)
            print(self._categcod)
            
            //загрузка url фото костюмов в программу
            url = URL(string: "http://helenmatveeva.000webhostapp.com/api_suits.php?param='\(self._sex)'.'\(self._categcod)'.\(self._weekMinTemp).\(self._weekMaxTemp)")
            URLSession.shared.dataTask(with: url!) { (data, response, error) in
                
                if error != nil {
                    print(error as Any)
                    return
                }
                
                let json = try? JSONSerialization.jsonObject(with: data!, options: .mutableContainers)
                
                //{} в фигурных скобках это dictionary:
                if let dictionary = json as? [String: Any] {
                    //[] в квадратных скобках эт о array:
                    if let arrList = dictionary["list"] as? [Any] {
                        for list in arrList { //считываю категории из api (справочника в mySql)
                            if let dictionaryList = list as? [String: Any] {
                                let _picUrl = dictionaryList["pic_url"] as! String
                                self.arrSuitsUrl.append(_picUrl)
                            }
                        }
                    }
                }
                
                // Bounce back to the main thread to update the UI
                DispatchQueue.main.async {
                    self.CollectionView.reloadData()
                }
                }.resume()
        }
        
    }
    
    //получить информацию о днях недели + погоде
    func loadFromCoreData(){
        
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "WeekSuitEntity")
        do {
            let results = try CoreDataManager.instance.managedObjectContext.fetch(fetchRequest)
            var i = 0
            for result in results as! [WeekSuitEntityMO] {
                let dt = result.dt! as Date
                let dtStr = self.getDateString(dt)
                let weatherStr = result.forecastShortStr!
                let weatherIconStr = result.forecastIconStr!
                self.arrDatesWeatherStr[i] = "\(dtStr) \(weatherStr) \(weatherIconStr)"
                i = i+1
            }
        } catch {
            print("error=\(error)")
        }
        
        //входные параметры
        //self._sex = "F" //взять из БД
        //self._weekMinTemp = -99 //взять из БД
        //self._weekMaxTemp =  99 //взять из БД
        //self._categcod = self.categCodeDefault
        
        let fetchRequestS = NSFetchRequest<NSFetchRequestResult>(entityName: "Settings")
        do {
            let resultsS = try CoreDataManager.instance.managedObjectContext.fetch(fetchRequestS)
            for result in resultsS as! [SettingsMO] {
                _sex = result.sex!
                print("============================")
                print(_sex)
                _weekMinTemp = Int(result.minTemp)
                _weekMaxTemp = Int(result.maxTemp)
                self.recommMode = result.recommMode!
                self.isWeekDaySet = Int(result.weekDayChoosed)
            }
        } catch {
            print("error=\(error)")
        }
        
        //Строка под заголовком "Рекомендации"
        dayWeatherStr = ""
        let allStr = NSLocalizedString("ALL: ", comment: "All string")
        if recommMode == modeDflt && (_weekMaxTemp == 99) == false {dayWeatherStr = "\(allStr) \(_weekMinTemp)/\(_weekMaxTemp) ℃"}
        if recommMode == modeChoose {dayWeatherStr = "\(self.arrDatesWeatherStr[self.isWeekDaySet])"}
    }
    
    func loadSettings() {
        
        let fetchRequestS = NSFetchRequest<NSFetchRequestResult>(entityName: "Settings")
        do {
            let resultsS = try CoreDataManager.instance.managedObjectContext.fetch(fetchRequestS)
            for result in resultsS as! [SettingsMO] {
                _sex = result.sex!
                _weekMinTemp = Int(result.minTemp)
                _weekMaxTemp = Int(result.maxTemp)
                self.recommMode = result.recommMode!
                self.isWeekDaySet = Int(result.weekDayChoosed)
                
            }
        } catch {
            print("error=\(error)")
        }
    }
    
    //изменить размер фото
    func resizeImage(image: UIImage, _newWidth: CGFloat) -> UIImage {
        
        var scale = _newWidth / image.size.width
        var newHeight = image.size.height * scale
        var newWidth = _newWidth
        
        if image.size.height > image.size.width {
            newHeight = newWidth
            scale = newHeight / image.size.height
            newWidth = image.size.width * scale
        }
        
        UIGraphicsBeginImageContext(CGSize(width: newWidth, height: newHeight))
        image.draw(in: CGRect(x: 0, y: 0, width: newWidth, height: newHeight))
        let newImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        
        return newImage!
    }


    //выставить шрифты в зависимости от типа устройства ----------------------------------------------------------
    func setFontInterface(isPad: String){
        if isPad == "Y" {
            self.RecommLabel.font = fontSize28
            self.BackBtn.titleLabel?.font =  fontSize20
            self.CategNameTextFld.font = fontSize20
            self.DayWeatherStrLabel.font = fontSize18
        }
    }
    
    //определить тип устройства - iPad или iPhone?
    func getIsIPad() -> String {
        //iPhone or iPad?
        is_iPad = "N"
        let deviceIdiom = UIScreen.main.traitCollection.userInterfaceIdiom
        switch (deviceIdiom) {
        case .pad: is_iPad = "Y"
        default:   is_iPad = "N" }
        self.setFontInterface(isPad: is_iPad)
        
        return is_iPad
    }
    
    //создать picker-ы для ...
    func createPicker() {
        //toolbarCateg
        let toolbarCateg = UIToolbar()
        toolbarCateg.sizeToFit()
        
        //что произойдет при нажатии на кнопку Done
        let doneButtonCateg = UIBarButtonItem(barButtonSystemItem: .done, target: nil, action: #selector(pickerCategDonePressed))
        toolbarCateg.setItems([doneButtonCateg], animated: false)
        CategNameTextFld.inputAccessoryView = toolbarCateg
        CategNameTextFld.inputView = categPickerView
    }

    //кнопка "Done" на picker-e категорий
    func pickerCategDonePressed() {
        //здесь нужно вызвать процедуру вызова блока рекомендаций (api)
        DispatchQueue.global(qos: .userInitiated).async {
            self.arrSuitsUrl.removeAll()
            self.imageCache.removeAll()
            
            //входные параметры
            self.loadSettings()
            
            print("-------------------")
            print(self._weekMinTemp)
            print(self._weekMaxTemp)
            print(self._categcod)
            print(self._sex)
            
            //загрузка url фото костюмов в программу
            let url = URL(string: "http://helenmatveeva.000webhostapp.com/api_suits.php?param='\(self._sex)'.'\(self._categcod)'.\(self._weekMinTemp).\(self._weekMaxTemp)")
            URLSession.shared.dataTask(with: url!) { (data, response, error) in
                
                if error != nil {
                    print(error as Any)
                    return
                }
                
                let json = try? JSONSerialization.jsonObject(with: data!, options: .mutableContainers)
                
                //{} в фигурных скобках это dictionary:
                if let dictionary = json as? [String: Any] {
                    //[] в квадратных скобках эт о array:
                    if let arrList = dictionary["list"] as? [Any] {
                        for list in arrList { //считываю категории из api (справочника в mySql)
                            if let dictionaryList = list as? [String: Any] {
                                let _picUrl = dictionaryList["pic_url"] as! String
                                self.arrSuitsUrl.append(_picUrl)
                            }
                        }
                    }
                }
               
                // Bounce back to the main thread to update the UI
                DispatchQueue.main.async {
                    self.CollectionView.reloadData()
                    self.view.endEditing(true) //убираем клавиатуру
                }
                }.resume()
        }
    }
    //------------------------------------------------------------------------
    //присвоим считанное из ячейки CV фото в качестве фото дня недели
    func setPhotoToWeekDay(dayWeek: Int, protoRowNum: Int){
        
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "WeekSuitEntity")
        do {
            let results = try CoreDataManager.instance.managedObjectContext.fetch(fetchRequest)
            var dayWee = 0
            for result in results as! [WeekSuitEntityMO] {
                if dayWee == dayWeek {
                    let url = arrSuitsUrl[protoRowNum]
                    let data = UIImagePNGRepresentation(imageCache[url]!) as NSData?
                    result.photo = data
                }
                dayWee = dayWee + 1
            }
            CoreDataManager.instance.saveContext()
        } catch {
            print("error=\(error)")
        }
    }
    
    //--получить дату в формате
    public func getDateString(_ date :Date) -> String {
        let formatter = DateFormatter()
        
        formatter.dateFormat = "dd.MM"
        let dateFormat = formatter.string(from: date)
        
        formatter.dateFormat = "EE"
        var dayFormat = formatter.string(from: date)
        
        if dayFormat == "Mon" {dayFormat = NSLocalizedString("Mon", comment: "Mon day") } //пн
        if dayFormat == "Tue" {dayFormat = NSLocalizedString("Tue", comment: "Tue day") } //вт
        if dayFormat == "Wed" {dayFormat = NSLocalizedString("Wed", comment: "Wed day") } //ср
        if dayFormat == "Thu" {dayFormat = NSLocalizedString("Thu", comment: "Thu day") } //cht
        if dayFormat == "Fri" {dayFormat = NSLocalizedString("Fri", comment: "Fri day") } //pt
        if dayFormat == "Sat" {dayFormat = NSLocalizedString("Sat", comment: "Sat day") } //sb
        if dayFormat == "Sun" {dayFormat = NSLocalizedString("Sun", comment: "Sun day") } //вс
        
        return dateFormat + " " + dayFormat
    }//func getDateString
    
    //--------------------------------
    func closeKeyboard() {
        self.view.endEditing(true) //убираем клавиатуру
    }
    
    // MARK: UICollectionViewDataSource
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of items
        return arrSuitsUrl.count
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: CGFloat((collectionView.frame.size.width / 3) - 20), height: CGFloat(100))
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "RecommCell", for: indexPath) as! CustomRecommCell
        
        cell.layer.borderWidth = 3
        cell.ImageRecomm?.image = self.emptyPic
        
        let urlString = self.arrSuitsUrl[indexPath.row]
        
        if let img = imageCache[urlString] {
            cell.ImageRecomm.image = img
        }
        else {
            let url = URL(string: urlString)
            let session = URLSession.shared
            
            let task = session.dataTask(with: url!, completionHandler: {
                data,_,_ in
                // Convert the downloaded data in to a UIImage object
                let image = UIImage(data: data!)
                // Store the image in to our cache
                if image == nil {}
                else {
                    self.imageCache[urlString] = self.resizeImage(image: image!, _newWidth: 600)
                    // Update the cell
                    DispatchQueue.main.async(execute: {
                        if self.CollectionView.cellForItem(at: indexPath) != nil {
                            cell.ImageRecomm.contentMode = UIViewContentMode.scaleAspectFit //фото во весь размер
                            cell.ImageRecomm.image = image
                        }
                    })
                }
            })
            task.resume()
        }
        
        //THIS IS VERY IMPORTANT
        cell.layer.shouldRasterize = true
        cell.layer.rasterizationScale = UIScreen.main.scale
        
        return cell
    }

    //обработка жеста long press на фото в CollectionView
    func longPress(sender: UIPinchGestureRecognizer){
        if (sender.state == UIGestureRecognizerState.ended) {
            if recommMode == modeDflt {           
                if let indexPath = self.CollectionView?.indexPathForItem(at: sender.location(in: self.CollectionView)) {
                    let alertController = UIAlertController(title: nil,message: NSLocalizedString("Select day of the week", comment: "Выберите день недели"), preferredStyle: .actionSheet)
                    //Кнопки дней недели - устанавливаем фото в соответствующий день недели
                    let photoIdxPathRow = indexPath.row
                    var dayOfWeek = 0
                    let dayWeek1 = UIAlertAction(title: self.arrDatesWeatherStr[0], style: .default){(action) in dayOfWeek = 0
                        self.setPhotoToWeekDay(dayWeek: dayOfWeek, protoRowNum: photoIdxPathRow)  }
                    let dayWeek2 = UIAlertAction(title: self.arrDatesWeatherStr[1], style: .default){(action) in dayOfWeek = 1
                        self.setPhotoToWeekDay(dayWeek: dayOfWeek, protoRowNum: photoIdxPathRow)  }
                    let dayWeek3 = UIAlertAction(title: self.arrDatesWeatherStr[2], style: .default){(action) in dayOfWeek = 2
                        self.setPhotoToWeekDay(dayWeek: dayOfWeek, protoRowNum: photoIdxPathRow)  }
                    let dayWeek4 = UIAlertAction(title: self.arrDatesWeatherStr[3], style: .default){(action) in dayOfWeek = 3
                        self.setPhotoToWeekDay(dayWeek: dayOfWeek, protoRowNum: photoIdxPathRow)  }
                    let dayWeek5 = UIAlertAction(title: self.arrDatesWeatherStr[4], style: .default){(action) in dayOfWeek = 4
                        self.setPhotoToWeekDay(dayWeek: dayOfWeek, protoRowNum: photoIdxPathRow)  }
                    let dayWeek6 = UIAlertAction(title: self.arrDatesWeatherStr[5], style: .default){(action) in dayOfWeek = 5
                        self.setPhotoToWeekDay(dayWeek: dayOfWeek, protoRowNum: photoIdxPathRow)  }
                    let dayWeek7 = UIAlertAction(title: self.arrDatesWeatherStr[6], style: .default){(action) in dayOfWeek = 6
                        self.setPhotoToWeekDay(dayWeek: dayOfWeek, protoRowNum: photoIdxPathRow)  }
                    
                    //Кнопка "отмена"
                    let cancelAction = UIAlertAction(title: NSLocalizedString("Cancel",     comment: "cancel button"), style: .cancel){(action) in}
                    
                    alertController.addAction(dayWeek1);alertController.addAction(dayWeek2);alertController.addAction(dayWeek3);alertController.addAction(dayWeek4);alertController.addAction(dayWeek5);alertController.addAction(dayWeek6);alertController.addAction(dayWeek7);alertController.addAction(cancelAction)
                    
                    if self.is_iPad == "Y" {
                        if let popoverPresentationController = alertController.popoverPresentationController {
                            popoverPresentationController.sourceView = self.view}
                    }
                    
                    //отобразим все кнопки в меню
                    self.present(alertController, animated: true, completion: nil)
                    
                }
                else {
                    //print("collection view was tapped")
                    //клик внутри collection view (не на фото) не обрабатываем
                }
            } //if recommMode == modeDflt
            if recommMode == modeChoose {
                if let indexPath = self.CollectionView?.indexPathForItem(at: sender.location(in: self.CollectionView)) {
                    //сообщение
                    let alertController = UIAlertController(title: nil, message: NSLocalizedString("photo selected", comment: "фото выбрано alert"), preferredStyle: .actionSheet)
                    let dayOfWeek = self.isWeekDaySet;let photoIdxPathRow = indexPath.row
                    let okAction = UIAlertAction(title: "OK",style: .default){(action) in
                            //Кнопки дней недели - устанавливаем фото в соответствующий день недели
                            self.setPhotoToWeekDay(dayWeek: dayOfWeek, protoRowNum: photoIdxPathRow)
                            //автоматический возврат в главное окно
                            DispatchQueue.main.async(execute: {self.performSegue(withIdentifier: "segueRecommToMain", sender: self)})}
                    
                    //Кнопка "отмена"
                    let cancelAction = UIAlertAction(title: NSLocalizedString("Cancel",     comment: "cancel button"), style: .cancel){(action) in}
                    
                    alertController.addAction(okAction);alertController.addAction(cancelAction)
                    if self.is_iPad == "Y" {
                        if let popoverPresentationController = alertController.popoverPresentationController {
                            popoverPresentationController.sourceView = self.view}
                    }
                    
                    self.present(alertController, animated: true, completion: nil)
                }
                else {
                    //print("collection view was tapped")
                    //клик внутри collection view (не на фото) не обрабатываем
                }
            } //if photoArhMode == modeChoose

        }
    }
    
    
    //MARK: pickerView - Data Sources
    public func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    public func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
            return arrCategoryCode.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
            return arrCategoryName[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
            self._categcod = arrCategoryCode[row]
            CategNameTextFld.text = arrCategoryName[row]
            categPickerItemNum = row
    }
    
}
