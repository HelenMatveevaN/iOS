//
//  VC_main.swift
//  WeekSuit_b
//
//  Created by iMac on 01.03.2017
//  Copyright © 2017 Helen Matveeva. All rights reserved.
//
import UIKit
import Foundation
import CoreLocation
import SystemConfiguration
import Photos
import CoreData

class VC_main: UIViewController, CLLocationManagerDelegate, UITextFieldDelegate, UIImagePickerControllerDelegate, UINavigationControllerDelegate{
    
    //режим работы окон "фотоархив" и "рекомендации" - режим "по умолчанию" или режим "выбора"
    let modeDflt = "DEFAULT"
    let modeChoose = "CHOOSE"
    var photoArhMode = "DEFAULT"
    var recommMode = "DEFAULT"
    
    let locationManager = CLLocationManager()
    let albumTitle = "WeekSuit" //название альбома с фотоархивом
    var album_is_created = 0
    
    var is_iPad = "N"
    let fontSize18 = UIFont(name: "Helvetica", size: CGFloat(18))
    let fontSize20 = UIFont(name: "Helvetica", size: CGFloat(20))
    let fontSize28 = UIFont(name: "Helvetica", size: CGFloat(28))
    let emptyIPhoneSizePhoto = 150
    let emptyIPadSizePhoto   = 250
    let iPhoneSizePhoto = 300
    let iPadSizePhoto   = 600
    var sizePhoto = 300
    var emptyPic = #imageLiteral(resourceName: "emptyIcon.png")
    var isWeekDaySet = 0 //выбран номер недели
    
    //основные массивы, важные для сохранения данных - arrDates, ...
    //даты, загруженные в последний раз в массив (нов.неделя) соответствуют датам, сохраненным в БД (и загруженным в интерфейс из БД)
    var arrDates    = [Date(),Date(),Date(),Date(),Date(),Date(),Date()] //объявление+инициализация
    var arrDatesStr = ["","","","","","",""] //объявление+инициализация
    //--
    //есть массив загруженных данных из интернета, начиная с сегодняшнего дня, на 8 дней:
    var arrForecastFullNew  =  ["","","","","","","",""] //массив для прогноза погоды на 8 дней
    var arrForecastShortNew =  ["","","","","","","",""] //массив для краткого прогноза погоды на 8 дней
    var arrForecastIconNew  =  ["","","","","","","",""] //массив для иконок погоды
    
    //есть массив сохраненных из интерфейса данных о погоде, на неделю (7 дней)
    var arrForecastFullSaved  =  ["","","","","","",""] //массив для прогноза погоды на 8 дней
    var arrForecastShortSaved =  ["","","","","","",""] //массив для краткого прогноза погоды на 8 дней
    var arrForecastIconSaved  =  ["","","","","","",""] //массив для иконок погоды
    var arrImagesSaved        =  [UIImage(),UIImage(),UIImage(),UIImage(),UIImage(),UIImage(),UIImage()] //массив для хранения фото на 7 дней
    var arrSuitNamesSaved     =  ["","","","","","",""] //названия костюмов на 7 дней
    
    //глобальные переменные
    var cityName      = ""
    var minWeekTemp = -99 //минимальная температура недели
    var maxWeekTemp =  99 //максимальная температура недели
    
    @IBOutlet weak var date1: UIButton!
    @IBOutlet weak var date2: UIButton!
    @IBOutlet weak var date3: UIButton!
    @IBOutlet weak var date4: UIButton!
    @IBOutlet weak var date5: UIButton!
    @IBOutlet weak var date6: UIButton!
    @IBOutlet weak var date7: UIButton!
    @IBOutlet weak var DateWeatherLabel: UILabel!
    
    @IBOutlet weak var wt1: UITextField!
    @IBOutlet weak var wt2: UITextField!
    @IBOutlet weak var wt3: UITextField!
    @IBOutlet weak var wt4: UITextField!
    @IBOutlet weak var wt5: UITextField!
    @IBOutlet weak var wt6: UITextField!
    @IBOutlet weak var wt7: UITextField!
    var wt:[UITextField] = []
    
    @IBOutlet weak var wi1: UITextField!
    @IBOutlet weak var wi2: UITextField!
    @IBOutlet weak var wi3: UITextField!
    @IBOutlet weak var wi4: UITextField!
    @IBOutlet weak var wi5: UITextField!
    @IBOutlet weak var wi6: UITextField!
    @IBOutlet weak var wi7: UITextField!
    var wi:[UITextField] = []
    
    @IBOutlet weak var mainView: UIView!
    
    @IBOutlet weak var UpdateInfBtn: UIButton!
    @IBOutlet weak var HowToUseTheApp: UIButton!
    @IBOutlet weak var RecommBtn: UIButton!
    @IBOutlet weak var PhotoArhvBtn: UIButton!
    @IBOutlet weak var SettingsBtnOutlet: UIButton!
    
    @IBOutlet weak var WeekSuitLabel: UILabel!
    @IBOutlet weak var WeatherStrLabel: UILabel!
    @IBOutlet weak var cityNameLabel: UILabel!
    
    @IBOutlet weak var SuitName: UITextView!
    @IBOutlet weak var SuitImage: UIImageView!
    
    /** что произойдет до загрузки view*/ //--------------------------
    override func viewWillAppear(_ animated: Bool) {
        //print(UIDevice.current.modelName)
        
        //iPhone or iPad?
        is_iPad = self.getIsIPad()
        
        //установим более крупные шрифты для iPad
        setFontInterface(isPad: is_iPad)
        
        //загружаем долговременные данные на главный экран
        self.loadFromCoreData()
        self.refreshDateButtonTitles(arrDt: arrDates as [Date])
        self.refreshDateWeatherLabels()
        self.cityNameLabel.text = self.cityName
        self.setDateWeatherSuitInfo(num: isWeekDaySet)
    }//override func viewWillAppear(
    
    /** действия после загрузки view*/
    override func viewDidLoad() { //---------------------------
        super.viewDidLoad()
        
        //1-ищем папку "WeekSuit, 2 - если ее нет, то создаем
        //создаем фотоальбом, если его нет (запрашиваем право на доступ к фотоальбому)
        self.photo_create_album_if_not_exists()
        
        //add - распознавание жестов
        self.SuitImage.addGestureRecognizer(UILongPressGestureRecognizer(target: self, action: #selector(longPress)))
        self.view.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard)))
        
        wt1.delegate = self;wt2.delegate = self;wt3.delegate = self;wt4.delegate = self;wt5.delegate = self;wt6.delegate = self;wt7.delegate = self
        wt = [wt1, wt2, wt3, wt4, wt5, wt6, wt7]
        
        wi1.delegate = self;wi2.delegate = self;wi3.delegate = self;wi4.delegate = self;wi5.delegate = self;wi6.delegate = self;wi7.delegate = self
        wi = [wi1, wi2, wi3, wi4, wi5, wi6, wi7]
        
        locationManager.delegate = self;locationManager.desiredAccuracy = kCLLocationAccuracyHundredMeters
        if CLLocationManager.authorizationStatus() == .notDetermined {locationManager.requestWhenInUseAuthorization()}
        
        let app = UIApplication.shared;NotificationCenter.default.addObserver(self,selector: #selector(UIApplicationDelegate.applicationWillResignActive(_:)),name: NSNotification.Name.UIApplicationWillResignActive,object: app)
        
    } //конец viewDidLoad
    
    @IBAction func _ButtonHowToUseTheApp() {
        self.saveData()
    }

    //обновляем полную информацию о погоде на главной странице после выбора даты
    @IBAction func date1Act() {let num = 0;self.setDateWeatherSuitInfo(num: num)}
    @IBAction func date2Act() {let num = 1;self.setDateWeatherSuitInfo(num: num)}
    @IBAction func date3Act() {let num = 2;self.setDateWeatherSuitInfo(num: num)}
    @IBAction func date4Act() {let num = 3;self.setDateWeatherSuitInfo(num: num)}
    @IBAction func date5Act() {let num = 4;self.setDateWeatherSuitInfo(num: num)}
    @IBAction func date6Act() {let num = 5;self.setDateWeatherSuitInfo(num: num)}
    @IBAction func date7Act() {let num = 6;self.setDateWeatherSuitInfo(num: num)}
    
    @IBAction func _buttonPhotoArhive() {photoArhMode = modeDflt;self.saveData()}
    @IBAction func _buttonRecomm(_ sender: UIButton) {self.recommMode = modeDflt;self.saveData()}
    @IBAction func _buttonSettings() {self.saveData()}
    
    //КНОПКА!!!!! - ОСНОВНАЯ ФУНКЦИЯ -------------------------------------------------------
    @IBAction func _buttonUpdateInfoAct() { //------------------------

        //--- клава скрывается, когда пользователь нажимает на кнопку
        view.endEditing(true)
        
        let isInternet = self.getInternetStatus()
        if isInternet == 1 {locationManager.startUpdatingLocation()}
        
        let alertController = UIAlertController(
              title: nil,
              message: NSLocalizedString("Start a New Week or Update Weather Forecast?", comment: "New Or Update menu description")
            , preferredStyle: .actionSheet)
        
        //Кнопка "создать новую неделю"
        let newWeekAction = UIAlertAction(
          title: NSLocalizedString("Start a New Week",     comment: "new week button")
        , style: .default){(action) in
            self._funcNewWeek(isInternet)
        }
        //Кнопка "обновить данные о погоде"
        let refreshWeatherAction = UIAlertAction(
          title: NSLocalizedString("Update Weather Forecast",     comment: "refresh the weather info button")
        , style: .default){(action) in
            self._funcRfrshWeather(isInternet)
        }
        //Кнопка "отмена"
        let cancelAction = UIAlertAction(
          title: NSLocalizedString("Cancel",     comment: "cancel button")
        , style: .cancel){(action) in
        }

        alertController.addAction(newWeekAction)
        alertController.addAction(refreshWeatherAction)
        alertController.addAction(cancelAction)

        if is_iPad == "Y" {
            if let popoverPresentationController = alertController.popoverPresentationController {
                popoverPresentationController.sourceView = self.view
            }
        }

        //отобразим все кнопки в меню
        self.present(alertController, animated: true, completion: nil)
    }//@IBAction func _buttonUpdateInfoAct()
    
    override func didReceiveMemoryWarning() { //--------------------
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
        if(text == "\n") {
            textView.resignFirstResponder()
            return false
        }
        return true
    } //func textView(
    
    //Calls this function when the tap is recognized.
    func dismissKeyboard() { //--------------------
        //Causes the view (or one of its embedded text fields) to resign the first responder status.
        print("tap___________________")
        arrSuitNamesSaved[isWeekDaySet] = self.SuitName.text
        view.endEditing(true)
    }
    
    //-------------------------------------------------
    /*варианты развития:
     1. есть интернет -> пересоздаем неделю
     2. нет интернета -> создаем новую неделю из дат (имеющуюся информацию о погоде по возможности сохраняем)
     */
    
    //создаем новую неделю
    func _funcNewWeek(_ isInternet : Int){
  
        //создаем перечень дат
        arrDates = self.getArr7DatesFromTomorrow()
        self.refreshDateButtonTitles(arrDt: arrDates as [Date])
        
        //обновляем данные о погоде
        if (isInternet==0) { self.alertInternetConnection()     } //2. нет интернета
        else               { self._funcRfrshWeather(isInternet) } //1. есть интернет
        
    }// func _funcNewWeek
    
    //-------------------------------------------------
    //-------------------------------------------------
    // обновить данные о погоде
    func _funcRfrshWeather(_ isInternet : Int){
        
        if self.arrDatesStr[0].characters.count < 5 { self._funcNewWeek(isInternet)}
        
        do    {try self.refreshWeather()          }
        catch {    self.alertInternetConnection() }
    }
    
    //-------------------------------------------------
    //обновить Даты на Главной странице
    func refreshDateButtonTitles(arrDt: [Date]){
        for i in 0...6 {
            //--
            var dateStr = ""
            if is_iPad == "Y" {
                dateStr = self.getDateInStrFormat("dd.MM", arrDt[i]) + " " + self.getDateInStrFormat("EE", arrDt[i])
            }
            else              {
                dateStr = self.getDateInStrFormat("dd.MM", arrDt[i])
            }
            //--
            self.arrDatesStr[i] = dateStr
            if (i == 0) {self.date1.setTitle(dateStr, for: .normal)}
            if (i == 1) {self.date2.setTitle(dateStr, for: .normal)}
            if (i == 2) {self.date3.setTitle(dateStr, for: .normal)}
            if (i == 3) {self.date4.setTitle(dateStr, for: .normal)}
            if (i == 4) {self.date5.setTitle(dateStr, for: .normal)}
            if (i == 5) {self.date6.setTitle(dateStr, for: .normal)}
            if (i == 6) {self.date7.setTitle(dateStr, for: .normal)}
        }
    }//func refreshDateButtonTitles()
    
    //обновить в интерфейсе лейблы с погодой (загрузить данные из массивов)
    func refreshDateWeatherLabels(){
        for i in 0...6 {
            self.wt[i].text = self.arrForecastShortSaved[i]
            self.wi[i].text = self.arrForecastIconSaved[i]
        }
    }
    
    //-------------------------------------------------
    //получить массив из 7 дат подряд, начиная с завтрашнего дня
    func getArr7DatesFromTomorrow() -> [Date] {
        
        let dateOn = Date() //текущая дата
        var arrDt = [dateOn,dateOn,dateOn,dateOn,dateOn,dateOn,dateOn]
        
        //обновление дат начинаем с завтрашнего дня
        var nextDt = dateOn
        for i in 0...6 {
            nextDt = self.getNextDate(nextDt)
            arrDt[i] = nextDt
            if i == 6 {break}
        }
        return arrDt
    } //func getArr7DatesFromTomorrow
    
    //-------------------------------------------------
    //--получить нужный формат из даты
    func getDateInStrFormat(_ strFormat: String, _ date: Date) -> String {
        //--
        let formatter = DateFormatter()
        formatter.dateFormat = strFormat
        let dateInStrFormat = formatter.string(from: date)
        //--
        return dateInStrFormat
    } //func getDateInStrFormat
    
    //-------------------------------------------------
    func getDateFromString(_ strDate: String) -> Date{
        //обрабатывает строку в формате "dd.MM.yyyy"
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd.MM.yyyy"
        return dateFormatter.date( from: strDate )!
    } //func getDateFromString
    
    //-------------------------------------------------
    func getDateString(_ date :Date) -> String {
        let formatter = DateFormatter()
        
        formatter.dateFormat = "dd.MM.yyyy"
        let dateFormat = formatter.string(from: date)
        
        formatter.dateFormat = "EE"
        var dayFormat = formatter.string(from: date)
        
        if dayFormat == "Mon" {dayFormat = NSLocalizedString("Mon", comment: "Mon day") } //пн
        if dayFormat == "Tue" {dayFormat = NSLocalizedString("Tue", comment: "Tue day") } //вт
        if dayFormat == "Wed" {dayFormat = NSLocalizedString("Wed", comment: "Wed day") } //ср
        if dayFormat == "Thu" {dayFormat = NSLocalizedString("Thu", comment: "Thu day") } //cht
        if dayFormat == "Fri" {dayFormat = NSLocalizedString("Fri", comment: "Fri day") } //pt
        if dayFormat == "Sat" {dayFormat = NSLocalizedString("Sat", comment: "Sat day") } //sb
        if dayFormat == "Sun" {dayFormat = NSLocalizedString("Sun", comment: "Sun day") } //вс
        
        return dateFormat + " " + dayFormat
    }//func getDateString
    
    //-------------------------------------------------
    //Получить следующий день после заданного
    func getNextDate(_ date: Date) -> Date {
        let nextDate = (Calendar.current as NSCalendar).date(
            byAdding: [.day],
            value: 1,
            to: date,
            options: [])!
        return nextDate
    }//func getNextDate
    
    //-------------------------------------------------
    // детальная функция обновления данных о погоде
    func refreshWeather() throws {
        
        var labelTodayNum = -1
        var labelTomorrowNum = self.getTomorrowDateLabelNum() //-1; 0-6; 999
        
        if labelTomorrowNum < 0 {labelTomorrowNum = 0}
        if labelTomorrowNum >= 1 && labelTomorrowNum <= 6 {labelTodayNum = labelTomorrowNum - 1}
        if labelTomorrowNum == 999 { labelTodayNum = self.getTodayDateLabelNum() /*-1, 0-6, 999*/}
        
        // если неделя создана, но в нее не входит завтрашний день, то данные о погоде не обновляются
        if (labelTomorrowNum == 999 && labelTodayNum == 999) {self.alertLabelDateNotFound()}
        // обновление данных о погоде
        else {
            
            // обнуляем массивы с погодой (на 8 дней):
            arrForecastFullNew  =  ["","","","","","","",""] //массив для прогноза погоды на 8 дней
            arrForecastShortNew =  ["","","","","","","",""] //массив для краткого прогноза погоды на 8 дней
            arrForecastIconNew  =  ["","","","","","","",""] //массив для иконок погоды
            
            let coord = self.getCoordinates()
            let path = "http://api.openweathermap.org/data/2.5/forecast/daily?lat=\(coord.latit)&lon=\(coord.longt)&cnt=8&mode=json&units=metric&appid=6c0aaba31d403ec4ff57b514038ff0de"
            let url = URL(string: path)
            let session = URLSession.shared
            
            
            let task = session.dataTask(with: url!, completionHandler: {
                data,_,_ in
                //(data: Data?, response: URLResponse?, NSError?).self
                
                /*
                 Правила разбора JSon в Swift: https://developer.apple.com/swift/blog/?id=37
                 */
                
                let json = try? JSONSerialization.jsonObject(with: data!, options: [])
                
                var weatherMon = 0
                var weatherDay = 0
                var weatherEve = 0
                var logoNm = ""
                var logo = "" //"☀️🌤⛅️🌥🌦☁️🌧⛈🌩🌨"
                
                //глобальные переменные
                self.cityName = ""
                self.minWeekTemp = -99 //минимальная температура недели
                self.maxWeekTemp =  99 //максимальная температура недели
                
                if let dictionary = json as? [String: Any] {
                    if let dictionaryCity = dictionary["city"] as? [String: Any] {
                        self.cityName = dictionaryCity["name"] as! String
                        self.cityNameLabel.text = self.cityName
                    }
                
                    if let arrList = dictionary["list"] as? [Any] {
                        var i = 0
                        for list in arrList {
                            if let dictionaryList = list as? [String: Any] {
                                if let dictionaryTemp = dictionaryList["temp"] as? [String: Any] {
                                    weatherMon = Int((dictionaryTemp["morn"] as? Double)!)
                                    weatherDay = Int((dictionaryTemp["day"] as? Double)!)
                                    weatherEve = Int((dictionaryTemp["eve"] as? Double)!)
                                }
                                
                                if let arrWeather = dictionaryList["weather"] as? [Any] {
                                    for weather in arrWeather {
                                        if let dictionaryWeather = weather as? [String: Any] {
                                            logoNm = (dictionaryWeather["icon"] as? String)!
                                        }
                                    }
                                }
                            }
                            
                            if logoNm == "01d" || logoNm == "01n" {logo = "☀️"}
                            if logoNm == "02d" || logoNm == "02n" {logo = "🌤"}
                            if logoNm == "03d" || logoNm == "03n" {logo = "☁️"}
                            if logoNm == "04d" || logoNm == "04n" {logo = "☁️☁️"}
                            if logoNm == "09d" || logoNm == "09n" {logo = "☁️🌧"}
                            if logoNm == "10d" || logoNm == "10n" {logo = "🌦"}
                            if logoNm == "11d" || logoNm == "11n" {logo = "🌩"}
                            if logoNm == "13d" || logoNm == "13n" {logo = "🌨"}
                            
                            var weMonStr = "\(weatherMon)"
                            if (weMonStr as NSString).substring(with: NSMakeRange(0, 1)) != "-" || weatherMon != 0 {weMonStr = "+\(weMonStr)"}
                            
                            var weDayStr = "\(weatherDay)"
                            if (weDayStr as NSString).substring(with: NSMakeRange(0, 1)) != "-"
                             || weatherDay != 0 {weDayStr = "+\(weDayStr)"}
                            
                            var weEveStr = "\(weatherEve)"
                            if (weEveStr as NSString).substring(with: NSMakeRange(0, 1)) != "-" || weatherEve != 0 {weEveStr = "+\(weEveStr)"}
                            
                            let weatherStr = " T℃ | " +
                                NSLocalizedString("Morn", comment: "Morn string")
                                //УТР
                                + ":\(weMonStr) | " +
                                NSLocalizedString("Day", comment: "Day string")
                                //ДН
                                + ":\(weDayStr) | " +
                                NSLocalizedString("Even", comment: "Even string")
                                //ВЕЧ
                                + ":\(weEveStr) | " + logo
                            
                            //определяю максимальную и минимальную температуру дня
                            var min_temp = weatherMon
                            if weatherDay < min_temp {min_temp = weatherDay}
                            if weatherEve < min_temp {min_temp = weatherEve}
                            
                            if self.minWeekTemp == -99     {self.minWeekTemp = min_temp} //заменяем фейк.знач-е на реальное
                            if min_temp < self.minWeekTemp {self.minWeekTemp = min_temp}
                            
                            var max_temp = weatherDay
                            if weatherMon > max_temp {max_temp = weatherMon}
                            if weatherEve > max_temp {max_temp = weatherEve}
                            
                            if self.maxWeekTemp ==  99     {self.maxWeekTemp = max_temp} //заменяем фейк.знач-е на реальное
                            if max_temp > self.maxWeekTemp {self.maxWeekTemp = max_temp}

                            self.arrForecastFullNew[i] = weatherStr //загрузила погоду на 8 дней, начиная с сегодняшнего дня
                            self.arrForecastShortNew[i] = "\(min_temp)/\(max_temp)℃" //диапазон между мин. и макс. температурами дня
                            self.arrForecastIconNew[i] = logo
                            
                            i = i + 1
                        }
                    }
                }
                
                //обновление погоды в интерфейсе, после получения информации о погоде из api
                DispatchQueue.main.async{
                    //обновление погоды на завтра
                    var j = 1 //обновление погоды, начиная с завтрашнего дня, потому 1
                    let endNum = 6 //номер последнего лейбла (счет начинается с 0)
                    if labelTomorrowNum <= endNum {
                        for i in labelTomorrowNum...endNum {
                            self.wt[i].text = self.arrForecastShortNew[j]
                            self.wi[i].text = self.arrForecastIconNew[j]
                            //обновляем массивы для сохранения данных
                            self.arrForecastFullSaved[i] = self.arrForecastFullNew[j]
                            self.arrForecastShortSaved[i] = self.arrForecastShortNew[j]
                            self.arrForecastIconSaved[i] = self.arrForecastIconNew[j]
                            j = j + 1
                        }
                    }
                }
            })
            task.resume()
        }
    }//func refreshWeatherTexts()
    
    func getTomorrowDateLabelNum() -> Int {
        var date = Date()
        date = getNextDate(date)//завтрашний день
        let lblNumRetutn = getDateLabelNum(date)
        return lblNumRetutn
    }
    
    func getTodayDateLabelNum() -> Int {
        let date = Date()
        let lblNumRetutn = getDateLabelNum(date)
        return lblNumRetutn
    }
    
    /** Метод getDateLabelNum()
     (получить номер лейбла, в котором отображается указанная дата)
     
     -> возвращает:
     
     -1  (если поиск не был начат - актуально для пустых значений),
     0-6 (если дата найдена),
     999 (если поиск проведен, но дата не найдена)
     */
    func getDateLabelNum(_ _date: Date) -> Int {
        // по умолчанию, поиск даты не начинался
        var lblNumReturn = -1
        
        // если данные не заполнены
        /*if (self.arrDates[0] == nil) {
            lblNumReturn = -1 }
        else
        {*/ //ищем номер лейбла с датой
            let date1Str = self.getDateString(_date)
            for i in 0...6 {
                let date2Str = self.getDateString(arrDates[i] as Date)
                if (date1Str == date2Str){
                    //  Текущая дата currentDate и конечная дата endDate одинаковы
                    lblNumReturn = i
                    break
                }
            }
            
            //если нет ни одной даты, соответствующей date, то:
            if (lblNumReturn == -1) { lblNumReturn = 999 }
        //}
        return lblNumReturn
    }
    
    //-------------------------------------------------
    func getInternetStatus() -> Int {
        var existsInternetConnect = 0 //0-no,1-yes
        if self.isConnectToNetwork() == true { existsInternetConnect = 1 }
        return existsInternetConnect
    }
    
    //-------------------------------------------------
    func isConnectToNetwork() -> Bool {
        
        var zeroAddress = sockaddr_in()
        zeroAddress.sin_len = UInt8(MemoryLayout.size(ofValue: zeroAddress))
        zeroAddress.sin_family = sa_family_t(AF_INET)
            
        
        let defaultRouteReachability = withUnsafePointer(to: &zeroAddress) {
                $0.withMemoryRebound(to: sockaddr.self, capacity: 1)
                {zeroSockAddress in SCNetworkReachabilityCreateWithAddress(nil, zeroSockAddress)}
        }
        
        var flags : SCNetworkReachabilityFlags = []
        if SCNetworkReachabilityGetFlags(defaultRouteReachability!, &flags) == false {
            return false
        }
        
        let isReachable = flags.contains(.reachable)
        let needsConnection = flags.contains(.connectionRequired)
        return (isReachable && !needsConnection)
    }//func isConnectToNetwork()
    
    //-------------------------------------------------
    func getCoordinates() -> (latit : CLLocationDegrees, longt : CLLocationDegrees)
    {
        //по умолчанию - координаты штаб-квартиры Эппл в Купертино
        var latit : CLLocationDegrees = 37.3323
        var longit : CLLocationDegrees = -122.031
        
        if CLLocationManager.locationServicesEnabled(){
            if locationManager.location?.coordinate.latitude != nil { latit  = (locationManager.location?.coordinate.latitude)!}
            if locationManager.location?.coordinate.longitude != nil { longit  = (locationManager.location?.coordinate.longitude)!}
            if CLLocationManager.authorizationStatus() == .authorizedAlways || CLLocationManager.authorizationStatus() == .authorizedWhenInUse { locationManager.stopUpdatingLocation() }
        }
        return (latit,longit)
    }//func getCoordinates() 
    
    //-------------------------
    /*Переключение на другое приложение или нажатие копки «Home».*/
    func applicationWillResignActive(_ notification:Notification){
        self.saveData()
    }
    
    /*Переход в состояние Background*/
    func applicationDidEnterBackground(application: UIApplication) {
        self.saveData()
    }
    
    /*Пользователь закрывает приложение*/
    func applicationWillTerminate(application: UIApplication) {
        self.saveData()
    }
    
    //-------------------------------------------------
    /*сохранить изменения*/
    func saveData() {
        
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "WeekSuitEntity")
        do {
            let results = try CoreDataManager.instance.managedObjectContext.fetch(fetchRequest)
            if results.count == 0 {
                for i in (0...6){
                    let managedObject = WeekSuitEntityMO()
                    managedObject.dt = arrDates[i] as NSDate
                    managedObject.forecastFullStr = arrForecastFullSaved[i]
                    managedObject.forecastShortStr = arrForecastShortSaved[i]
                    managedObject.forecastIconStr = arrForecastIconSaved[i]
                    managedObject.descr = arrSuitNamesSaved[i]
                    if arrImagesSaved[i].size.width == 0 {} else {managedObject.photo = self.convertImageToNSData(myImage: arrImagesSaved[i])}
                }
            }
            else {
                var i = 0
                for result in results as! [WeekSuitEntityMO] {
                    //присвоить данные из массива
                    result.dt = arrDates[i] as NSDate
                    result.forecastFullStr = arrForecastFullSaved[i]
                    result.forecastShortStr = arrForecastShortSaved[i]
                    result.forecastIconStr = arrForecastIconSaved[i]
                    result.descr = arrSuitNamesSaved[i]
                    if arrImagesSaved[i].size.width == 0 {} else {result.photo = self.convertImageToNSData(myImage: arrImagesSaved[i])}
                    i = i + 1
                }
            }
            CoreDataManager.instance.saveContext()
        } catch {
            print("error=\(error)")
        }
        
        //сохранение настроек
        let fetchRequest1 = NSFetchRequest<NSFetchRequestResult>(entityName: "Settings")
        do {
            let results = try CoreDataManager.instance.managedObjectContext.fetch(fetchRequest1)
            if results.count == 0 {
                let managedObject = SettingsMO()
                managedObject.cityName = self.cityName
                if minWeekTemp != -99 {managedObject.minTemp  = Int16(self.minWeekTemp)}
                if maxWeekTemp !=  99 {managedObject.maxTemp  = Int16(self.maxWeekTemp)}
                managedObject.photoArhMode = photoArhMode
                managedObject.recommMode   = recommMode
                managedObject.weekDayChoosed = Int16(isWeekDaySet)
            }
            else {
                for result in results as! [SettingsMO] {
                    result.cityName = self.cityName
                    if minWeekTemp != -99 {result.minTemp  = Int16(self.minWeekTemp)}
                    if maxWeekTemp !=  99 {result.maxTemp  = Int16(self.maxWeekTemp)}
                    result.photoArhMode = photoArhMode
                    result.recommMode   = recommMode
                    result.weekDayChoosed = Int16(isWeekDaySet)
                }
            }
            CoreDataManager.instance.saveContext()
        } catch {
            print("error=\(error)")
        }
    }
    
    //-------------------------------------------------
    func alertInternetConnection() {
        let alertController = UIAlertController(
            title: NSLocalizedString("No Internet Connection", comment: "internet connection alert title")
            //"Нет соединения с интернетом"
            , message: NSLocalizedString("Weather Forecast Information can not be updated", comment: "weather not updated alert")
            //"Данные о погоде обновлены не будут"
          , preferredStyle: UIAlertControllerStyle.alert)
        alertController.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default,handler: nil))
        self.present(alertController, animated: true, completion: nil)
    }
    
    //--------------------------
    func alertLabelDateNotFound() {
        let alertController = UIAlertController(
            title: NSLocalizedString("No data found for Weather Forecast updates", comment: "weather is not refresh alert title")
            //"Не найдены данные для обновления погоды"
          , message: NSLocalizedString("You Need Start a New Week", comment: "start a new week alert")
            //"Создайте новую неделю"
          , preferredStyle: UIAlertControllerStyle.alert
        )
        alertController.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default,handler: nil))
        self.present(alertController, animated: true, completion: nil)
    }
    
    //создать в галерее фотоальбом, если его нет------------------------------------------------------
    func photo_create_album_if_not_exists() {
        //источник кода - https://habrahabr.ru/post/318810/
                //2-загружаем в БД инфо о фото, которые не были загружены
        //Создаем фото-альбом, если его нет
        
        //1-есть ли альбом с именем, с которым хотим создать?
        let options = PHFetchOptions()
        options.predicate = NSPredicate(format: "title = %@", albumTitle)
        let collection = PHAssetCollection.fetchAssetCollections(with: .album,
                                                                 subtype: .any,
                                                                 options: options)
        if collection.firstObject != nil {
            // Альбом уже есть, можем его использовать
            self.album_is_created = 1
        }
        else {
            //2 - Если альбома нет, то для его создания нам потребуется создать запрос с помощью метода PHAssetCollectionChangeRequest.creationRequestForAssetCollection(withTitle: String):
            var placeholder: PHObjectPlaceholder?
            PHPhotoLibrary.shared().performChanges({
                let request = PHAssetCollectionChangeRequest.creationRequestForAssetCollection(withTitle: self.albumTitle)
                placeholder = request.placeholderForCreatedAssetCollection
            }, completionHandler: { (success, error) -> Void in
                if success {
                    if let id = placeholder?.localIdentifier {
                        let fetchResult = PHAssetCollection.fetchAssetCollections(withLocalIdentifiers: [id],
                                                                                  options: nil)
                        if fetchResult.firstObject != nil {
                            // Можем использовать альбом
                            self.album_is_created = 1
                        }
                    }
                }
            })
        }
    }//func photo_create_album_if_not_exists()
    //------------------
    
    //выставить шрифты в зависимости от типа устройства ----------------------------------------------------------
    func setFontInterface(isPad: String){
        if isPad == "Y" {
            
            //buttons
            self.UpdateInfBtn.titleLabel?.font = fontSize20
            self.HowToUseTheApp.titleLabel?.font = fontSize18
            self.RecommBtn.titleLabel?.font = fontSize20
            self.PhotoArhvBtn.titleLabel?.font = fontSize20
            self.SettingsBtnOutlet.titleLabel?.font = fontSize20
            
            //textView
            self.SuitName.font = fontSize18
            
            //Labels
            self.WeekSuitLabel.font = fontSize28
            self.cityNameLabel.font = fontSize18
            self.DateWeatherLabel.font = fontSize20
            
            //dates-buttons
            self.date1.titleLabel?.font = fontSize18
            self.date2.titleLabel?.font = fontSize18
            self.date3.titleLabel?.font = fontSize18
            self.date4.titleLabel?.font = fontSize18
            self.date5.titleLabel?.font = fontSize18
            self.date6.titleLabel?.font = fontSize18
            self.date7.titleLabel?.font = fontSize18
            
            //dates-labels
            self.wt1.font = fontSize18
            self.wt2.font = fontSize18
            self.wt3.font = fontSize18
            self.wt4.font = fontSize18
            self.wt5.font = fontSize18
            self.wt6.font = fontSize18
            self.wt7.font = fontSize18
            
            //dates-icons
            self.wi1.font = fontSize20
            self.wi2.font = fontSize20
            self.wi3.font = fontSize20
            self.wi4.font = fontSize20
            self.wi5.font = fontSize20
            self.wi6.font = fontSize20
            self.wi7.font = fontSize20
            
            self.sizePhoto = self.iPadSizePhoto
        }//if isPad == "Y"
    }//setFontInterface
    
    
    //определить тип устройства - iPad или iPhone?
    func getIsIPad() -> String {
        //iPhone or iPad?
        is_iPad = "N"
        let deviceIdiom = UIScreen.main.traitCollection.userInterfaceIdiom
        switch (deviceIdiom) {
        case .pad: is_iPad = "Y"
        default:   is_iPad = "N" }
        self.setFontInterface(isPad: is_iPad)
        return is_iPad
    }
    
    //загрузка долговременных данных
    func loadFromCoreData(){
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "WeekSuitEntity")
        do {
            let results = try CoreDataManager.instance.managedObjectContext.fetch(fetchRequest)
            
            var i = 0
            for result in results as! [WeekSuitEntityMO] {
                arrDates[i] = result.dt! as Date
                arrForecastFullSaved[i] = result.forecastFullStr!
                arrForecastShortSaved[i] = result.forecastShortStr!
                arrForecastIconSaved[i] = result.forecastIconStr!
                if result.descr == nil {} else {arrSuitNamesSaved[i] = result.descr!}
                if result.photo == nil {arrImagesSaved[i] = UIImage()}
                else { arrImagesSaved[i] = self.convertNSDataToImage(imageData: result.photo!)}
                i = i + 1
            }
        } catch {
            print("error=\(error)")
        }

        //загрузка настроек
        let fetchRequest1 = NSFetchRequest<NSFetchRequestResult>(entityName: "Settings")
        do {
            let results = try CoreDataManager.instance.managedObjectContext.fetch(fetchRequest1)
            for result in results as! [SettingsMO] {
                self.cityName = result.cityName!
                isWeekDaySet = Int(result.weekDayChoosed)
            }
        } catch {
            print("error=\(error)")
        }
    }//загрузка долговременных данных


    func convertImageToNSData(myImage: UIImage) -> NSData {
        let imageData: NSData = UIImagePNGRepresentation(myImage)! as NSData
        return imageData
    }

    func convertNSDataToImage(imageData: NSData) -> UIImage {
        let image : UIImage = UIImage(data: imageData as Data)!
        return image
    }
    
    //изменить размер фото
    func resizeImage(image: UIImage, _newWidth: CGFloat) -> UIImage {
        
        var scale = _newWidth / image.size.width
        var newHeight = image.size.height * scale
        var newWidth = _newWidth

        //print("\(image) \(scale) \(newHeight) \(newWidth)")

        if image.size.height > image.size.width {
            newHeight = newWidth
            scale = newHeight / image.size.height
            newWidth = image.size.width * scale
        }
        
        UIGraphicsBeginImageContext(CGSize(width: newWidth, height: newHeight))
        image.draw(in: CGRect(x: 0, y: 0, width: newWidth, height: newHeight))
        let newImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        
        return newImage!

    }
    
    func setNewSuitImage(num: Int){
        var image = UIImage()
        var emptySizePhoto = 0
        if num > -1 {image = arrImagesSaved[num]}
        if image.size.width == 0 {
            image = emptyPic
            if is_iPad == "Y" {emptySizePhoto = emptyIPadSizePhoto; image = emptyPic}
            else              {emptySizePhoto = emptyIPhoneSizePhoto; image = #imageLiteral(resourceName: "ppic_180.png")}
            self.SuitImage.image = resizeImage(image: image, _newWidth: CGFloat(emptySizePhoto))}
        else {
            self.SuitImage.image = resizeImage(image: image, _newWidth: CGFloat(sizePhoto))
        }
    }
    
    
    func setDateDecoration(num: Int){
        date1.layer.borderWidth = 0;date2.layer.borderWidth = 0;date3.layer.borderWidth = 0;date4.layer.borderWidth = 0;date5.layer.borderWidth = 0;date6.layer.borderWidth = 0;date7.layer.borderWidth = 0
        if num == 0 {date1.layer.borderWidth = 3;self.DateWeatherLabel.backgroundColor = self.date1.backgroundColor}
        if num == 1 {date2.layer.borderWidth = 3;self.DateWeatherLabel.backgroundColor = self.date2.backgroundColor}
        if num == 2 {date3.layer.borderWidth = 3;self.DateWeatherLabel.backgroundColor = self.date3.backgroundColor}
        if num == 3 {date4.layer.borderWidth = 3;self.DateWeatherLabel.backgroundColor = self.date4.backgroundColor}
        if num == 4 {date5.layer.borderWidth = 3;self.DateWeatherLabel.backgroundColor = self.date5.backgroundColor}
        if num == 5 {date6.layer.borderWidth = 3;self.DateWeatherLabel.backgroundColor = self.date6.backgroundColor}
        if num == 6 {date7.layer.borderWidth = 3;self.DateWeatherLabel.backgroundColor = self.date7.backgroundColor}
    }
    
    func setDateWeatherSuitInfo(num: Int) {
        self.DateWeatherLabel.text = " \(self.arrDatesStr[num]) \(self.arrForecastFullSaved[num])"
        self.setNewSuitImage(num: num)
        self.setDateDecoration(num: num)
        
        if self.arrSuitNamesSaved[num].characters.count < 6
             {self.SuitName.text = NSLocalizedString("Type the suit name...", comment: "Type the suite name...")}
        else {self.SuitName.text = "\(self.arrSuitNamesSaved[num])"}

        isWeekDaySet = num
    }
    
    //обработка жеста long press на фото в CollectionView
    func longPress(sender: UIPinchGestureRecognizer){
        if (sender.state == UIGestureRecognizerState.ended) {
            print("longPress______________")
            //--- клава скрывается, когда пользователь нажимает на кнопку
            view.endEditing(true)
            
            let alertController = UIAlertController(
                title: nil,
                message: NSLocalizedString("Select photo source:", comment: "Выберите источник фото description")
                , preferredStyle: .actionSheet)
            
            //Кнопка "фотоархив"
            let callPhotoArhive = UIAlertAction(title: NSLocalizedString("Photoarhive", comment: "фото-архив"), style: .default){(action) in
                self.photoArhMode = self.modeChoose //режим выбора фото
                self.saveData()
                
                //открыть другое окно
                DispatchQueue.main.async(execute: {
                    self.performSegue(withIdentifier: "segueArh", sender: self)
                })
                
                /*
                 в режиме CHOOSE должны происходить 3 вещи:
                 1 - нет кнопки "Назад"
                 2 - выбранное фото должно дополнительно подсвечиваться (более жирной рамкой - как вариант)
                 2.1 - выбранное фото должно сохраниться в нужном дне неделе и отобразиться потом в главном окне
                 3 - после выбора фото должен происходить автоматический переход в главное окно
                 4 - в главном окне должны остаться подсвечены те элементы, который были подсвечены до перехода
                 */
            }
            //Кнопка "рекомендации"
            let callRecomm = UIAlertAction(title: NSLocalizedString("Recommendations", comment: "рекомендации"), style: .default){(action) in
                self.recommMode = self.modeChoose //режим выбора фото
                self.saveData()
                //открыть другое окно
                DispatchQueue.main.async(execute: {self.performSegue(withIdentifier: "segueRecomm", sender: self)})
            }
            //Кнопка "фото-камера"
            let callPhotoCam = UIAlertAction(title: NSLocalizedString("Camera", comment: "фото-камера"), style: .default){(action) in
                self.openCamera()}
            //Кнопка "отмена"
            let cancelAction = UIAlertAction(title: NSLocalizedString("Cancel",     comment: "cancel button"), style: .cancel){(action) in }
            //
            alertController.addAction(callPhotoArhive);alertController.addAction(callRecomm);alertController.addAction(callPhotoCam)
            alertController.addAction(cancelAction)
            //
            if is_iPad == "Y" {
                if let popoverPresentationController = alertController.popoverPresentationController {
                    popoverPresentationController.sourceView = self.view
                }
            }
            //отобразим все кнопки в меню
            self.present(alertController, animated: true, completion: nil)        }
    }
    
    func openCamera() {
        if UIImagePickerController.isSourceTypeAvailable(UIImagePickerControllerSourceType.camera) {
            let imagePicker = UIImagePickerController()
            imagePicker.delegate = self
            imagePicker.sourceType = UIImagePickerControllerSourceType.camera;
            imagePicker.allowsEditing = false
            self.present(imagePicker, animated: true, completion: nil)
        }
    }

    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        if let pickedImage = info[UIImagePickerControllerOriginalImage] as? UIImage {
            //отобразить фото на главной странице
            self.arrImagesSaved[self.isWeekDaySet] = resizeImage(image: pickedImage, _newWidth: CGFloat(sizePhoto))
            //сохранить фото в БД
            saveData()
            //сохранить фото в библиотеке устройства
            let imageData = UIImagePNGRepresentation(pickedImage)
            let compressedImage = UIImage(data: imageData!)
            UIImageWriteToSavedPhotosAlbum(compressedImage!, self, nil, nil)
            //сообщение о сохранении фото в библиотеке
            let alert = UIAlertController(title: "Saved", message: "Your image has been saved in album 'WeekSuit'", preferredStyle: .alert)
            let okAction = UIAlertAction(title: "Ok", style: .default, handler: nil)
            alert.addAction(okAction)
            self.present(alert, animated: true, completion: nil)
        }
        picker.dismiss(animated: true, completion: nil)
    }
  }


//источник - http://stackoverflow.com/questions/26028918/ios-how-to-determine-the-current-iphone-device-model-in-swift
/*public extension UIDevice {
    
    var modelName: String {
        #if (arch(i386) || arch(x86_64)) && os(iOS)
            let DEVICE_IS_SIMULATOR = true
        #else
            let DEVICE_IS_SIMULATOR = false
        #endif
        
        var machineString : String = ""
        
        if DEVICE_IS_SIMULATOR == true
        {
            if let dir = ProcessInfo().environment["SIMULATOR_MODEL_IDENTIFIER"] {
                machineString = dir
            }
        }
        else {
            //var systemInfo = utsname()
            //uname(&systemInfo)
            //let machineMirror = Mirror(reflecting: systemInfo.machine)
            //machineString = machineMirror.children.reduce("") { identifier, element in
            //    guard let value = element.value as? Int8, value != 0 else { return identifier }
            //    return identifier + String(UnicodeScalar(UInt8(value)))
            //}
        }
        
        switch machineString {
        case "iPod5,1":                                 return "iPod Touch 5"
        case "iPod7,1":                                 return "iPod Touch 6"
        case "iPhone3,1", "iPhone3,2", "iPhone3,3":     return "iPhone 4"
        case "iPhone4,1":                               return "iPhone 4s"
        case "iPhone5,1", "iPhone5,2":                  return "iPhone 5"
        case "iPhone5,3", "iPhone5,4":                  return "iPhone 5c"
        case "iPhone6,1", "iPhone6,2":                  return "iPhone 5s"
        case "iPhone7,2":                               return "iPhone 6"
        case "iPhone7,1":                               return "iPhone 6 Plus"
        case "iPhone8,1":                               return "iPhone 6s"
        case "iPhone8,2":                               return "iPhone 6s Plus"
        case "iPhone8,4":                               return "iPhone SE"
        case "iPhone9,1":                               return "iPhone 7"
        case "iPhone9,2":                               return "iPhone 7 Plus"
        case "iPad2,1", "iPad2,2", "iPad2,3", "iPad2,4":return "iPad 2"
        case "iPad3,1", "iPad3,2", "iPad3,3":           return "iPad 3"
        case "iPad3,4", "iPad3,5", "iPad3,6":           return "iPad 4"
        case "iPad4,1", "iPad4,2", "iPad4,3":           return "iPad Air"
        case "iPad5,3", "iPad5,4":                      return "iPad Air 2"
        case "iPad2,5", "iPad2,6", "iPad2,7":           return "iPad Mini"
        case "iPad4,4", "iPad4,5", "iPad4,6":           return "iPad Mini 2"
        case "iPad4,7", "iPad4,8", "iPad4,9":           return "iPad Mini 3"
        case "iPad5,1", "iPad5,2":                      return "iPad Mini 4"
        case "iPad6,7", "iPad6,8":                      return "iPad Pro"
        case "AppleTV5,3":                              return "Apple TV"
        default:                                        return machineString
        }
    }
}
*/
