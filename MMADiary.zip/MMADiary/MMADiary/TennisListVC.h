//
//  TennisListVC.h
//  TennisTraner2
//
//  Created by Helen Matveeva on 03.04.18.
//  Copyright © 2018 Helen Matveeva. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TennisListVC : UIViewController <UITableViewDelegate, UITableViewDataSource> {
}
@property (weak, nonatomic) IBOutlet UITableView *TennisListTableView;
@property (weak, nonatomic) IBOutlet UILabel     *titleLabel;
@property (weak, nonatomic) IBOutlet UIButton    *BtnBackOutlet;


@end
