//
//  DicHelp.m
//
//  Created by Helen Matveeva on 09.07.18.
//  Copyright © 2018 Helen Matveeva. All rights reserved.
//

#import "DicHelp.h"
#import "Params.h"

@interface DicHelp () {
    NSString *g_isIpad;
}
@end

@implementation DicHelp

@synthesize dicHelpTextView;
@synthesize BtnBackOutlet, LabelTitleOutlet;

- (void)viewDidLoad {
    NSLog(@"----------viewDidLoad------------");
    [super viewDidLoad];
    
    //iPad?
    Params *params = [[Params alloc] init];
    [params getUserInterfaceIdiom];
    g_isIpad = params -> isIPad;
    
    if ([g_isIpad isEqualToString:@"Y"]){
        [LabelTitleOutlet   setFont:[LabelTitleOutlet.font fontWithSize:22]];
        [dicHelpTextView    setFont:[dicHelpTextView.font fontWithSize:20]];
        [BtnBackOutlet.titleLabel setFont:[BtnBackOutlet.titleLabel.font fontWithSize:20]];
    }
    
    NSString *strHelp = NSLocalizedString(@"HELP\n\nTENNIS DIARY (Personal diary of achievements and Archive of the developing techniques) is the application for tennis players (and their coachers) that enables the user to note and save information about the trainings as well as to control personal progress in this kind of sport.\n\n- Enter information about the training to your diary (the coacher’s name, the date of the training, pulse rate, pressure, the goal of the training, said in training (bright memorable key phrase or sentence, said in the training).\n\n- Write down the techniques you consider the most effective ones.\n\n- Use Diary and create the History of trainings.\n\n- Monitor your progress.\n\n- Keep watch over the most effective techniques for you (successfully applied technique, good physical state, the viable explanations of the coacher, etc.).\n\n- Work to improve yourself.\n\nNow there is no need to rely on your memory – our Diary will save information about your state and the peculiarities of your technique.\nNo one is born a champion, you can become one as a result of step-by-step and conscious movement towards your goal. Our Diary will help you to achieve your objectives.\n***\n\nDISPLAY THE MAIN FORM\n\nThe Main form is displayed by default when the app is launched. There is a caption «How to use the program» (it’s a switch to Help) at the bottom of this form.\n\n\nCREATE A NOTE ABOUT THE TRAINING\n\nTo create a note about a new training, please click the «+» button on the Main form and fill in the following fields: «coacher», «date, time», «pressure», «pulse before / after training», «said in training», «goal», «protection», «training gloves».\nClick the «💾» button to save your note.\n\nYou may fill in «coacher», «goal» fields by clicking the «coacher»/«goal» fields (under the «coacher»/«goal» captions), then select the desired value from the list and click the «Choose Coacher»/«Choose Goal» button.\n\nIf the list of values is empty, you can create a new value by clicking the «New» button and filling in this field, then press the «Add» button. As a result, the specified value will appear under the «coacher»/«goal» caption.\n\nIn order to fill in «protection», «training gloves» fields, you need to click the field on the right side of «protection», «training gloves» caption, choose the desired value from the list and press the «Choose Protection»/«Choose Training Gloves» button.\n\nIf the list of values is empty, you can create a new value by clicking the «New» button and filling in this field, then press the «Add» button. As a result, the specified value will appear on the right side of the «protection»/«training gloves» caption.\n\nYou may fill in «pressure», «pulse before/after training», «said in training» fields by setting the cursor to one of these fields. Using the keyboard, enter the value. When you finished, just click outside the field and keyboard will be closed automatically.\n\nIf you specify all information about the training, please save it by clicking the «💾» button.\n\n\nCREATE A NEW TRAINING\n\nYou may create a new training by clicking the «+» button on the Main form and following the mentioned above steps. Save your note by clicking the «💾» button.\n\nAfter saving, the previous training will be added to the History of trainings.\n\n\nCHANGE A NEW TRAINING\n\nTo change a new training, you need to change appropriate parameters on the Main form and then save all the changes by clicking the «💾» button.\n\n\nCHANGE/VIEW THE PREVIOUS TRAINING (HISTORY OF TRAINING)\n\nFor this, you need to go to «The History of trainings» window by clicking «🗒» on the Main form.\nIn «The History of trainings» form choose the training you want to change and then press «✏» on the right side of this training.\nSo, change information in the «Edit a training» form and click the button «💾» - all changes will be saved.\n\nFor returning to the previous form, please click the «Back» button.\n\nThe Main form displays the last training, the History of trainings – previously created ones. If you create only 1 training, the History of trainings list will be empty.\n\n\nREFERENCE GUIDES\n\n«Coacher», «Goal», «Protection», «Training Gloves» are the reference values. You can view, change/delete them.\n\nThe reference values of every training remain the same – they can be changed by CHANGE A TRAINING (for doing this, look at «CHANGE A NEW TRAINING» or «CHANGE/VIEW THE PREVIOUS TRAINING» of this HELP).\n\nBy clicking any button like «→» on the Main form, you can change information in the reference guide. Please choose the necessary reference guide by clicking above the «choose a reference guide» caption.\n\nClick «✏» opposite the article of the reference guide you want to be changed.\n\nIn the «Edit» window you need to change the necessary fields. By clicking «💾», all the changes will be saved.\n\nIf the reference guide is empty, just create a new reference value. For this, you need to click any button like «→» on the Main form. Choose the desired reference guide by clicking above the «choose the reference guide» caption. Click the «+» button on the right side. Specify new reference values. Save the changes by clicking the «Add» button. As a result, the reference value will be added to the selected reference guide.\n\n\nTHE REFERENCE GUIDE «MY TECHNIQUES»\n\nThe reference guide «My techniques» is special.\nIts values aren’t saved in the History of trainings.\n\nIt is assumed that the user himself fills in the descriptions of techniques for different types of the strokes (for example, the description of performing the serve technique).\n\nIf the reference value is marked with «display on the main form», its name will be displayed on the Main form under «My techniques» caption.\n\nBy clicking the technique name, you can find out the description of this technique.\n\nOn the Main form can be displayed only the first 3 techniques, indicated as «display on the main form».",@"Help comment");
                                                                                                
    dicHelpTextView.scrollEnabled = false;//отмена прокрутки вниз
    dicHelpTextView.text = strHelp;
}

- (void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:NO];
    dicHelpTextView.scrollEnabled = true; //отмена прокрутки вниз
}

@end

