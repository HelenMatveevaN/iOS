//
//  MyMethodicsMO+CoreDataClass.h
//  MMADiary
//
//  Created by Helen Matveeva on 26/10/2018.
//  Copyright © 2018 Helen Matveeva. All rights reserved.
//
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

NS_ASSUME_NONNULL_BEGIN

@interface MyMethodicsMO : NSManagedObject

@end

NS_ASSUME_NONNULL_END

#import "MyMethodicsMO+CoreDataProperties.h"
