//
//  GoalsMO+CoreDataProperties.m
//  MMADiary
//
//  Created by Helen Matveeva on 26/10/2018.
//  Copyright © 2018 Helen Matveeva. All rights reserved.
//
//

#import "GoalsMO+CoreDataProperties.h"

@implementation GoalsMO (CoreDataProperties)

+ (NSFetchRequest<GoalsMO *> *)fetchRequest {
	return [NSFetchRequest fetchRequestWithEntityName:@"Goals"];
}

@dynamic descr;

@end
