//
//  DicGlovesMO+CoreDataProperties.m
//  MMADiary
//
//  Created by Helen Matveeva on 26/10/2018.
//  Copyright © 2018 Helen Matveeva. All rights reserved.
//
//

#import "DicGlovesMO+CoreDataProperties.h"

@implementation DicGlovesMO (CoreDataProperties)

+ (NSFetchRequest<DicGlovesMO *> *)fetchRequest {
	return [NSFetchRequest fetchRequestWithEntityName:@"DicGloves"];
}

@dynamic descr;
@dynamic size;

@end
