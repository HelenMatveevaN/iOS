//
//  DicProtectMO+CoreDataProperties.h
//  MMADiary
//
//  Created by Helen Matveeva on 26/10/2018.
//  Copyright © 2018 Helen Matveeva. All rights reserved.
//
//

#import "DicProtectMO+CoreDataClass.h"


NS_ASSUME_NONNULL_BEGIN

@interface DicProtectMO (CoreDataProperties)

+ (NSFetchRequest<DicProtectMO *> *)fetchRequest;

@property (nullable, nonatomic, copy) NSString *descr;
@property (nullable, nonatomic, copy) NSString *size;

@end

NS_ASSUME_NONNULL_END
