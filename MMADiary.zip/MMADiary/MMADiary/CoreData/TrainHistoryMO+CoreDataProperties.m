//
//  TrainHistoryMO+CoreDataProperties.m
//  MMADiary
//
//  Created by Helen Matveeva on 26/10/2018.
//  Copyright © 2018 Helen Matveeva. All rights reserved.
//
//

#import "TrainHistoryMO+CoreDataProperties.h"

@implementation TrainHistoryMO (CoreDataProperties)

+ (NSFetchRequest<TrainHistoryMO *> *)fetchRequest {
	return [NSFetchRequest fetchRequestWithEntityName:@"TrainHistory"];
}

@dynamic fioStr;
@dynamic goalStr;
@dynamic protectStr;
@dynamic saidStr;
@dynamic glovesStr;
@dynamic tDateDate;
@dynamic tDateString;
@dynamic tNum;
@dynamic tPressLow;
@dynamic tPressUp;
@dynamic tPulseAfter;
@dynamic tPulseBefore;

@end
