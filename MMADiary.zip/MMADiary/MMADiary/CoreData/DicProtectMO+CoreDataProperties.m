//
//  DicProtectMO+CoreDataProperties.m
//  MMADiary
//
//  Created by Helen Matveeva on 26/10/2018.
//  Copyright © 2018 Helen Matveeva. All rights reserved.
//
//

#import "DicProtectMO+CoreDataProperties.h"

@implementation DicProtectMO (CoreDataProperties)

+ (NSFetchRequest<DicProtectMO *> *)fetchRequest {
	return [NSFetchRequest fetchRequestWithEntityName:@"DicProtect"];
}

@dynamic descr;
@dynamic size;

@end
