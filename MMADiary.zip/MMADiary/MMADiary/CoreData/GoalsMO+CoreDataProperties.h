//
//  GoalsMO+CoreDataProperties.h
//  MMADiary
//
//  Created by Helen Matveeva on 26/10/2018.
//  Copyright © 2018 Helen Matveeva. All rights reserved.
//
//

#import "GoalsMO+CoreDataClass.h"


NS_ASSUME_NONNULL_BEGIN

@interface GoalsMO (CoreDataProperties)

+ (NSFetchRequest<GoalsMO *> *)fetchRequest;

@property (nullable, nonatomic, copy) NSString *descr;

@end

NS_ASSUME_NONNULL_END
