//
//  TrainTodayMO+CoreDataProperties.m
//  MMADiary
//
//  Created by Helen Matveeva on 26/10/2018.
//  Copyright © 2018 Helen Matveeva. All rights reserved.
//
//

#import "TrainTodayMO+CoreDataProperties.h"

@implementation TrainTodayMO (CoreDataProperties)

+ (NSFetchRequest<TrainTodayMO *> *)fetchRequest {
	return [NSFetchRequest fetchRequestWithEntityName:@"TrainToday"];
}

@dynamic fioStr;
@dynamic goalStr;
@dynamic protectStr;
@dynamic saidStr;
@dynamic glovesStr;
@dynamic tDateDate;
@dynamic tDateString;
@dynamic tNum;
@dynamic tPressLow;
@dynamic tPressUp;
@dynamic tPulseAfter;
@dynamic tPulseBefore;

@end
