//
//  MyMethodicsMO+CoreDataProperties.m
//  MMADiary
//
//  Created by Helen Matveeva on 26/10/2018.
//  Copyright © 2018 Helen Matveeva. All rights reserved.
//
//

#import "MyMethodicsMO+CoreDataProperties.h"

@implementation MyMethodicsMO (CoreDataProperties)

+ (NSFetchRequest<MyMethodicsMO *> *)fetchRequest {
	return [NSFetchRequest fetchRequestWithEntityName:@"MyMethodics"];
}

@dynamic descr;
@dynamic isBase;
@dynamic name;

@end
