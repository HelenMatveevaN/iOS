//
//  DicTrainerMO+CoreDataProperties.h
//  MMADiary
//
//  Created by Helen Matveeva on 26/10/2018.
//  Copyright © 2018 Helen Matveeva. All rights reserved.
//
//

#import "DicTrainerMO+CoreDataClass.h"


NS_ASSUME_NONNULL_BEGIN

@interface DicTrainerMO (CoreDataProperties)

+ (NSFetchRequest<DicTrainerMO *> *)fetchRequest;

@property (nullable, nonatomic, copy) NSString *fio;

@end

NS_ASSUME_NONNULL_END
