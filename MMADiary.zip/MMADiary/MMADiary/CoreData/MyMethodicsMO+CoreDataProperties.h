//
//  MyMethodicsMO+CoreDataProperties.h
//  MMADiary
//
//  Created by Helen Matveeva on 26/10/2018.
//  Copyright © 2018 Helen Matveeva. All rights reserved.
//
//

#import "MyMethodicsMO+CoreDataClass.h"


NS_ASSUME_NONNULL_BEGIN

@interface MyMethodicsMO (CoreDataProperties)

+ (NSFetchRequest<MyMethodicsMO *> *)fetchRequest;

@property (nullable, nonatomic, copy) NSString *descr;
@property (nullable, nonatomic, copy) NSString *isBase;
@property (nullable, nonatomic, copy) NSString *name;

@end

NS_ASSUME_NONNULL_END
