//
//  TrainTodayMO+CoreDataProperties.h
//  MMADiary
//
//  Created by Helen Matveeva on 26/10/2018.
//  Copyright © 2018 Helen Matveeva. All rights reserved.
//
//

#import "TrainTodayMO+CoreDataClass.h"


NS_ASSUME_NONNULL_BEGIN

@interface TrainTodayMO (CoreDataProperties)

+ (NSFetchRequest<TrainTodayMO *> *)fetchRequest;

@property (nullable, nonatomic, copy) NSString *fioStr;
@property (nullable, nonatomic, copy) NSString *goalStr;
@property (nullable, nonatomic, copy) NSString *protectStr;
@property (nullable, nonatomic, copy) NSString *saidStr;
@property (nullable, nonatomic, copy) NSString *glovesStr;
@property (nullable, nonatomic, copy) NSDate *tDateDate;
@property (nullable, nonatomic, copy) NSString *tDateString;
@property (nonatomic) int16_t tNum;
@property (nonatomic) int16_t tPressLow;
@property (nonatomic) int16_t tPressUp;
@property (nonatomic) int16_t tPulseAfter;
@property (nonatomic) int16_t tPulseBefore;

@end

NS_ASSUME_NONNULL_END
