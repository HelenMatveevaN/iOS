//
//  DicTrainerMO+CoreDataProperties.m
//  MMADiary
//
//  Created by Helen Matveeva on 26/10/2018.
//  Copyright © 2018 Helen Matveeva. All rights reserved.
//
//

#import "DicTrainerMO+CoreDataProperties.h"

@implementation DicTrainerMO (CoreDataProperties)

+ (NSFetchRequest<DicTrainerMO *> *)fetchRequest {
	return [NSFetchRequest fetchRequestWithEntityName:@"DicTrainer"];
}

@dynamic fio;

@end
