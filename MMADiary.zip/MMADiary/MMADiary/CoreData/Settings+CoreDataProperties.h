//
//  Settings+CoreDataProperties.h
//  MMADiary
//
//  Created by Helen Matveeva on 26/10/2018.
//  Copyright © 2018 Helen Matveeva. All rights reserved.
//
//

#import "Settings+CoreDataClass.h"


NS_ASSUME_NONNULL_BEGIN

@interface Settings (CoreDataProperties)

+ (NSFetchRequest<Settings *> *)fetchRequest;

@property (nonatomic) int16_t goToDicId;
@property (nonatomic) int16_t goToDicRowNum;
@property (nonatomic) int16_t goToRowNumTrainList;
@property (nullable, nonatomic, copy) NSString *isEditTrainList;

@end

NS_ASSUME_NONNULL_END
