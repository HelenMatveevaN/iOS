//
//  DicCell.h
//  TennisTraner2
//
//  Created by Helen Matveeva on 03.05.18.
//  Copyright © 2018 Helen Matveeva. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DicCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UIButton   *TEditButton;
@property (weak, nonatomic) IBOutlet UILabel    *TextShortLabel;
@property (weak, nonatomic) IBOutlet UITextView *TextLongTextView;
@property (weak, nonatomic) IBOutlet UILabel    *isBaseLabel;

@end


