//
//  ViewController.h
//
//  Created by Helen Matveeva on 27.02.18.
//  Copyright © 2018 Helen Matveeva. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>
#import <SystemConfiguration/SystemConfiguration.h>

@interface ViewController : UIViewController <UITextFieldDelegate, UITextViewDelegate, UIPickerViewDelegate, UIPickerViewDataSource/*, CLLocationManagerDelegate, UINavigationControllerDelegate*/>
{

    UIToolbar *toolbarDate;
    UIToolbar *toolbarFIO;
    UIToolbar *toolbarGOAL;
    UIToolbar *toolbarRACKET;
    UIToolbar *toolbarSNEAKERS;

    UIDatePicker *datePicker;
    UIPickerView *pickerViewFIO;
    UIPickerView *pickerViewGOAL;
    UIPickerView *pickerViewRACKET;
    UIPickerView *pickerViewSNEAKERS;
}

//поле для datePicker
@property (weak, nonatomic) IBOutlet UITextField *dateSelectionTextField;
@property (weak, nonatomic) IBOutlet UITextField *dateDateSelectionTextField;
//поля для ввода текстового справочного значения
@property (weak, nonatomic) IBOutlet UITextField *fioTextField;
@property (weak, nonatomic) IBOutlet UITextField *goalTextField;
@property (weak, nonatomic) IBOutlet UITextField *racketTextField;
@property (weak, nonatomic) IBOutlet UITextField *sneakersTextField;

//поля для ввода цифровых значений (picker не вызывается)
@property (weak, nonatomic) IBOutlet UITextField *pulseBeforeTextField;
@property (weak, nonatomic) IBOutlet UITextField *pulseAfterTextField;
@property (weak, nonatomic) IBOutlet UILabel     *tennisDayNumLabel;
@property (weak, nonatomic) IBOutlet UITextField *pressUpTextField;
@property (weak, nonatomic) IBOutlet UITextField *pressLowTextField;
@property (weak, nonatomic) IBOutlet UITextView  *saidOnTheCortTextView;

//Buttons
@property (weak, nonatomic) IBOutlet UIButton *MyMethodic1ButtonOutlet;
@property (weak, nonatomic) IBOutlet UIButton *MyMethodic2ButtonOutlet;
@property (weak, nonatomic) IBOutlet UIButton *MyMethodic3ButtonOutlet;
@property (weak, nonatomic) IBOutlet UIButton *HelpButtonOutlet;
@property (weak, nonatomic) IBOutlet UIButton *DicButtonTrainerOutlet;
@property (weak, nonatomic) IBOutlet UIButton *DicButtonGoalOutlet;
@property (weak, nonatomic) IBOutlet UIButton *DicButtonRacketOutlet;
@property (weak, nonatomic) IBOutlet UIButton *DicButtonSneakersOutlet;
@property (weak, nonatomic) IBOutlet UIButton *DicButtonMyMethodicsOutlet;
@property (weak, nonatomic) IBOutlet UIButton *BtnNewDayOutlet;
@property (weak, nonatomic) IBOutlet UIButton *BtnSaveDayOutlet;
@property (weak, nonatomic) IBOutlet UIButton *BtnViewTDaysOutlet;

@property (weak, nonatomic) IBOutlet UIScrollView *ScrollView;

//labels with different fonts
@property (weak, nonatomic) IBOutlet UILabel *trainerLabel;
@property (weak, nonatomic) IBOutlet UILabel *dateTimeLabel;
@property (weak, nonatomic) IBOutlet UILabel *pressureLabel;
@property (weak, nonatomic) IBOutlet UILabel *pulseLabel;
@property (weak, nonatomic) IBOutlet UILabel *goalLabel;
@property (weak, nonatomic) IBOutlet UILabel *methodicsTypeLabel;
@property (weak, nonatomic) IBOutlet UILabel *myMethodicsLabel;
@property (weak, nonatomic) IBOutlet UILabel *saidLabel;
@property (weak, nonatomic) IBOutlet UILabel *racketLabel;
@property (weak, nonatomic) IBOutlet UILabel *sneakersLabel;

@end

