//
//  TennisDetailVC.m
//  TennisTraner2
//
//  Created by iMac on 11.04.2018.
//  Copyright © 2018 Helen Matveeva. All rights reserved.
//
#import "AppDelegate.h"
#import "TennisDetailVC.h"
#import "Params.h"

@interface TennisDetailVC () {
    
    //нужно для работы с CoreData - взято из https://www.youtube.com/watch?v=gNuXTJoBTEM
    AppDelegate *appDelegate;
    NSManagedObjectContext *context;

    //объявляем динамические (NSMutableArray) массивы
    NSMutableArray *g_dictFIO;
    NSMutableArray *g_dictGOAL;
    NSMutableArray *g_dictRACKET;
    NSMutableArray *g_dictSNEAKERS;
    
    NSArray *g_dictFIO_sorted;
    NSArray *g_dictGOAL_sorted;
    NSArray *g_dictRACKET_sorted;
    NSArray *g_dictSNEAKERS_sorted;
    
    int g_numFIO;
    int g_numGOAL;
    int g_numRACKET;
    int g_numSNEAKERS;
    
    int g_dicIdFIO;
    int g_dicIdGOAL;
    int g_dicIdRACKET;
    int g_dicIdSNEAKERS;
    
    NSString *g_isIpad;
    
    NSString *g_selectedString; //выбранная статья в pickerView
    
    NSArray *arrayDicFieldMsg;
    NSArray *arrayDicNamesTech;      //тех.название справочника
    NSArray *arrayDicNamesFieldTech;
    
    NSString *g_FIOstr;
    NSString *g_GOALstr;
    NSString *g_RACKETstr;
    NSString *g_SNEAKERSstr;
    
    NSDateFormatter *g_formatter;
    NSDateFormatter *g_formatterDateToStr;
    
    Params *params;
}

@end

@implementation TennisDetailVC

@synthesize fioStrTextField, tNumTextField, tDateTextField, tDateDateTextField, tPressUpTextField, tPressLowTextField, tPulseBeforeTextField, tPulseAfterTextField, goalStrTextField, saidOnTheCortTextView, racketStrTextField, sneakersStrTextField;
@synthesize selectedRow, tNumStrVar, tfioStrVar, tdateStrVar, tdateDateVar, tgoalStrVar, tPressUpStrVar, tsaidStrVar, tPressLowStrVar, tPulseAfterStrVar, tPulseBeforeStrVar, tracketStrVar, tsneakersStrVar;
@synthesize ScrollView;
@synthesize sneakersLabel, pressureLabel, racketLabel, saidLabel, trainerLabel, pulseLabel, goalLabel, dateTimeLabel, titleLabel, BtnBackOutlet, BtnSaveOutlet;

//--MARK: View ---------------------
- (void)viewWillAppear:(BOOL)animated{
    NSLog(@"----------TennisDetailVC (viewWillAppear)------------");
    
    [super viewWillAppear:NO];
    
    //iPad?
    params = [[Params alloc] init];
    [params getUserInterfaceIdiom];
    g_isIpad = params -> isIPad;
    
    int     l_fontSizeLabel = 22;
    int     l_fontSizeTexts = 20;
    if ([g_isIpad isEqualToString:@"Y"]){
        
        [titleLabel      setFont:[titleLabel.font fontWithSize:20]];
        
        [sneakersLabel   setFont:[sneakersLabel.font fontWithSize:l_fontSizeLabel]];
        [pressureLabel   setFont:[pressureLabel.font fontWithSize:l_fontSizeLabel]];
        [racketLabel     setFont:[racketLabel.font fontWithSize:l_fontSizeLabel]];
        [saidLabel       setFont:[saidLabel.font fontWithSize:l_fontSizeLabel]];
        [trainerLabel    setFont:[trainerLabel.font fontWithSize:l_fontSizeLabel]];
        [pulseLabel      setFont:[pulseLabel.font fontWithSize:l_fontSizeLabel]];
        [goalLabel       setFont:[goalLabel.font fontWithSize:l_fontSizeLabel]];
        [dateTimeLabel   setFont:[dateTimeLabel.font fontWithSize:l_fontSizeLabel]];
        
        [BtnSaveOutlet.titleLabel setFont:[BtnSaveOutlet.titleLabel.font fontWithSize:25]];
        [BtnBackOutlet.titleLabel  setFont:[BtnBackOutlet.titleLabel.font fontWithSize:20]];
        
        [tNumTextField   setFont:[tNumTextField.font fontWithSize:l_fontSizeTexts]];
        [fioStrTextField setFont:[fioStrTextField.font fontWithSize:l_fontSizeTexts]];
        [goalStrTextField setFont:[goalStrTextField.font fontWithSize:l_fontSizeTexts]];
        [tPressUpTextField setFont:[tPressUpTextField.font fontWithSize:l_fontSizeTexts]];
        [tPressLowTextField setFont:[tPressLowTextField.font fontWithSize:l_fontSizeTexts]];
        [tPulseAfterTextField setFont:[tPulseAfterTextField.font fontWithSize:l_fontSizeTexts]];
        [tPulseBeforeTextField setFont:[tPulseBeforeTextField.font fontWithSize:l_fontSizeTexts]];
        [racketStrTextField setFont:[racketStrTextField.font fontWithSize:l_fontSizeTexts]];
        [sneakersStrTextField setFont:[sneakersStrTextField.font fontWithSize:l_fontSizeTexts]];
        [saidOnTheCortTextView setFont:[saidOnTheCortTextView.font fontWithSize:l_fontSizeTexts]];
        [tDateTextField setFont:[tDateTextField.font fontWithSize:l_fontSizeTexts]];
    }
}

- (void)viewDidLoad {
    NSLog(@"----------TennisDetailVC (viewDidLoad)------------");
    
    [super viewDidLoad];
    
    g_formatter=[[NSDateFormatter alloc]init];
    [g_formatter setDateFormat:@"dd MMMM YYYY EEEE; HH:mm"];
    g_formatterDateToStr =[[NSDateFormatter alloc]init];
    [g_formatterDateToStr setDateFormat:@"yyyy/MM/dd HH-mm-ss"];
    
    //константы, используемые в приложении
    g_FIOstr = @"FIO";
    g_GOALstr = @"GOAL";
    g_RACKETstr = @"RACKET";
    g_SNEAKERSstr = @"SNEAKERS";
    
    //инициализация переменных]
    Params *params = [[Params alloc] init];
    [params setArrayDicNamesTech];
    [params setArrayDicFieldMsg]; //сообщения для создания новых статей в словаре
    [params setArrayDicFieldNamesTech];
    arrayDicNamesTech  = params -> arrayDicNamesTech;
    arrayDicFieldMsg   = params -> arrayDicFieldMsg;
    arrayDicNamesFieldTech = params -> arrayDicFieldNamesTech;

    /*
     номера кнопок вызова справочника:
     0 тренер
     1 цель
     3 мои методики
     4 ракетка
     5 кроссовки
     */
    g_dicIdFIO      = 0;
    g_dicIdGOAL     = 1;
    g_dicIdRACKET   = 3;
    g_dicIdSNEAKERS = 4;
    
    [self loadDicsFromCoreData];

    // Do any additional setup after loading the view.
    fioStrTextField.text = tfioStrVar;
    tNumTextField.text = tNumStrVar;
    tDateTextField.text = tdateStrVar;
    tDateDateTextField.text = [g_formatterDateToStr stringFromDate:tdateDateVar];
    tPressUpTextField.text = tPressUpStrVar;
    tPressLowTextField.text = tPressLowStrVar ;
    tPulseBeforeTextField.text = tPulseBeforeStrVar ;
    tPulseAfterTextField.text = tPulseAfterStrVar ;
    goalStrTextField.text = tgoalStrVar;
    saidOnTheCortTextView.text = tsaidStrVar;
    racketStrTextField.text = tracketStrVar;
    sneakersStrTextField.text = tsneakersStrVar;
    
    //=================================================================== viewDidLoad
    //set the delegate
    self.tPressUpTextField.delegate = self;
    self.tPressLowTextField.delegate = self;
    self.tPulseBeforeTextField.delegate = self;
    self.tPulseAfterTextField.delegate = self;
    self.saidOnTheCortTextView.delegate = self;
    
    //готовим picker-------------------------------------------------------viewDidLoad
    //pickerView
    datePicker=[[UIDatePicker alloc]init];
    datePicker.datePickerMode = UIDatePickerModeDateAndTime;
    
    pickerViewFIO = [[UIPickerView alloc] init];
    pickerViewFIO.delegate = self;
    pickerViewFIO.dataSource = self;
    pickerViewFIO.showsSelectionIndicator = YES;
    pickerViewFIO.tag = g_dicIdFIO;
    
    pickerViewGOAL = [[UIPickerView alloc] init];
    pickerViewGOAL.delegate = self;
    pickerViewGOAL.dataSource = self;
    pickerViewGOAL.showsSelectionIndicator = YES;
    pickerViewGOAL.tag = g_dicIdGOAL;
    
    pickerViewRACKET = [[UIPickerView alloc] init];
    pickerViewRACKET.delegate = self;
    pickerViewRACKET.dataSource = self;
    pickerViewRACKET.showsSelectionIndicator = YES;
    pickerViewRACKET.tag = g_dicIdRACKET;
    
    pickerViewSNEAKERS = [[UIPickerView alloc] init];
    pickerViewSNEAKERS.delegate = self;
    pickerViewSNEAKERS.dataSource = self;
    pickerViewSNEAKERS.showsSelectionIndicator = YES;
    pickerViewSNEAKERS.tag = g_dicIdSNEAKERS;

    //=========================================================================viewDidLoad - ToolBar-s + PickerView
    UIBarButtonItem *flexibleSpaceLeft = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
    UIColor         *backGroundColor   = [UIColor colorWithRed:5.0/255.0 green:110.0/255.0 blue:170.0/255.0 alpha:1];
    UIColor         *tintColor         = [UIColor whiteColor];
    
    //создаем ToolBar с кнопками, на который добавляем и datePicker
    toolbarDate = [[UIToolbar alloc]init];
    [toolbarDate sizeToFit];
    UIBarButtonItem *selectDateBtn =
    [
     [UIBarButtonItem alloc]initWithTitle:
     NSLocalizedString(@"Choose date-time", @"Choose date-time comment") style:UIBarButtonItemStyleDone target:self action:@selector(ShowSelectedDateTennDet)];
    
    selectDateBtn.tintColor = tintColor;
    toolbarDate.backgroundColor = backGroundColor;
    [toolbarDate setItems:[NSArray arrayWithObjects:flexibleSpaceLeft, selectDateBtn , nil]];
    [self.tDateTextField setInputAccessoryView:toolbarDate];
    self.tDateTextField.inputView = datePicker;
    [self.tDateDateTextField setInputAccessoryView:toolbarDate];
    self.tDateDateTextField.inputView = datePicker;
    
    toolbarFIO = [[UIToolbar alloc]init];
    [toolbarFIO sizeToFit];
    UIBarButtonItem *selectFIOBtn =
    [
     [UIBarButtonItem alloc]initWithTitle:
     NSLocalizedString(@"Choose coacher", @"Choose coacher comment")
     style:UIBarButtonItemStyleDone target:self action:@selector(ShowSelectedTextFIO:)];
    selectFIOBtn.tintColor = tintColor;
    UIBarButtonItem *AddFIOBtn =
    [
     [UIBarButtonItem alloc]initWithTitle:
     NSLocalizedString(@"New", @"New comment")
     style:UIBarButtonItemStyleDone target:self action:@selector(NewDicTextFIO)];
    
    AddFIOBtn.tintColor = tintColor;
    toolbarFIO.backgroundColor = backGroundColor;
    [toolbarFIO setItems:[NSArray arrayWithObjects:flexibleSpaceLeft, selectFIOBtn , AddFIOBtn, nil]];
    [self.fioStrTextField setInputAccessoryView:toolbarFIO];
    self.fioStrTextField.inputView = pickerViewFIO;
    
    toolbarGOAL = [[UIToolbar alloc]init];
    [toolbarGOAL sizeToFit];
    UIBarButtonItem *selectGOALBtn =
    [
     [UIBarButtonItem alloc]initWithTitle:
     NSLocalizedString(@"Choose goal", @"Choose goal comment")
     style:UIBarButtonItemStyleDone target:self action:@selector(ShowSelectedTextGOAL:)];
    
    selectGOALBtn.tintColor = tintColor;
    UIBarButtonItem *AddGOALBtn =
    [
     [UIBarButtonItem alloc]initWithTitle:
     NSLocalizedString(@"New", @"New comment")
     style:UIBarButtonItemStyleDone target:self action:@selector(NewDicTextGOAL)];
    
    AddGOALBtn.tintColor = tintColor;
    toolbarGOAL.backgroundColor = backGroundColor;
    [toolbarGOAL setItems:[NSArray arrayWithObjects:flexibleSpaceLeft, selectGOALBtn , AddGOALBtn, nil]];
    [self.goalStrTextField setInputAccessoryView:toolbarGOAL];
    self.goalStrTextField.inputView = pickerViewGOAL;
    
    toolbarRACKET = [[UIToolbar alloc]init];
    [toolbarRACKET sizeToFit];
    UIBarButtonItem *selectRACKETBtn =
    [
     [UIBarButtonItem alloc]initWithTitle:
     NSLocalizedString(@"Choose protection", @"Choose protection comment")
     style:UIBarButtonItemStyleDone target:self action:@selector(ShowSelectedTextRACKET:)];
    
    selectRACKETBtn.tintColor = tintColor;
    UIBarButtonItem *AddRACKETBtn =
    [
     [UIBarButtonItem alloc]initWithTitle:
     NSLocalizedString(@"New", @"New comment")
     style:UIBarButtonItemStyleDone target:self action:@selector(NewDicTextRACKET)];
    
    AddRACKETBtn.tintColor = tintColor;
    toolbarRACKET.backgroundColor = backGroundColor;
    [toolbarRACKET setItems:[NSArray arrayWithObjects:flexibleSpaceLeft, selectRACKETBtn , AddRACKETBtn, nil]];
    [self.racketStrTextField setInputAccessoryView:toolbarRACKET];
    self.racketStrTextField.inputView = pickerViewRACKET;
    
    toolbarSNEAKERS = [[UIToolbar alloc]init];
    [toolbarSNEAKERS sizeToFit];
    UIBarButtonItem *selectSNEAKERSBtn =
    [
     [UIBarButtonItem alloc]initWithTitle:
     NSLocalizedString(@"Choose training gloves", @"Choose training gloves comment")
     style:UIBarButtonItemStyleDone target:self action:@selector(ShowSelectedTextSNEAKERS:)];
    
    selectSNEAKERSBtn.tintColor = tintColor;
    UIBarButtonItem *AddSNEAKERSBtn =
    [
     [UIBarButtonItem alloc]initWithTitle:
     NSLocalizedString(@"New", @"New comment")
     style:UIBarButtonItemStyleDone target:self action:@selector(NewDicTextSNEAKERS)];
    
    AddSNEAKERSBtn.tintColor = tintColor;
    toolbarSNEAKERS.backgroundColor = backGroundColor;
    [toolbarSNEAKERS setItems:[NSArray arrayWithObjects:flexibleSpaceLeft, selectSNEAKERSBtn , AddSNEAKERSBtn, nil]];
    [self.sneakersStrTextField setInputAccessoryView:toolbarSNEAKERS];
    self.sneakersStrTextField.inputView = pickerViewSNEAKERS;
    //=========================================================================

    //распознавание жеста
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(dismissKeyboard)];
    [self.view addGestureRecognizer:tap];
} //viewDidLoad

-(void)viewWillLayoutSubviews{
    NSLog(@"----------TennisDetailVC (viewWillLayoutSubviews)------------");
    
    [super viewWillLayoutSubviews];
    //прокрутка textview вверх
    [saidOnTheCortTextView setContentOffset:CGPointZero animated:NO];
}

//--MARK: pickerView ---------------------
//PickerView
- (NSInteger)numberOfComponentsInPickerView:(nonnull UIPickerView *)pickerView {
    NSLog(@"----------TennisDetailVC (pickerView numberOfComponentsInPickerView)------------");
    return 1;
}

- (NSInteger)pickerView:(nonnull UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component {
    NSLog(@"----------TennisDetailVC (pickerView numberOfRowsInComponent)------------");
    
    int num = 0;
    g_selectedString = @"";
    
    if (pickerView.tag == g_dicIdFIO)
    {   num = g_numFIO;  if (g_dictFIO.count > 0) {g_selectedString = g_dictFIO[0]; } }
    
    if (pickerView.tag == g_dicIdGOAL)
    {   num = g_numGOAL; if (g_dictGOAL.count > 0) {g_selectedString = g_dictGOAL[0];} }
    
    if (pickerView.tag == g_dicIdRACKET)
    {   num = g_numRACKET; if (g_dictRACKET.count > 0) {g_selectedString = g_dictRACKET[0];} }
    
    if (pickerView.tag == g_dicIdSNEAKERS)
    {   num = g_numSNEAKERS; if (g_dictSNEAKERS.count > 0) {g_selectedString = g_dictSNEAKERS[0];} }
    
    if ([g_selectedString isEqualToString:@""]) {g_selectedString = @"...";}
    
    return num;
}

- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component {
    NSLog(@"----------TennisDetailVC (pickerView titleForRow)------------");
    
    if (pickerView.tag == g_dicIdFIO)      { g_selectedString = g_dictFIO_sorted[row];      }
    if (pickerView.tag == g_dicIdGOAL)     { g_selectedString = g_dictGOAL_sorted[row];     }
    if (pickerView.tag == g_dicIdRACKET)   { g_selectedString = g_dictRACKET_sorted[row];   }
    if (pickerView.tag == g_dicIdSNEAKERS) { g_selectedString = g_dictSNEAKERS_sorted[row]; }
    
    return g_selectedString;
}

- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component {
    NSLog(@"----------TennisDetailVC (pickerView didSelectRow)------------");
    
    if (pickerView.tag == g_dicIdFIO)      {g_selectedString = g_dictFIO_sorted[row];     }
    if (pickerView.tag == g_dicIdGOAL)     {g_selectedString = g_dictGOAL_sorted[row];    }
    if (pickerView.tag == g_dicIdRACKET)   {g_selectedString = g_dictRACKET_sorted[row];  }
    if (pickerView.tag == g_dicIdSNEAKERS) {g_selectedString = g_dictSNEAKERS_sorted[row];}
}

//--MARK: ShowSelected ---------------------
//обработка datepicker =================================================================
//используется для datePicker-а
- (void)ShowSelectedDateTennDet{
    NSLog(@"----------TennisDetailVC (ShowSelectedDate)------------");
    
    self.tDateTextField.text     = [NSString stringWithFormat:@"%@",[g_formatter stringFromDate:datePicker.date]];
    self.tDateDateTextField.text = [g_formatterDateToStr stringFromDate:datePicker.date];
    [self.tDateTextField resignFirstResponder];//убрать клавиатуру
}

//используется для pickerView
- (void)ShowSelectedTextFIO:(id)sender{
    NSLog(@"----------TennisDetailVC (ShowSelectedTextFIO)------------");
    self.fioStrTextField.text = g_selectedString; [self ShowSelectedText:g_FIOstr];
}
- (void)ShowSelectedTextGOAL:(id)sender{
    NSLog(@"----------TennisDetailVC (ShowSelectedTextGOAL)------------");
    self.goalStrTextField.text = g_selectedString; [self ShowSelectedText:g_GOALstr];
}
- (void)ShowSelectedTextRACKET:(id)sender{
    NSLog(@"----------TennisDetailVC (ShowSelectedTextRACKET)------------");
    self.racketStrTextField.text = g_selectedString;[self ShowSelectedText:g_RACKETstr];
}
- (void)ShowSelectedTextSNEAKERS:(id)sender{
    NSLog(@"----------TennisDetailVC (ShowSelectedTextSNEAKERS)------------");
    self.sneakersStrTextField.text = g_selectedString; [self ShowSelectedText:g_SNEAKERSstr];
}
//-----------
- (void)ShowSelectedText:(NSString*) thema {
    NSLog(@"----------TennisDetailVC (ShowSelectedText)------------");
    [self leftStringFieldsDismissKeyboard]; //скрыть клавиатуру
}

//MARK: NewDic ============================
- (void)NewDicTextFIO      { [self NewDicText: g_FIOstr];      } //вызов для ФИО - FIO
- (void)NewDicTextGOAL     { [self NewDicText: g_GOALstr];     } //вызов для Цели - Goal
- (void)NewDicTextRACKET   { [self NewDicText: g_RACKETstr];   }
- (void)NewDicTextSNEAKERS { [self NewDicText: g_SNEAKERSstr]; }

//ДОБАВЛЯЕМ НОВУЮ СЛОВАРНУЮ СТАТЬЮ В ТАБЛИЦУ ---------------
- (void) NewDicText: (NSString*) thema {
    NSLog(@"----------TennisDetailVC (NewDicText)------------");
    
    //скрываем клавиатуру
    [self leftStringFieldsDismissKeyboard];
    NSString *str = NSLocalizedString(@"Set a new value", @"Set a new value comment");
    
    //Alert Controller с кнопками и полем для ввода данных в справочник (ДОБАВИТЬ ДАННЫЕ В СПРАВОЧНИК)
    UIAlertController* alert = [UIAlertController alertControllerWithTitle:str
     message:@""
     preferredStyle:UIAlertControllerStyleAlert //стиль кнопок - только для этого стиля можно добавить текстовое поле в Alert
    ];
    
    //добавить текстовое поле в справочник из alert
    [alert addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
        int k = 0;
        if ([thema  isEqual: self->g_FIOstr])      { k = self->g_dicIdFIO; }
        if ([thema  isEqual: self->g_GOALstr])     { k = self->g_dicIdGOAL; }
        if ([thema  isEqual: self->g_RACKETstr])   { k = self->g_dicIdRACKET; }
        if ([thema  isEqual: self->g_SNEAKERSstr]) { k = self->g_dicIdSNEAKERS; }
        textField.placeholder = self->arrayDicFieldMsg[k][0];
    }];
    
    //добавить доп.текстовое поле для справочников Ракетка/Кроссовки
    if ([thema  isEqual: g_RACKETstr] || [thema  isEqual: g_SNEAKERSstr]) {
        [alert addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
            int k = 0;
            if ([thema  isEqual: self->g_RACKETstr])   { k = self->g_dicIdRACKET; }
            if ([thema  isEqual: self->g_SNEAKERSstr]) { k = self->g_dicIdSNEAKERS; }
            textField.placeholder = self->arrayDicFieldMsg[k][1];
        }];
    }
    
    UIAlertAction* actionAdd = [UIAlertAction
     actionWithTitle: NSLocalizedString(@"Add", @"Add comment")
     style:UIAlertActionStyleDefault
     handler:^(UIAlertAction * action)
    {
        //добавить новую статью в справочник
        
        //Get Context
        self->appDelegate = (AppDelegate *)[[UIApplication sharedApplication]delegate];
        self->context = self->appDelegate.persistentContainer.viewContext;
        
        //значение из текстового поля алерта
        NSString *newVal = alert.textFields[0].text;
        NSString *newValDop = @"";
        if ([thema  isEqual: self->g_RACKETstr] || [thema  isEqual: self->g_SNEAKERSstr]) {
            newValDop = alert.textFields[1].text;
        }
        
        int k = 0;
        if ([thema  isEqual: self->g_FIOstr])      { k = self->g_dicIdFIO; }
        if ([thema  isEqual: self->g_GOALstr])     { k = self->g_dicIdGOAL; }
        if ([thema  isEqual: self->g_RACKETstr])   { k = self->g_dicIdRACKET; }
        if ([thema  isEqual: self->g_SNEAKERSstr]) { k = self->g_dicIdSNEAKERS; }
        
        if (k > -1) {
            //Save Data
            NSManagedObject *entityObj = [NSEntityDescription insertNewObjectForEntityForName: self->arrayDicNamesTech[k] inManagedObjectContext:self->context];
            [entityObj setValue: newVal forKey:self->arrayDicNamesFieldTech[k][0]]; //добавила в справочник значение из Alert
            
            //Save Data
            if ([thema  isEqual: self->g_FIOstr]) {
                [self->g_dictFIO addObject:(newVal)];
                self->g_numFIO = self->g_numFIO+1;
                self.fioStrTextField.text = newVal;
            }
            
            if ([thema  isEqual: self->g_GOALstr]) {
                [self->g_dictGOAL addObject:(newVal)];
                self->g_numGOAL = self->g_numGOAL+1;
                self.goalStrTextField.text = newVal;
            }
            
            if ([thema  isEqual: self->g_RACKETstr] || [thema  isEqual: self->g_SNEAKERSstr]) {
                [entityObj setValue: newValDop forKey:self->arrayDicNamesFieldTech[k][1]];
                
                //добавить в массив новый элемент
                NSString *str = @"";
                str = [newVal stringByAppendingString:@" / "];
                str = [str stringByAppendingString: newValDop];
                
                if ([thema  isEqual: self->g_RACKETstr]){
                    [self->g_dictRACKET addObject:(str)];
                    self->g_numRACKET = self->g_numRACKET+1;
                    self.racketStrTextField.text = str;
                }
                
                if ([thema  isEqual: self->g_SNEAKERSstr]){
                    [self->g_dictSNEAKERS addObject:(str)];
                    self->g_numSNEAKERS = self->g_numSNEAKERS+1;
                    self.sneakersStrTextField.text = str;
                }
            }
            
            //сортируем массивы по алфавиту
            [self sortedDicArrays];
            
            //save data
            [self->appDelegate saveContext];
        }
    }];
    
    UIAlertAction* actionCancel =
    [UIAlertAction actionWithTitle:
     NSLocalizedString(@"Cancel", @"Cancel comment")
                             style:UIAlertActionStyleCancel
                           handler:^(UIAlertAction * action) {}];
    
    [alert addAction:actionAdd];
    [alert addAction:actionCancel];
    
    [self presentViewController:alert animated:YES completion:nil];
}

//--MARK: CoreData -------------------------
-(void)loadDicsFromCoreData {
    NSLog(@"----------TennisDetailVC (loadFromCoreData)------------");
    //загрузка справочника FIO в массив
    //Get Context
    appDelegate = (AppDelegate *)[[UIApplication sharedApplication]delegate];
    context = appDelegate.persistentContainer.viewContext;
    
    //Fetch (Load) Data ********************************
    NSFetchRequest *requestExamLocationFIO = [NSFetchRequest fetchRequestWithEntityName:@"DicTrainer"];
    NSArray *resultsFIO = [context executeFetchRequest:requestExamLocationFIO error:nil];
    g_numFIO = (int)resultsFIO.count;
    
    [g_dictFIO removeAllObjects];
    g_dictFIO = [[NSMutableArray alloc]initWithCapacity:1];
    for (int i=0; i<resultsFIO.count; i++) { [g_dictFIO addObject:[[resultsFIO objectAtIndex:i] valueForKey:@"fio"]]; }
    
    //загрузка справочника GOAL в массив
    //Fetch (Load) Data ********************************
    NSFetchRequest *requestExamLocationGOAL = [NSFetchRequest fetchRequestWithEntityName:@"Goals"];
    NSArray *resultsGOAL = [context executeFetchRequest:requestExamLocationGOAL error:nil];
    g_numGOAL = (int)resultsGOAL.count;
    [g_dictGOAL removeAllObjects];
    g_dictGOAL = [[NSMutableArray alloc]initWithCapacity:1];
    for (int i=0; i<resultsGOAL.count; i++) { [g_dictGOAL addObject:[[resultsGOAL objectAtIndex:i] valueForKey:@"descr"]]; }
    
    //загрузка справочника RACKET в массив
    //Fetch (Load) Data ********************************
    NSFetchRequest *requestExamLocationRACKET = [NSFetchRequest fetchRequestWithEntityName:@"DicProtect"];
    NSArray *resultsRACKET = [context executeFetchRequest:requestExamLocationRACKET error:nil];
    g_numRACKET = (int)resultsRACKET.count;
    [g_dictRACKET removeAllObjects];
    g_dictRACKET = [[NSMutableArray alloc]initWithCapacity:1];
    for (int i=0; i<resultsRACKET.count; i++) {
        NSString *str = [[resultsRACKET objectAtIndex:i] valueForKey:@"size"];
        if ([str isEqualToString:@""]) {str = @"-";}
        str = [str stringByAppendingString:@" / "];
        str = [str stringByAppendingString: [[resultsRACKET objectAtIndex:i] valueForKey:@"descr"]];
        [g_dictRACKET addObject: str];
    }
    
    //загрузка справочника SNEAKERS в массив
    //Fetch (Load) Data ********************************
    NSFetchRequest *requestExamLocationSNEAKERS = [NSFetchRequest fetchRequestWithEntityName:@"DicGloves"];
    NSArray *resultsSNEAKERS = [context executeFetchRequest:requestExamLocationSNEAKERS error:nil];
    g_numSNEAKERS = (int)resultsSNEAKERS.count;
    [g_dictSNEAKERS removeAllObjects];
    g_dictSNEAKERS = [[NSMutableArray alloc]initWithCapacity:1];
    for (int i=0; i<resultsSNEAKERS.count; i++) {
        NSString *str = [[resultsSNEAKERS objectAtIndex:i] valueForKey:@"size"];
        if ([str isEqualToString:@""]) {str = @"-";}
        str = [str stringByAppendingString:@" / "];
        str = [str stringByAppendingString: [[resultsSNEAKERS objectAtIndex:i] valueForKey:@"descr"]];
        [g_dictSNEAKERS addObject: str];
    }
    
    //сортируем массивы по алфавиту
    [self sortedDicArrays];
}//============================loadFromCoreData

//--MARK: BUTTONS -------------------------
- (IBAction)BtnSaveTennisDay {
    NSLog(@"----------TennisDetailVC (BtnSaveTennisDay)------------");
    
    //спрашиваем - действительно ли пользователь хочет сохранить новую тренировку?
    
    UIAlertController *alert = [UIAlertController
                                alertControllerWithTitle:
                                NSLocalizedString(@"Do you really want to keep the training?", @"Do you really want to keep the training? comment")
                                message:@""
                                preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *actionYes = [UIAlertAction
                                actionWithTitle:
                                NSLocalizedString(@"Yes", @"Yes comment")
                                style:UIAlertActionStyleDefault
                                handler:^(UIAlertAction * action)
                                {   //сохранить данные о тренировке
                                    [self saveData];
                                }];
    UIAlertAction *actionNo = [UIAlertAction
                               actionWithTitle:
                               NSLocalizedString(@"No", @"No comment")
                               style:UIAlertActionStyleCancel
                               handler:^(UIAlertAction * action) {}];
    [alert addAction:actionYes];
    [alert addAction:actionNo];
    [self presentViewController:alert animated:YES completion:nil];
}

- (IBAction)BtnBack {
    NSLog(@"----------TennisDetailVC (BtnBack)------------");
    //инициализация переменных]
    Params  *params = [[Params alloc] init];
    [params setSettingTennisRow:(int)(selectedRow+1)];
}

//--MARK: OTHERS -------------------------
//Мои методы ============================================================***********************
//покидая поле number, скрываем клавиатуру
-(void)leftNumberFieldsDismissKeyboard {
    NSLog(@"----------TennisDetailVC (leftNumberFieldsDismissKeyboard)------------");
    [self.tPressUpTextField resignFirstResponder];
    [self.tPressLowTextField resignFirstResponder];
    [self.tPulseBeforeTextField resignFirstResponder];
    [self.tPulseAfterTextField resignFirstResponder];
}

//покидая поле String, скрываем клавиатуру
-(void)leftStringFieldsDismissKeyboard {
    NSLog(@"----------TennisDetailVC (leftStringFieldsDismissKeyboard)------------");
    [self.fioStrTextField       resignFirstResponder];
    [self.goalStrTextField      resignFirstResponder];
    [self.saidOnTheCortTextView resignFirstResponder];
    [self.racketStrTextField    resignFirstResponder];
    [self.sneakersStrTextField  resignFirstResponder];
}

//  Hide the keyboard (покидая редактируемый textField)
-(void)dismissKeyboard {
    NSLog(@"----------TennisDetailVC (dismissKeyboard)------------");
    [self.tDateTextField resignFirstResponder];
    [self leftNumberFieldsDismissKeyboard];
    [self leftStringFieldsDismissKeyboard];
}

- (void)didReceiveMemoryWarning {
    NSLog(@"----------TennisDetailVC (didReceiveMemoryWarning)------------");
    
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (void)saveData {
    NSLog(@"----------TennisDetailVC (saveData)------------");
    //Get Context
    appDelegate = (AppDelegate *)[[UIApplication sharedApplication]delegate];
    context = appDelegate.persistentContainer.viewContext;
    
    NSFetchRequest *requestExamLocationTennisHistory = [NSFetchRequest fetchRequestWithEntityName:@"TrainHistory"];
    NSArray *resultsTennisHistory = [context executeFetchRequest:requestExamLocationTennisHistory error:nil];
    NSManagedObject *entityObjTennisHistory = [resultsTennisHistory objectAtIndex:selectedRow];
    
    //записываем в текущую тренировку отредактированные данные
    [entityObjTennisHistory setValue: self.fioStrTextField.text                     forKey: @"fioStr"];
    [entityObjTennisHistory setValue: self.goalStrTextField.text                    forKey: @"goalStr"];
    [entityObjTennisHistory setValue: self.saidOnTheCortTextView.text               forKey: @"saidStr"];
    [entityObjTennisHistory setValue: self.tDateTextField.text                      forKey: @"tDateString"];
    
    NSDate *ldate = [g_formatterDateToStr dateFromString:self.tDateDateTextField.text];
    [entityObjTennisHistory setValue: ldate                                         forKey: @"tDateDate"];

    [entityObjTennisHistory setValue: @([self.tNumTextField.text intValue])         forKey: @"tNum"];
    [entityObjTennisHistory setValue: @([self.tPressUpTextField.text intValue])     forKey: @"tPressUp"];
    [entityObjTennisHistory setValue: @([self.tPressLowTextField.text intValue])    forKey: @"tPressLow"];
    [entityObjTennisHistory setValue: @([self.tPulseBeforeTextField.text intValue]) forKey: @"tPulseBefore"];
    [entityObjTennisHistory setValue: @([self.tPulseAfterTextField.text intValue])  forKey: @"tPulseAfter"];
    [entityObjTennisHistory setValue: self.racketStrTextField.text                  forKey: @"protectStr"];
    [entityObjTennisHistory setValue: self.sneakersStrTextField.text                forKey: @"glovesStr"];
    
    [appDelegate saveContext];
    
    [params setSettingTennisListIsEdit:@"Y"];
}

/*отсортировать массивы*/
-(void) sortedDicArrays {
    NSLog(@"----------TennisDetailVC (sortedArrays)------------");
    g_dictFIO_sorted      = [g_dictFIO      sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
    g_dictGOAL_sorted     = [g_dictGOAL     sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
    g_dictRACKET_sorted   = [g_dictRACKET   sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
    g_dictSNEAKERS_sorted = [g_dictSNEAKERS sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
}

//--MARK: FOR SCROLL -----------------
//создано для редактирования поля "Сказано на корте"
-(void)textViewDidBeginEditing:(UITextView *)textView{
    NSLog(@"----------textViewDidBeginEditing------------");
    //перемещаем скролл (чтобы клавиатура не перекрывала редактируемое поле)
    if (textView == self.saidOnTheCortTextView) {
        [self.ScrollView setContentOffset:CGPointMake(0, 50)];
    }
}

-(void)textViewDidEndEditing:(UITextView *)textView{
    NSLog(@"----------textViewDidEndEditing------------");
    if (textView == self.saidOnTheCortTextView) {
        [self.ScrollView setContentOffset:CGPointMake(0, 0)];
    }
}


@end
