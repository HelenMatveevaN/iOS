//
//  DicCell.m
//  TennisTraner2
//
//  Created by Helen Matveeva on 03.05.18.
//  Copyright © 2018 Helen Matveeva. All rights reserved.
//

#import "DicCell.h"
#import "Params.h"

@implementation DicCell

@synthesize TextShortLabel   = _TextShortLabel;
@synthesize TextLongTextView = _TextLongTextView;
@synthesize isBaseLabel      = _isBaseLabel;
@synthesize TEditButton      = _TEditButton;

- (void)awakeFromNib {
    [super awakeFromNib];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
}

@end
