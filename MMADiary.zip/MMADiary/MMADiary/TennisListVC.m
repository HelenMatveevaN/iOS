//
//  TennisListViewController.m
//  TennisTraner2
//
//  Created by Helen Matveeva on 03.04.18.
//  Copyright © 2018 Helen Matveeva. All rights reserved.
//

#import "AppDelegate.h"
#import "TennisListVC.h"
#import "TennisCell.h"
#import "TennisDetailVC.h"
#import "Params.h"

@interface TennisListVC () {
    //нужно для работы с CoreData
    AppDelegate *appDelegate;
    NSManagedObjectContext *context;
    NSMutableArray *g_arrayTennisHistory;
    
    Boolean viewHasAppeared;
    
    NSInteger g_tennisRowNum;
    NSString *g_SettingTennisListIsEdit;
    
    NSInteger g_arrayTennisHistory_ColumnCnt;
    
    NSString *g_isIpad;
}
@end

@implementation TennisListVC

@synthesize TennisListTableView;
@synthesize titleLabel, BtnBackOutlet;

#pragma mark - View -------------------------------

- (void)viewWillAppear:(BOOL)animated{
    NSLog(@"----------TennisListVC (viewWillAppear)------------");
    [super viewWillAppear:NO];
    
    //iPad?
    Params *params = [[Params alloc] init];
    [params getUserInterfaceIdiom];
    g_isIpad = params -> isIPad;
    
    UIFont *l_font     = titleLabel.font;
    if ([g_isIpad isEqualToString:@"Y"]){
        [titleLabel                 setFont:[l_font fontWithSize:22]];
        [BtnBackOutlet.titleLabel   setFont:[BtnBackOutlet.titleLabel.font fontWithSize:20]];
    }
}

- (void) viewDidLoad {
    NSLog(@"----------TennisListVC (viewDidLoad)------------");
    [super viewDidLoad];
    
    g_arrayTennisHistory_ColumnCnt = 12; //12 полей в таблице тренировок
    viewHasAppeared = FALSE;
    
    self.TennisListTableView.delegate = self;
    self.TennisListTableView.dataSource = self;
    
    [self loadFromCoreData];
    
    Params *params = [[Params alloc] init];
    [params getSettingsTennisList];
    g_SettingTennisListIsEdit = params -> settingsTennisListIsEdit;
    if ([g_SettingTennisListIsEdit isEqual: @"Y"]) {
        [self sortTennisList];
    }

} //--viewDidLoad

- (void) viewDidAppear:(BOOL)animated {
    NSLog(@"----------TennisListVC (viewDidAppear)------------");
    [super viewDidAppear:animated];
    viewHasAppeared = TRUE;
}

- (void) viewDidLayoutSubviews{
    NSLog(@"----------TennisListVC (viewDidLayoutSubviews)------------");
    [super viewDidLayoutSubviews];
    if (viewHasAppeared == FALSE) { [self tableViewScrollToBottomAnimated:NO];}
}

#pragma mark - UITableView
- (NSInteger)tableView:(nonnull UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    NSLog(@"----------TennisListVC (tableView numberOfRowsInSection)------------");
    return g_arrayTennisHistory.count;
}

- (nonnull UITableViewCell *)tableView:(nonnull UITableView *)tableView cellForRowAtIndexPath:(nonnull NSIndexPath *)indexPath {
    NSLog(@"----------TennisListVC (tableView cellForRowAtIndexPath)------------");
    
    static NSString *tennisTableId = @"TennisCell";
    TennisCell *cell = (TennisCell *)[tableView dequeueReusableCellWithIdentifier:tennisTableId];
    
    if (cell == nil) {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"TennisCell" owner:self options:nil];
        cell = [nib objectAtIndex:0];
    }
    
    /*
     0-fioStr; String
     1-goalStr; String
     2-saidStr; String
     3-tDateString; String
     4-tDateDate
     5-tNum; int
     6-tPressLow; int
     7-tPressUp; int
     8-tPulseBefore; int
     9-tPulseAfter; int
     10-racketStr; String
     11-sneakersStr; String
     */
    
    NSString *str = @"";

    str = [NSLocalizedString(@"Coacher name: ", @"Coacher name: comment")
           stringByAppendingString:g_arrayTennisHistory[indexPath.row][0]];
    cell.TFioLabel.text = str;
    
    str = [//@"Цель: "
           NSLocalizedString(@"Goal: ", @"Goal: comment")
           stringByAppendingString: g_arrayTennisHistory[indexPath.row][1]];
    cell.tGoalLabel.text = str;

    str = [//@"Сказано на корте: "
           NSLocalizedString(@"Said in training: ", @"Said in training: comment")
           stringByAppendingString: g_arrayTennisHistory[indexPath.row][2]];
    cell.tSaidLabel.text = str;

    str = [//@"Дата: "
           NSLocalizedString(@"Date: ", @"Date: comment")
           stringByAppendingString:  g_arrayTennisHistory[indexPath.row][3]];
    cell.TDateLabel.text = str;
    
    cell.tNumLabel.text = [[g_arrayTennisHistory[indexPath.row][5] stringValue] stringByAppendingString:
                           NSLocalizedString(@" training day", @" training day")
                           //@"й день тренировки"
                           ];
    
    str = [//@"Давление: "
           NSLocalizedString(@"Pressure: ", @"Pressure: comment")
           stringByAppendingString: [g_arrayTennisHistory[indexPath.row][7] stringValue] ];
    str = [str stringByAppendingString:
           //@" на "
           NSLocalizedString(@" to ", @" to comment")
           ];
    str = [str stringByAppendingString: [g_arrayTennisHistory[indexPath.row][6] stringValue]  ];
    cell.tPressLabel.text = str;
    
    str = [//@"Пульс (до/после) тренировки: "
           NSLocalizedString(@"Pulse (before/after) training: ", @"Pulse (before/after) training: comment")
           stringByAppendingString: [g_arrayTennisHistory[indexPath.row][8] stringValue]];
    str = [str stringByAppendingString:@" / "];
    str = [str stringByAppendingString: [g_arrayTennisHistory[indexPath.row][9] stringValue]];
    cell.tPulseLabel.text = str;
    
    str = [//@"Ракетка: "
           NSLocalizedString(@"Racket: ", @"Racket: comment")
           stringByAppendingString: g_arrayTennisHistory[indexPath.row][10]];
    cell.tRacketLabel.text = str;
   
    str = [//@"Кроссовки: "
           NSLocalizedString(@"Training gloves: ", @"Training gloves: ")
           stringByAppendingString: g_arrayTennisHistory[indexPath.row][11]];
    cell.tSneakersLabel.text = str;
    
    cell.tEditButton.tag = indexPath.row;
    
    //iPad?
    Params *params = [[Params alloc] init];
    [params getUserInterfaceIdiom];
    g_isIpad = params -> isIPad;
    
    if ([g_isIpad isEqualToString:@"Y"]){
        [cell.TFioLabel setFont:[cell.TFioLabel.font fontWithSize:18]];
        [cell.TDateLabel setFont:[cell.TDateLabel.font fontWithSize:18]];
        [cell.tNumLabel setFont:[cell.tNumLabel.font fontWithSize:18]];
        [cell.tPressLabel setFont:[cell.tPressLabel.font fontWithSize:18]];
        [cell.tPulseLabel setFont:[cell.tPulseLabel.font fontWithSize:18]];
        [cell.tGoalLabel setFont:[cell.tGoalLabel.font fontWithSize:18]];
        [cell.tSaidLabel setFont:[cell.tSaidLabel.font fontWithSize:18]];
        [cell.tRacketLabel setFont:[cell.tRacketLabel.font fontWithSize:18]];
        [cell.tSneakersLabel setFont:[cell.tSneakersLabel.font fontWithSize:18]];
        [cell.tEditButton.titleLabel setFont:[cell.tEditButton.titleLabel.font fontWithSize:18]];
    }
    
    return cell;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    NSLog(@"----------TennisListVC (tableView editingStyle)------------");
    
    if (editingStyle==UITableViewCellEditingStyleDelete) {
        
        NSFetchRequest *requestExamLocationTennisHistory = [NSFetchRequest fetchRequestWithEntityName:@"TrainHistory"];
        NSArray *resultsTennisHistory = [context executeFetchRequest:requestExamLocationTennisHistory error:nil];
        
        //удаление из coredata
        NSManagedObject *entityObj = [resultsTennisHistory objectAtIndex:indexPath.row];
        [context deleteObject:entityObj];
        [appDelegate saveContext];
        
        //удаление из массива
        [g_arrayTennisHistory removeObjectAtIndex:indexPath.row];
        
        //удаление из таблицы
        [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath]  withRowAnimation:UITableViewRowAnimationFade];
        
        //пересчитать сквозной нумерации тренировок
        [self loadFromCoreData];
        [self sortTennisList];
    }
}

//отсортировать теннисные тренировки
- (void) sortTennisList{
    NSLog(@"----------TennisListVC (reCheckTennisNum)------------");
    
    NSString * FIOSTR       = @"fioStr";
    NSString * GOALSTR      = @"goalStr";
    NSString * SAIDSTR      = @"saidStr";
    NSString * TDATESTRING  = @"tDateString";
    NSString * TDATEDATE    = @"tDateDate";
    NSString * TNUM         = @"tNum";
    NSString * TPRESSLOW    = @"tPressLow";
    NSString * TPRESSUP     = @"tPressUp";
    NSString * TPULSEBEFORE = @"tPulseBefore";
    NSString * TPULSEAFTER  = @"tPulseAfter";
    NSString * RACKETSTR    = @"protectStr";
    NSString * SNEAKERSSTR  = @"glovesStr";
    
    //сортировка NSMutableArray resultsTennisHistory по дате
    NSMutableArray * arraySorted = [NSMutableArray array];
    NSDictionary * dict;
    
    for (int i = 0; i<g_arrayTennisHistory.count; i++) {
        dict = [NSDictionary dictionaryWithObjectsAndKeys:
                g_arrayTennisHistory[i][0],  FIOSTR,
                g_arrayTennisHistory[i][1],  GOALSTR,
                g_arrayTennisHistory[i][2],  SAIDSTR,
                g_arrayTennisHistory[i][3],  TDATESTRING,
                g_arrayTennisHistory[i][4],  TDATEDATE,
                g_arrayTennisHistory[i][5],  TNUM,
                g_arrayTennisHistory[i][6],  TPRESSLOW,
                g_arrayTennisHistory[i][7],  TPRESSUP,
                g_arrayTennisHistory[i][8],  TPULSEBEFORE,
                g_arrayTennisHistory[i][9],  TPULSEAFTER,
                g_arrayTennisHistory[i][10], RACKETSTR,
                g_arrayTennisHistory[i][11], SNEAKERSSTR,
                nil];
        [arraySorted addObject:dict];
    }
    
    //непосредственно, сортировка NSMutableArray по ключу TDATEDATE
    NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc] initWithKey:TDATEDATE ascending:TRUE];
    [arraySorted sortUsingDescriptors:[NSArray arrayWithObject:sortDescriptor]];
    
    //getContext
    appDelegate = (AppDelegate *)[[UIApplication sharedApplication]delegate];
    context = appDelegate.persistentContainer.viewContext;
    
    //fetch (Load) Data
    NSFetchRequest *requestExamLocationTennisHistory = [NSFetchRequest fetchRequestWithEntityName:@"TrainHistory"];
    NSArray *resultsTennisHistory = [context executeFetchRequest:requestExamLocationTennisHistory error:nil];
    
    NSInteger newTennisNum = 0;
    
    //меняем в core data данные на отсортированные
    for (int i = 0; i<arraySorted.count; i++) {
        
        NSManagedObject *entityObjTennisHistory = [resultsTennisHistory objectAtIndex:i];
        dict =  [arraySorted objectAtIndex: i];
        
        [entityObjTennisHistory setValue: [dict objectForKey:FIOSTR]        forKey: @"fioStr"];
        [entityObjTennisHistory setValue: [dict objectForKey:GOALSTR]       forKey: @"goalStr"];
        [entityObjTennisHistory setValue: [dict objectForKey:SAIDSTR]       forKey: @"saidStr"];
        [entityObjTennisHistory setValue: [dict objectForKey:TDATESTRING]   forKey: @"tDateString"];
        [entityObjTennisHistory setValue: [dict objectForKey:TDATEDATE]     forKey: @"tDateDate"];
        
        newTennisNum = newTennisNum+1; // исправляем сквозную нумерацию
        [entityObjTennisHistory setValue: @(newTennisNum) forKey: @"tNum"];
        
        [entityObjTennisHistory setValue: [dict objectForKey:TPRESSLOW]     forKey: @"tPressLow"];
        [entityObjTennisHistory setValue: [dict objectForKey:TPRESSUP]      forKey: @"tPressUp"];
        [entityObjTennisHistory setValue: [dict objectForKey:TPULSEBEFORE]  forKey: @"tPulseBefore"];
        [entityObjTennisHistory setValue: [dict objectForKey:TPULSEAFTER]   forKey: @"tPulseAfter"];
        [entityObjTennisHistory setValue: [dict objectForKey:RACKETSTR]     forKey: @"protectStr"];
        [entityObjTennisHistory setValue: [dict objectForKey:SNEAKERSSTR]   forKey: @"glovesStr"];
        
        // глобальный массив с тренировками - теперь с сортировкой и новой сквозной нумерацией!
        NSArray *array = @[
                           [dict objectForKey:FIOSTR],      //0
                           [dict objectForKey:GOALSTR],     //1
                           [dict objectForKey:SAIDSTR],    //2
                           [dict objectForKey:TDATESTRING],      //3
                           [dict objectForKey:TDATEDATE],      //4
                           @(newTennisNum), //5
                           [dict objectForKey:TPRESSLOW],      //6
                           [dict objectForKey:TPRESSUP],      //7
                           [dict objectForKey:TPULSEBEFORE],      //8
                           [dict objectForKey:TPULSEAFTER],      //9
                           [dict objectForKey:RACKETSTR],      //10
                           [dict objectForKey:SNEAKERSSTR]      //11
                           ];
        [g_arrayTennisHistory replaceObjectAtIndex:i withObject:array];
    }
    
    //исправляем номер тренировки в TennisToday
    newTennisNum = newTennisNum + 1;
    NSFetchRequest *requestExamLocationTennisToday = [NSFetchRequest fetchRequestWithEntityName:@"TrainToday"];
    NSArray *resultsTennisToday = [context executeFetchRequest:requestExamLocationTennisToday error:nil];
    NSManagedObject *entityObjTennisToday = [resultsTennisToday objectAtIndex:0];
    [entityObjTennisToday setValue: @([[NSString stringWithFormat:@"%ld", (long) newTennisNum] intValue]) forKey: @"tNum"];
    
    //сохраняем контекст
    [appDelegate saveContext];
    
    [self.TennisListTableView reloadData];
}

- (void)tableViewScrollToBottomAnimated:(BOOL)animated {
    NSLog(@"----------TennisListVC (tableViewScrollToBottomAnimated)------------");
    
    NSInteger numberOfRows = g_tennisRowNum;
    if (numberOfRows == -1) {numberOfRows = [self.TennisListTableView numberOfRowsInSection:0];}
    if (numberOfRows) {
        [self.TennisListTableView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:numberOfRows-1 inSection:0] atScrollPosition:UITableViewScrollPositionBottom animated:animated];
    }
}

//--/*Mark: TableView*/

/*+ Mark: CoreData*/
#pragma mark - CoreData
-(void)loadFromCoreData {
    NSLog(@"----------TennisListVC (loadFromCoreData)------------");
    
    //загрузка истории тренировок в табличную форму
    //getContext
    appDelegate = (AppDelegate *)[[UIApplication sharedApplication]delegate];
    context = appDelegate.persistentContainer.viewContext;
    
    //fetch (Load) Data
    NSFetchRequest *requestExamLocationTennisHistory = [NSFetchRequest fetchRequestWithEntityName:@"TrainHistory"];
    NSArray *resultsTennisHistory = [context executeFetchRequest:requestExamLocationTennisHistory error:nil];
    
    [g_arrayTennisHistory removeAllObjects];
    g_arrayTennisHistory = [[NSMutableArray alloc]initWithCapacity: g_arrayTennisHistory_ColumnCnt];
    //--
    for (int i = 0; i<resultsTennisHistory.count; i++){
        NSArray *array = @[
           [[resultsTennisHistory objectAtIndex:i] valueForKey:@"fioStr"], //0
           [[resultsTennisHistory objectAtIndex:i] valueForKey:@"goalStr"],//1
           [[resultsTennisHistory objectAtIndex:i] valueForKey:@"saidStr"],//2
           [[resultsTennisHistory objectAtIndex:i] valueForKey:@"tDateString"],//3
           [[resultsTennisHistory objectAtIndex:i] valueForKey:@"tDateDate"],//4
           [[resultsTennisHistory objectAtIndex:i] valueForKey:@"tNum"],//5
           [[resultsTennisHistory objectAtIndex:i] valueForKey:@"tPressLow"],//6
           [[resultsTennisHistory objectAtIndex:i] valueForKey:@"tPressUp"],//7
           [[resultsTennisHistory objectAtIndex:i] valueForKey:@"tPulseBefore"],//8
           [[resultsTennisHistory objectAtIndex:i] valueForKey:@"tPulseAfter"],//9
           [[resultsTennisHistory objectAtIndex:i] valueForKey:@"protectStr"],//10
           [[resultsTennisHistory objectAtIndex:i] valueForKey:@"glovesStr"]//11
           ];
        [g_arrayTennisHistory addObject:array];
    }
    
    Params *params = [[Params alloc] init];
    [params getSettingsTennisList];
    g_tennisRowNum = params -> settingsDicRowNum;
}
/*- Mark: CoreData*/

#pragma mark - prepareForSegue ------------------
//передача параметров во вложенное окно
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    NSLog(@"----------TennisListVC (prepareForSegue)------------");
    
    if ([segue.identifier isEqualToString:@"showTennisDetail"]) {
        //узнаем, кнопка на какой строке была нажата?
        UIButton *clicked = (UIButton *) sender;
        int l_selectedRow = (int)clicked.tag;
        TennisDetailVC *detailViewController = segue.destinationViewController;
        
        detailViewController.selectedRow = l_selectedRow;
        detailViewController.tfioStrVar  = g_arrayTennisHistory[l_selectedRow][0];
        detailViewController.tgoalStrVar = g_arrayTennisHistory[l_selectedRow][1];
        detailViewController.tsaidStrVar = g_arrayTennisHistory[l_selectedRow][2];
        detailViewController.tdateStrVar = g_arrayTennisHistory[l_selectedRow][3];
        detailViewController.tdateDateVar = g_arrayTennisHistory[l_selectedRow][4];
        detailViewController.tNumStrVar  = [[g_arrayTennisHistory[l_selectedRow][5] stringValue] stringByAppendingString:@"й день тренировки"];
        detailViewController.tPressLowStrVar    = [g_arrayTennisHistory[l_selectedRow][6] stringValue];
        detailViewController.tPressUpStrVar     = [g_arrayTennisHistory[l_selectedRow][7] stringValue];
        detailViewController.tPulseBeforeStrVar = [g_arrayTennisHistory[l_selectedRow][8] stringValue];
        detailViewController.tPulseAfterStrVar  = [g_arrayTennisHistory[l_selectedRow][9] stringValue];
        detailViewController.tracketStrVar      =  g_arrayTennisHistory[l_selectedRow][10];
        detailViewController.tsneakersStrVar    =  g_arrayTennisHistory[l_selectedRow][11];
    }
}

@end

