//
//  Params.m
//  TennisTraner2
//
//  Created by Helen Matveeva on 23.05.18.
//  Copyright © 2018 Helen Matveeva. All rights reserved.
//

#import "Params.h"

@implementation Params
/*
 номера кнопок вызова справочника:
 0 тренер
 1 цель
 2 мои методики
 3 ракетка
 4 кроссовки
 */

- (NSArray*) setArrayDicNames {
    //заполняем массив названий справочников
    
    
    
    arrayDicNames      = @[NSLocalizedString(@"Сoacher", @"Сoacher comment")/*0*/,
                           NSLocalizedString(@"Goal", @"Goal comment"), //@"Цель"/*1*/,
                           NSLocalizedString(@"My techniques", @"My techniques comment"), //@"Мои методики"/*2*/,
                           NSLocalizedString(@"Protect", @"Protect comment"), //@"Защита"/*3*/,
                           NSLocalizedString(@"Training gloves", @"Training gloves comment") //@"Перчатки"/*4*/
                           ];
    return arrayDicNames;
}

- (NSArray*) setArrayDicNamesTech {
    arrayDicNamesTech = @[@"DicTrainer"/*0*/,
                          @"Goals"/*1*/,
                          @"MyMethodics"/*3*/,
                          @"DicProtect"/*4*/,
                          @"DicGloves"/*5*/];
    return arrayDicNamesTech;
}

- (NSArray*) setArrayDicFieldNamesTech {
    arrayDicFieldNamesTech = [ NSArray arrayWithObjects:
                          [NSArray arrayWithObjects:@"fio"   ,@""     ,@""      , nil], /*0 DicTrainer*/
                          [NSArray arrayWithObjects:@"descr" ,@""     ,@""      , nil], /*1 Goals*/
                          [NSArray arrayWithObjects:@"name"  ,@"descr",@"isBase", nil], /*3 MyMethodics*/
                          [NSArray arrayWithObjects:@"size"  ,@"descr",@""      , nil], /*4 DicProtect*/
                          [NSArray arrayWithObjects:@"size"  ,@"descr",@""      , nil], /*5 DicGloves*/
                          nil];
    return arrayDicFieldNamesTech;
}

- (NSArray*) setArrayDicFieldMsg {
    arrayDicFieldMsg  =
    [NSArray arrayWithObjects:
     
     [NSArray arrayWithObjects:
       NSLocalizedString(@"Coacher name: ", @"Coacher name: comment"),
      @"",
      nil
      ], /*0 DicTrainer*/
     
     [NSArray arrayWithObjects:
      NSLocalizedString(@"Goal: ", @"Goal: comment"),
      @"",
      nil
      ], /*1 Goals*/
     
     [NSArray arrayWithObjects:
      NSLocalizedString(@"Name: ", @"Name: comment"),
      NSLocalizedString(@"Technique: ", @"Technique: comment"),
      nil
      ], /*2 MyMethodics*/
     
     [NSArray arrayWithObjects:
      NSLocalizedString(@"Size: ", @"Size: comment"),
      NSLocalizedString(@"Protection: ", @"Protection: comment"),
      nil
      ], /*3 DicProtect*/
     
     [NSArray arrayWithObjects:
      NSLocalizedString(@"Size: ", @"Size: comment"),
      NSLocalizedString(@"Training gloves: ", @"Training gloves: comment"),
      nil
      ], /*4 DicGloves*/
     
     nil];
     return arrayDicFieldMsg;
}

//количество полей в каждом справочнике
- (NSArray*) setArrayDicFieldsCnt {
    arrayDicFieldsCnt = @[@1, /*0 DicTrainer*/
                          @1, /*1 Goals*/
                          @3, /*3 MyMethodics*/
                          @2, /*4 DicProtect*/
                          @2  /*5 DicSneakersGloves*/
                        ];
    return arrayDicFieldsCnt;
}

- (void) setSettingTennisRow:       (int)        l_TennisRow        {
    settingsTennisListRowNum = l_TennisRow;
    
    NSLog(@"----------Params (setSettings)------------");
    
    //Get Context
    appDelegate = (AppDelegate *)[[UIApplication sharedApplication]delegate];
    context = appDelegate.persistentContainer.viewContext;
    
    NSFetchRequest *requestExamLocationSetting = [NSFetchRequest fetchRequestWithEntityName:@"Settings"];
    NSArray *resultsSetting = [context executeFetchRequest:requestExamLocationSetting error:nil];
    
    NSManagedObject *entityObjSetting = nil;
    
    //если данных нет, заливаем 1 строку данных
    if ([resultsSetting count] == 0) {entityObjSetting = [NSEntityDescription insertNewObjectForEntityForName:@"Settings" inManagedObjectContext:context];}
    //сохраним данные, если в таблице уже есть информация
    else {if ([resultsSetting count] > 0) {entityObjSetting = [resultsSetting objectAtIndex:0];}
    }
    
    //записываем в текущую тренировку отредактированные данные
    if ((settingsTennisListRowNum == -99) == FALSE) {
        [entityObjSetting setValue: @(settingsTennisListRowNum) forKey: @"goToRowNumTrainList"];
    }
    
    [appDelegate saveContext];
}

- (void) setSettingTennisListIsEdit:(NSString *) l_TennisListIsEdit {
    settingsTennisListIsEdit = l_TennisListIsEdit;
    
    NSLog(@"----------Params (setSettings)------------");
    
    //Get Context
    appDelegate = (AppDelegate *)[[UIApplication sharedApplication]delegate];
    context = appDelegate.persistentContainer.viewContext;
    
    NSFetchRequest *requestExamLocationSetting = [NSFetchRequest fetchRequestWithEntityName:@"Settings"];
    NSArray *resultsSetting = [context executeFetchRequest:requestExamLocationSetting error:nil];
    
    NSManagedObject *entityObjSetting = nil;
    
    //если данных нет, заливаем 1 строку данных
    if ([resultsSetting count] == 0) {entityObjSetting = [NSEntityDescription insertNewObjectForEntityForName:@"Settings" inManagedObjectContext:context];}
    //сохраним данные, если в таблице уже есть информация
    else {if ([resultsSetting count] > 0) {entityObjSetting = [resultsSetting objectAtIndex:0];}
    }
    
    if (settingsTennisListIsEdit == nil) {settingsTennisListIsEdit = @"N";}
    [entityObjSetting setValue: settingsTennisListIsEdit forKey: @"isEditTrainList"];
    
    [appDelegate saveContext];
}

- (void) setSettingDicId:           (int)        l_DicId            { settingsDicId            = l_DicId;            }
- (void) setSettingDicRow:          (int)        l_DicRow           { settingsDicRowNum        = l_DicRow;           }

- (void) setSettingsDic {
    NSLog(@"----------Params (setSettings)------------");
    
    //Get Context
    appDelegate = (AppDelegate *)[[UIApplication sharedApplication]delegate];
    context = appDelegate.persistentContainer.viewContext;
    NSFetchRequest *requestExamLocationSetting = [NSFetchRequest fetchRequestWithEntityName:@"Settings"];
    NSArray *resultsSetting = [context executeFetchRequest:requestExamLocationSetting error:nil];
    NSManagedObject *entityObjSetting = nil;
    
    //если данных нет, заливаем 1 строку данных
    if ([resultsSetting count] == 0) {entityObjSetting = [NSEntityDescription insertNewObjectForEntityForName:@"Settings" inManagedObjectContext:context];}
    //сохраним данные, если в таблице уже есть информация
    else {if ([resultsSetting count] > 0) {entityObjSetting = [resultsSetting objectAtIndex:0];}}
    
    //записываем в текущую тренировку отредактированные данные
    [entityObjSetting setValue: @(settingsDicId)     forKey: @"goToDicId"];
    [entityObjSetting setValue: @(settingsDicRowNum) forKey: @"goToDicRowNum"];
    [appDelegate saveContext];
}

- (void) getSettingsTennisList {
    NSLog(@"----------Params (getSettingsTennisList)------------");
    
    //getContext
    appDelegate = (AppDelegate *)[[UIApplication sharedApplication]delegate];
    context = appDelegate.persistentContainer.viewContext;
    
    //fetch (Load) Data
    NSFetchRequest *requestExamLocationSetting = [NSFetchRequest fetchRequestWithEntityName:@"Settings"];
    NSArray *resultsSetting = [context executeFetchRequest:requestExamLocationSetting error:nil];
    
    settingsTennisListRowNum = [[[resultsSetting objectAtIndex:0] valueForKey:@"goToRowNumTrainList"] integerValue];//0
    
    settingsTennisListIsEdit     = [[resultsSetting objectAtIndex:0]  valueForKey:@"isEditTrainList"];
    if (settingsTennisListIsEdit == nil) {settingsTennisListIsEdit = @"N";}
}

- (void) getSettingsDic {
    NSLog(@"----------Params (getSettingsDic)------------");
    //getContext
    appDelegate = (AppDelegate *)[[UIApplication sharedApplication]delegate];
    context = appDelegate.persistentContainer.viewContext;

    //fetch (Load) Data
    NSFetchRequest *requestExamLocationSetting = [NSFetchRequest fetchRequestWithEntityName:@"Settings"];
    NSArray *resultsSetting = [context executeFetchRequest:requestExamLocationSetting error:nil];

    settingsDicRowNum = -99;
    settingsDicId     = -99;
    if ([resultsSetting count] > 0) {
        settingsDicId     = [[[resultsSetting objectAtIndex:0] valueForKey:@"goToDicId"    ] integerValue];
        settingsDicRowNum = [[[resultsSetting objectAtIndex:0] valueForKey:@"goToDicRowNum"] integerValue];
    }
}

- (void) getUserInterfaceIdiom {
    if ( UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad )
    {
        isIPad = @"Y"; /* Device is iPad */
    }
    else
    {
        isIPad = @"N";
    }
}

@end
