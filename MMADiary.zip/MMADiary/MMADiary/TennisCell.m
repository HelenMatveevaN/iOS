//
//  TennisCell.m
//  TennisTraner2
//
//  Created by Helen Matveeva on 04.04.18.
//  Copyright © 2018 Helen Matveeva. All rights reserved.
//

#import "TennisCell.h"

@implementation TennisCell

@synthesize TDateLabel = _TDateLabel;
@synthesize TFioLabel = _TFioLabel;
@synthesize tNumLabel = _tNumLabel;
@synthesize tPressLabel = _tPressLabel;
@synthesize tPulseLabel = _tPulseLabel;
@synthesize tGoalLabel = _tGoalLabel;
@synthesize tSaidLabel = _tSaidLabel;
@synthesize tRacketLabel = _tRacketLabel;
@synthesize tSneakersLabel = _tSneakersLabel;

- (void)awakeFromNib {
    [super awakeFromNib];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
}

@end
