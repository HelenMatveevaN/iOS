//
//  DicDetailVC.h
//  TennisTraner2
//
//  Created by Helen Matveeva on 21.05.18.
//  Copyright © 2018 Helen Matveeva. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DicDetailVC : UIViewController {
}

@property (weak, nonatomic) IBOutlet UILabel    *DicNameLabel;
@property (weak, nonatomic) IBOutlet UIButton   *BtnOutletDicDataSave;
@property (weak, nonatomic) IBOutlet UIButton   *BtnOutletBack;

@property (weak, nonatomic) IBOutlet UILabel    *labelShort;
@property (weak, nonatomic) IBOutlet UILabel    *labelLong;
@property (weak, nonatomic) IBOutlet UILabel    *labelIsBase;

@property (weak, nonatomic) IBOutlet UITextView *textShort;
@property (weak, nonatomic) IBOutlet UITextView *textLong;
@property (weak, nonatomic) IBOutlet UISwitch   *switchIsBase;

//переменные для передачи
@property (nonatomic, assign) NSInteger selectedRow;    //выбранная строка таблицы
@property (nonatomic, assign) NSInteger selectedButton; //выбранный словарь
@property (nonatomic, assign) NSInteger dicFieldsCnt;   //выбранный словарь

@property (nonatomic, assign) NSString  *dicNameTech; //выбранный словарь
@property (nonatomic, assign) NSString  *dicName; //выбранный словарь

@property (nonatomic, assign) NSString  *valShort;  //статья из словаря, 1е поле
@property (nonatomic, assign) NSString  *valLong;   //2е поле
@property (nonatomic, assign) NSString  *valIsBase; //3е поле

@property (nonatomic, assign) NSString  *valLabelShort; //статья из словаря, 1е поле
@property (nonatomic, assign) NSString  *valLabelLong;  //2е поле

@property (nonatomic, assign) NSString  *dicFieldNameShort;  //статья из словаря, 1е поле
@property (nonatomic, assign) NSString  *dicFieldNameLong;   //2е поле
@property (nonatomic, assign) NSString  *dicFieldNameIsBase; //3е поле

@end
