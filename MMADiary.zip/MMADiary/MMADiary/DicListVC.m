//
//  DicListVC.m
//  TennisTraner2
//
//  Created by iMac on 02.05.2018.
//  Copyright © 2018 Helen Matveeva. All rights reserved.
//
// в каждый момент времени отображается только 1 справочник

#import "AppDelegate.h"
#import "DicListVC.h"
#import "DicCell.h"
#import "DicDetailVC.h"
#import "Params.h"

@interface DicListVC () {
    //нужно для работы с CoreData
    AppDelegate *appDelegate;
    NSManagedObjectContext *context;
    
    //массив для загрузки данных из CoreData
    NSMutableArray *g_arrayDic; //размерность = 3
    
    //объявление переменных
    NSArray *arrayDicNames;      //описание справочника
    NSArray *arrayDicNamesTech;  //тех.название справочника
    NSArray *arrayDicFieldsNameTech; //поля каждого справочника
    NSArray *arrayDicFieldsCnt;  //количество полей в каждом справочнике
    NSArray *arrayDicFieldMsg;
    
    NSString *g_isIpad;
}
@end

@implementation DicListVC //предстоит исправить предупреждение

@synthesize DicTextField;
@synthesize selectDicLabel;
@synthesize DicListTableView;
@synthesize selectedButton, selectedButtonTextField, selectedRow, BtnBackOutlet, BtnNewDicStringOutlet;

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:NO];
    
    //iPad?
    Params *params = [[Params alloc] init];
    [params getUserInterfaceIdiom];
    g_isIpad = params -> isIPad;
    
    if ([g_isIpad isEqualToString:@"Y"]){
        [BtnBackOutlet.titleLabel setFont:[BtnBackOutlet.titleLabel.font fontWithSize:20]];
        [DicTextField   setFont:[DicTextField.font   fontWithSize:20]];
        [selectDicLabel setFont:[selectDicLabel.font fontWithSize:20]];
        [BtnNewDicStringOutlet.titleLabel setFont:[BtnNewDicStringOutlet.titleLabel.font fontWithSize:40]];
    }
    
}

- (void)viewDidLoad {
    NSLog(@"----------DicListVC (viewDidLoad)------------");

    [super viewDidLoad];
    
    //инициализация переменных]
    Params *params = [[Params alloc] init];
    
    [params setArrayDicNamesTech];
    [params setArrayDicNames];
    [params setArrayDicFieldNamesTech];
    [params setArrayDicFieldMsg];
    [params setArrayDicFieldsCnt];

    arrayDicNamesTech  = params -> arrayDicNamesTech;
    arrayDicNames      = params -> arrayDicNames;
    arrayDicFieldsNameTech = params -> arrayDicFieldNamesTech;
    arrayDicFieldMsg   = params -> arrayDicFieldMsg;
    arrayDicFieldsCnt  = params -> arrayDicFieldsCnt;
    
    [params getSettingsDic];
    if ((params -> settingsDicId == -99) == FALSE) {
        selectedButton = params -> settingsDicId;
        selectedRow    = params -> settingsDicRowNum;
        if (selectedButton == params -> settingsDicId && selectedRow == params -> settingsDicRowNum){
            [params setSettingDicId:-99];
            [params setSettingDicRow:-99];
            [params setSettingsDic];
        }
    }

    /*
     номера кнопок вызова справочника:
     0 тренер
     1 цель
     2 мои методики
     3 ракетка
     4 кроссовки
     */
    
    //отображаем название в поле с названием справочника
    self.DicTextField.text = arrayDicNames[selectedButton];
    selectedButtonTextField = selectedButton;
    
    //делегаты
    self.DicTextField.delegate       = self;
    self.DicListTableView.delegate   = self;
    self.DicListTableView.dataSource = self;

    //готовим picker
    pickerViewDic = [[UIPickerView alloc] init];
    pickerViewDic.delegate = self;
    pickerViewDic.dataSource = self;
    pickerViewDic.showsSelectionIndicator = YES;
    
    //создаем toolbar с кнопками. Сюда же добавляем picker
    toolbarDic = [[UIToolbar alloc] init];
    [toolbarDic sizeToFit];

    UIBarButtonItem *doneBtnDic = [[UIBarButtonItem alloc]initWithTitle:
                                   NSLocalizedString(@"Choose Reference guide", @"Choose Reference guide comment")
                                                                  style:UIBarButtonItemStyleDone target:self action:@selector(ShowSelectedDic:)];
    
    doneBtnDic.tintColor = [UIColor whiteColor];
    
    UIBarButtonItem *flexibleSpaceLeft = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
    
    toolbarDic.backgroundColor = [UIColor colorWithRed:5.0/255.0 green:110.0/255.0 blue:170.0/255.0 alpha:1];
    
    [toolbarDic setItems:[NSArray arrayWithObjects:flexibleSpaceLeft, doneBtnDic, nil]];
    
    [self.DicTextField setInputAccessoryView:toolbarDic];
    self.DicTextField.inputView = pickerViewDic;
    
    //распознавание жеста
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(dismissKeyboard)];
    [self.view addGestureRecognizer:tap];

    //загрузка данных из CoreData после инициализации всех переменных и присвоения им соотв.значений
    [self loadFromCoreData: selectedButtonTextField];

}//--viewDidLoad

//  Hide the keyboard (покидая редактируемый textField)
-(void)dismissKeyboard {
    NSLog(@"----------DicListVC (dismissKeyboard)------------");

    [self.DicTextField resignFirstResponder];
}

- (void)didReceiveMemoryWarning {
    NSLog(@"----------DicListVC (didReceiveMemoryWarning)------------");
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)ShowSelectedDic:(id)sender{
    NSLog(@"----------DicListVC (ShowSelectedDic)------------");
    self.DicTextField.text = arrayDicNames[selectedButton];
    selectedButtonTextField = selectedButton;
    
    [self loadFromCoreData: selectedButtonTextField];
    
    [DicListTableView reloadData];
    [self dismissKeyboard]; //скрыть клавиатуру
}

/*MARK: Picker View*/
- (NSInteger)numberOfComponentsInPickerView:(nonnull UIPickerView *)pickerView {
    NSLog(@"----------DicListVC (numberOfComponentsInPickerView)------------");
    return 1;
}

- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    NSLog(@"----------DicListVC (pickerView titleForRow)------------");
    NSString *string = arrayDicNames[row];
    selectedButton = row;
    
    return string;
}

- (NSInteger)pickerView:(nonnull UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    NSLog(@"----------DicListVC (pickerView numberOfRowsInComponent)------------");
    return arrayDicNames.count;
}

- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
    NSLog(@"----------DicListVC (pickerView didSelectRow)------------");
    selectedButton = row;
}
//--MARK: pv

/*MARK: tableView */
#pragma mark - UITableView Data Source method
- (NSInteger)tableView:(nonnull UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    NSLog(@"----------DicListVC (tableView numberOfRowsInSection)------------");
    return g_arrayDic.count;
}

- (nonnull UITableViewCell *)tableView:(nonnull UITableView *)tableView cellForRowAtIndexPath:(nonnull NSIndexPath *)indexPath
{
    NSLog(@"----------DicListVC (tableView cellForRowAtIndexPath)------------");
    static NSString *tennisTableId = @"DicCell";
    DicCell *cell = (DicCell *)[tableView dequeueReusableCellWithIdentifier:tennisTableId];
    
    if (cell == nil) {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"DicCell" owner:self options:nil];
        cell = [nib objectAtIndex:0];
    }
    
    NSString *strVal0 = g_arrayDic[indexPath.row][0];
    if ([arrayDicFieldsCnt[selectedButtonTextField] isEqual:@1] == FALSE)
    {   strVal0 = [arrayDicFieldMsg[selectedButtonTextField][0] stringByAppendingString: strVal0]; }
    
    //iPad?
    Params *params = [[Params alloc] init];
    [params getUserInterfaceIdiom];
    g_isIpad = params -> isIPad;
    
    if ([g_isIpad isEqualToString:@"Y"]){
        [cell.TextLongTextView setFont:[cell.TextLongTextView.font fontWithSize:18]];
        [cell.TextShortLabel setFont:[cell.TextShortLabel.font fontWithSize:18]];
        [cell.isBaseLabel setFont:[cell.isBaseLabel.font fontWithSize:17]];
        [cell.TEditButton.titleLabel setFont:[cell.TEditButton.titleLabel.font fontWithSize:18]];
    }
    cell.TextShortLabel.text = strVal0;
    cell.TextLongTextView.hidden = TRUE;
    cell.isBaseLabel.hidden = TRUE;
    
    //если больше 1 поля
    if ([arrayDicFieldsCnt[selectedButtonTextField] isEqual: @2] ||
        [arrayDicFieldsCnt[selectedButtonTextField] isEqual: @3])
    {
        cell.TextLongTextView.hidden = FALSE;
        cell.TextLongTextView.text = g_arrayDic[indexPath.row][1];
        
        //если 3 поля
        if ([arrayDicFieldsCnt[selectedButtonTextField] isEqual: @3]) {
            if ([g_arrayDic[indexPath.row][2] isEqualToString:@"Y"])
            {     cell.isBaseLabel.hidden = FALSE;}
            else {cell.isBaseLabel.hidden = TRUE;}
        }
    }
    
    cell.TEditButton.tag = indexPath.row; //нужно для редактирования справочного значения
    
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{   int l_height = 100;
    if ([arrayDicFieldsCnt[selectedButtonTextField] isEqual: @1]) {l_height = 45;}
    if ([arrayDicFieldsCnt[selectedButtonTextField] isEqual: @2]) {l_height = 80;}
    if ([arrayDicFieldsCnt[selectedButtonTextField] isEqual: @3]) {l_height = 100;}
    return l_height;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSLog(@"----------DicListVC (tableView forRowAtIndexPath)------------");
    
    if (editingStyle==UITableViewCellEditingStyleDelete) {
        
        NSFetchRequest *requestExamLocationDic = [NSFetchRequest fetchRequestWithEntityName:arrayDicNamesTech[selectedButtonTextField]];
        NSArray *resultsDic = [context executeFetchRequest:requestExamLocationDic error:nil];
        
        //удаление из coredata
        NSManagedObject *entityObj = [resultsDic objectAtIndex:indexPath.row];
        [context deleteObject:entityObj];
        [appDelegate saveContext];
        
        //удаление из массива
        [g_arrayDic removeObjectAtIndex:indexPath.row];
        
        //удаление из таблицы
        [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath]  withRowAnimation:UITableViewRowAnimationFade];
    }
}

//--/*Mark: TableView*/

/*MARK: CoreData*/
-(void)loadFromCoreData: (NSInteger) l_selectedButton {
    NSLog(@"----------DicListVC (loadFromCoreData)------------");
    //загрузка справочника из CoreData - в g_arrayDiff, g_arrayDescr
    
    //инициализация других переменных
    [g_arrayDic removeAllObjects];
    g_arrayDic = [[NSMutableArray alloc]initWithCapacity:3];//0-Descr,1-Diff,2-isBase
    NSInteger resultsCount = 0;
    
    //getContext
    appDelegate = (AppDelegate *)[[UIApplication sharedApplication]delegate];
    context = appDelegate.persistentContainer.viewContext;

    //fetch (Load) Data - загрузка данных из выбранного справочника
    NSFetchRequest *requestExamLocationDic = nil;
    NSArray *resultsDic = nil;
    
    if ([arrayDicFieldsCnt[l_selectedButton] isEqual: @0] == FALSE) {
        
        requestExamLocationDic = [NSFetchRequest fetchRequestWithEntityName:arrayDicNamesTech[l_selectedButton]];
        resultsDic = [context executeFetchRequest:requestExamLocationDic error:nil];
        resultsCount = resultsDic.count;

        //идем по словарю
        for (int i = 0; i<resultsCount; i++){
            NSString *field0 = @"";
            NSString *field1 = @"";
            NSString *field2 = @"N";
            
            //поле descr-fio - актуально для всех
            field0 = [[resultsDic objectAtIndex:i]    valueForKey:arrayDicFieldsNameTech[l_selectedButton][0]];
            
            //поле size-name - актуально для кол-ва полей = 2 или 3
            if ([arrayDicFieldsCnt[l_selectedButton]  isEqual: @2] ||
                [arrayDicFieldsCnt[l_selectedButton]  isEqual: @3])
            {
                field1 = [[resultsDic objectAtIndex:i] valueForKey:arrayDicFieldsNameTech[l_selectedButton][1]];

                if (field1 == nil) {field1 = @"...";}
                
                //поле isBase - если 3 поля
                if ([arrayDicFieldsCnt[l_selectedButton]  isEqual: @3]) {
                    field2 = [[resultsDic objectAtIndex:i] valueForKey:arrayDicFieldsNameTech[l_selectedButton][2]];
                    if (field2 == nil) {field2 = @"N";}
                }
            }
            
            NSArray *array = @[field0,field1,field2];
            [g_arrayDic addObject:array];
        }//for (int i = 0; i<resultsCount; i++){
    }
}
- (IBAction)BtnNewDicString {
    NSLog(@"----------DicListVC (BtnNewDicString)------------");
    [self NewDicText: selectedButtonTextField];
}
/*- Mark: CoreData*/

//ДОБАВЛЯЕМ НОВУЮ СЛОВАРНУЮ СТАТЬЮ В ТАБЛИЦУ ---------------
- (void) NewDicText: (NSInteger) l_selectedButton {
    NSLog(@"----------DicListVC (NewDicText)------------");
    
    //Alert Controller с кнопками и полем для ввода данных в справочник (ДОБАВИТЬ ДАННЫЕ В СПРАВОЧНИК)
    UIAlertController* alert = [UIAlertController alertControllerWithTitle:
                                NSLocalizedString(@"Set a new value", @"Set a new value")
                                                                   message:@"" preferredStyle:UIAlertControllerStyleAlert //стиль кнопок - только для этого стиля можно добавить текстовое поле в Alert
    ];

    //Предварительное заполнение alert-ов значениями из справочника
    [alert addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
        textField.placeholder = self->arrayDicFieldMsg[l_selectedButton][0];}];
    
    //добавить доп.текстовое поле для справочников c кол-вом полей 2 или 3
    if ([arrayDicFieldsCnt[l_selectedButton] isEqual:@2] || [arrayDicFieldsCnt[l_selectedButton] isEqual:@3]) {
        [alert addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
            textField.placeholder = self->arrayDicFieldMsg[l_selectedButton][1];}];
    }//if
    
    //добавить новую статью в справочник
    UIAlertAction* actionAdd = [UIAlertAction actionWithTitle:
                                NSLocalizedString(@"Add", @"Add comment")
                                                        style:UIAlertActionStyleDefault handler:^(UIAlertAction * action)
    {
        //Get Context
        self->appDelegate = (AppDelegate *)[[UIApplication sharedApplication]delegate];
        self->context = self->appDelegate.persistentContainer.viewContext;
        
        NSManagedObject *entityObj = [NSEntityDescription insertNewObjectForEntityForName:self->arrayDicNamesTech[l_selectedButton] inManagedObjectContext:self->context];
        
        NSString *val0 = @"";//descr-fio
        NSString *val1 = @"";
        NSString *val2 = @"N";
        
        //добавление в CoreData
        val0 = alert.textFields[0].text;
        [entityObj setValue: val0 forKey:self->arrayDicFieldsNameTech[l_selectedButton][0]];//работает
        
        //dop-field  -  для справочников c кол-вом полей > 1
        if ([self->arrayDicFieldsCnt[l_selectedButton] isEqual:@1] == FALSE) {
            val1 = alert.textFields[1].text;
            [entityObj setValue: val1 forKey:self->arrayDicFieldsNameTech[l_selectedButton][1]]; //добавила в справочник значение из Alert
        }
        //save data
        [self->appDelegate saveContext];
        
        NSArray *array = @[val0,val1,val2];//работает
        [self->g_arrayDic addObject:array];
        [self->DicListTableView reloadData];
    }];
        
    UIAlertAction* actionCancel = [UIAlertAction actionWithTitle:
                                   //@"Отмена"
                                   NSLocalizedString(@"Cancel", @"Cancel comment")
                                                           style:UIAlertActionStyleCancel handler:^(UIAlertAction * action) {}];
    
    [alert addAction:actionAdd];
    [alert addAction:actionCancel];
    
    [self presentViewController:alert animated:YES completion:nil];
}

//передача параметров в DicDetailVC
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    NSLog(@"----------DicListVC (prepareForSegue)------------");
    
    if ([segue.identifier isEqualToString:@"showDicDetail"]) {
        
        //узнаем, кнопка на какой строке была нажата?
        UIButton *clicked = (UIButton *) sender;
        int l_selectedRow = (int)clicked.tag;
        DicDetailVC *detailVC = segue.destinationViewController;
        
        NSString *valShort = @"", *valLong = @"", *valIsBase = @"N";
        valShort = g_arrayDic[l_selectedRow][0];//значение из строки
        
        //selectedButtonTextField-выбранный справочник
        if ([arrayDicFieldsCnt[selectedButtonTextField] isEqual: @3] ||
             [arrayDicFieldsCnt[selectedButtonTextField] isEqual:@2])
        {
            valLong = g_arrayDic[l_selectedRow][1];//выбранная строка
            if ([arrayDicFieldsCnt[selectedButtonTextField] isEqual:@3]){
                valIsBase = g_arrayDic[l_selectedRow][2];//выбранная строка
            }
        }
        
        //передача параметров во вложенное окно
        detailVC.selectedRow    = l_selectedRow;
        detailVC.selectedButton = selectedButtonTextField;
        
        detailVC.valLabelShort = arrayDicFieldMsg[selectedButtonTextField][0]; //названия полей выбранных справочников
        detailVC.valLabelLong = arrayDicFieldMsg[selectedButtonTextField][1];
        
        detailVC.dicFieldsCnt      = [arrayDicFieldsCnt[selectedButtonTextField] integerValue];
        detailVC.dicName           = arrayDicNames[selectedButtonTextField];
        detailVC.dicNameTech       = arrayDicNamesTech[selectedButtonTextField];
        
        detailVC.dicFieldNameShort  = arrayDicFieldsNameTech[selectedButtonTextField][0];
        detailVC.dicFieldNameLong   = arrayDicFieldsNameTech[selectedButtonTextField][1];
        detailVC.dicFieldNameIsBase = arrayDicFieldsNameTech[selectedButtonTextField][2];
        
        detailVC.valShort  = valShort;
        detailVC.valLong   = valLong;
        detailVC.valIsBase = valIsBase;
        
        // при переходе во вложенное окно нужно запомнить:
        // (а)-какой словарь редактируем, (б)-какую строку редактируем
        Params  *params = [[Params alloc] init];
        [params setSettingDicId:(int)selectedButtonTextField];
        [params setSettingDicRow:(int)l_selectedRow];
        [params setSettingsDic];
    }
}

//--//TableView

@end
