//
//  DicDetailVC.m
//  TennisTraner2
//
//  Created by Helen Matveeva on 21.05.18.
//  Copyright © 2018 Helen Matveeva. All rights reserved.

#import "AppDelegate.h"
#import "DicDetailVC.h"
#import "Params.h"

@interface DicDetailVC () {
    AppDelegate *appDelegate;
    NSManagedObjectContext *context;
    NSString *g_isIpad;
}
@end

@implementation DicDetailVC

//переданные параметры
@synthesize selectedRow, selectedButton;
@synthesize valShort, valLong, valIsBase;
@synthesize valLabelShort, valLabelLong;
@synthesize dicFieldsCnt, dicName, dicNameTech;
@synthesize dicFieldNameShort, dicFieldNameLong, dicFieldNameIsBase;

//параметры из родного окна
@synthesize DicNameLabel, BtnOutletDicDataSave, BtnOutletBack;
@synthesize textShort, textLong, switchIsBase, labelShort, labelLong,labelIsBase;

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:NO];
    
    //iPad?
    Params *params = [[Params alloc] init];
    [params getUserInterfaceIdiom];
    g_isIpad = params -> isIPad;
    
    if ([g_isIpad isEqualToString:@"Y"]){
        [BtnOutletBack.titleLabel   setFont:[BtnOutletBack.titleLabel.font fontWithSize:20]];
        [BtnOutletDicDataSave.titleLabel   setFont:[BtnOutletDicDataSave.titleLabel.font fontWithSize:25]];
        [DicNameLabel setFont:[DicNameLabel.font fontWithSize:22]];
        [labelShort   setFont:[labelShort.font   fontWithSize:20]];
        [labelLong    setFont:[labelLong.font    fontWithSize:20]];
        [textShort    setFont:[textShort.font    fontWithSize:20]];
        [textLong     setFont:[textLong.font    fontWithSize:20]];
        [labelIsBase  setFont:[labelIsBase.font  fontWithSize:17]];
    }
}//viewWillAppear

- (void)viewDidLoad {
    NSLog(@"----------viewDidLoad------------");
    [super viewDidLoad];
    
    //"редактирование" + название справочника
    NSString *strAppend =
    NSLocalizedString(@" Editing", @" Editing comment");
    if (selectedButton == 2) {
        strAppend = @"";
    }
    DicNameLabel.text = [dicName stringByAppendingString:strAppend];
    
    //видимость элементов
    labelLong.hidden    = TRUE;
    labelIsBase.hidden  = TRUE;
    textLong.hidden     = TRUE;
    switchIsBase.hidden = TRUE;
    textShort.editable  = TRUE;
    textLong.editable   = TRUE;
    
    if ([@(dicFieldsCnt) isEqual:@2]) {
        labelLong.hidden = FALSE; //2 параметр
        textLong.hidden  = FALSE;
    }
    
    if ([@(dicFieldsCnt) isEqual:@3]) {
        labelLong.hidden    = FALSE; //2 параметр
        textLong.hidden     = FALSE;
        labelIsBase.hidden  = FALSE; //2 параметр
        switchIsBase.hidden = FALSE;
    }
    
    //заполняем значения полей
    labelShort.text = valLabelShort;
    labelLong.text  = valLabelLong;
    textShort.text = valShort;
    textLong.text  = valLong;
    if ([valIsBase isEqualToString:@"Y"])
    {switchIsBase.on = YES;} else {switchIsBase.on = NO;}
    
    //распознавание жеста
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(dismissKeyboard)];
    [self.view addGestureRecognizer:tap];
    
}//viewDidLoad

-(void)viewWillLayoutSubviews{
    [super viewWillLayoutSubviews];
    //прокрутка textview вверх
    [textShort setContentOffset:CGPointZero animated:NO];
    [textLong  setContentOffset:CGPointZero animated:NO];
}

- (IBAction)BtnSaveDicData:(id)sender {
    NSLog(@"----------viewDidLoad------------");
    
    //отредактировать статью в справочнике
    
    //Get Context
    appDelegate = (AppDelegate *)[[UIApplication sharedApplication]delegate];
    context = appDelegate.persistentContainer.viewContext;
    
    NSFetchRequest  *requestExamLocation = [NSFetchRequest fetchRequestWithEntityName:dicNameTech];
    NSArray         *results             = [context executeFetchRequest:requestExamLocation error:nil];
    NSManagedObject *entityObj           = [results objectAtIndex:selectedRow];

    [entityObj setValue: textShort.text forKey: dicFieldNameShort];
    
    if (dicFieldsCnt == 2 || dicFieldsCnt == 3) {
        [entityObj setValue: textLong.text forKey: dicFieldNameLong];
        if (dicFieldsCnt == 3) {
            if (switchIsBase.on == YES)
                 {[entityObj setValue: @"Y" forKey: dicFieldNameIsBase];}
            else {[entityObj setValue: @"N" forKey: dicFieldNameIsBase];}
        }
    }

    //save data
    [appDelegate saveContext];
    
    //имитация нажатия кнопки Back/Назад
    [self performSegueWithIdentifier:@"backToDicList" sender:self];
}//BtnSaveDicData

//  Hide the keyboard (покидая редактируемый textField)
-(void)dismissKeyboard {
    NSLog(@"----------TennisDetailVC (dismissKeyboard)------------");
    [self.textShort resignFirstResponder];
    [self.textLong  resignFirstResponder];
}


@end
