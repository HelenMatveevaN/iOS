//
//  TennisDetailVC.h
//  TennisTraner2
//
//  Created by iMac on 11.04.2018.
//  Copyright © 2018 Helen Matveeva. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TennisDetailVC : UIViewController <UITextFieldDelegate, UITextViewDelegate, UIPickerViewDelegate, UIPickerViewDataSource>{
    
    UIToolbar *toolbarDate;
    UIToolbar *toolbarFIO;
    UIToolbar *toolbarGOAL;
    UIToolbar *toolbarRACKET;
    UIToolbar *toolbarSNEAKERS;
    
    UIDatePicker *datePicker;
    UIPickerView *pickerViewFIO;
    UIPickerView *pickerViewGOAL;
    UIPickerView *pickerViewRACKET;
    UIPickerView *pickerViewSNEAKERS;
    
    UITextField *pickerViewTextField; //из какого поля вызывается picker?
}

@property (weak, nonatomic) IBOutlet UITextField *fioStrTextField;
@property (weak, nonatomic) IBOutlet UILabel     *tNumTextField;
@property (weak, nonatomic) IBOutlet UITextField *tDateTextField;
@property (weak, nonatomic) IBOutlet UITextField *tDateDateTextField;
@property (weak, nonatomic) IBOutlet UITextField *tPressUpTextField;
@property (weak, nonatomic) IBOutlet UITextField *tPressLowTextField;
@property (weak, nonatomic) IBOutlet UITextField *tPulseBeforeTextField;
@property (weak, nonatomic) IBOutlet UITextField *tPulseAfterTextField;
@property (weak, nonatomic) IBOutlet UITextField *goalStrTextField;
@property (weak, nonatomic) IBOutlet UITextView  *saidOnTheCortTextView;
@property (weak, nonatomic) IBOutlet UITextField *racketStrTextField;
@property (weak, nonatomic) IBOutlet UITextField *sneakersStrTextField;

//Labels
@property (weak, nonatomic) IBOutlet UILabel  *titleLabel;
@property (weak, nonatomic) IBOutlet UIButton *BtnBackOutlet;
@property (weak, nonatomic) IBOutlet UIButton *BtnSaveOutlet;

@property (weak, nonatomic) IBOutlet UIScrollView *ScrollView;

@property (weak, nonatomic) IBOutlet UILabel *trainerLabel;
@property (weak, nonatomic) IBOutlet UILabel *dateTimeLabel;
@property (weak, nonatomic) IBOutlet UILabel *pressureLabel;
@property (weak, nonatomic) IBOutlet UILabel *pulseLabel;
@property (weak, nonatomic) IBOutlet UILabel *goalLabel;
@property (weak, nonatomic) IBOutlet UILabel *saidLabel;
@property (weak, nonatomic) IBOutlet UILabel *racketLabel;
@property (weak, nonatomic) IBOutlet UILabel *sneakersLabel;


//параметры для передачи
@property (nonatomic, assign) NSInteger selectedRow;

@property (nonatomic, strong) NSString *tfioStrVar;
@property (nonatomic, strong) NSString *tgoalStrVar;
@property (nonatomic, strong) NSString *tsaidStrVar;
@property (nonatomic, strong) NSString *tdateStrVar;
@property (nonatomic, strong) NSDate   *tdateDateVar;
@property (nonatomic, strong) NSString *tNumStrVar;
@property (nonatomic, strong) NSString *tPressLowStrVar;
@property (nonatomic, strong) NSString *tPressUpStrVar;
@property (nonatomic, strong) NSString *tPulseAfterStrVar;
@property (nonatomic, strong) NSString *tPulseBeforeStrVar;
@property (nonatomic, strong) NSString *tracketStrVar;
@property (nonatomic, strong) NSString *tsneakersStrVar;

@end
