//
//  DicListVC.h
//  TennisTraner2
//
//  Created by iMac on 02.05.2018.
//  Copyright © 2018 Helen Matveeva. All rights reserved.
//
//  Модуль для отображения содержимого выбранного справочника
//  список справочников:
// * сказано на корте, цель, тренер,
// * ракетка, кроссовки,
// * мои методики, методики типов удара (этот справ-к целиком берется из массива)

#import <UIKit/UIKit.h>

@interface DicListVC : UIViewController <UITableViewDelegate, UITableViewDataSource, UITextFieldDelegate, UIPickerViewDelegate, UIPickerViewDataSource> {
    UIToolbar *toolbarDic;
    UIPickerView *pickerViewDic;
}

@property (weak, nonatomic) IBOutlet UITableView *DicListTableView;
@property (weak, nonatomic) IBOutlet UITextField *DicTextField;
@property (weak, nonatomic) IBOutlet UIButton *BtnBackOutlet;
@property (weak, nonatomic) IBOutlet UIButton *BtnNewDicStringOutlet;


//Labels
@property (weak, nonatomic) IBOutlet UILabel *selectDicLabel;

//переменная для передачи из ViewController в DicListVC
@property (nonatomic, assign) NSInteger selectedButton;
@property (nonatomic, assign) NSInteger selectedButtonTextField;
@property (nonatomic, assign) NSInteger selectedRow;

@end
