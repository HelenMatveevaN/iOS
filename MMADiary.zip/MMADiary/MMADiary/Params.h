//
//  Params.h
//  TennisTraner2
//
//  Created by Helen Matveeva on 23.05.18.
//  Copyright © 2018 Helen Matveeva. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

@interface Params : NSObject
{
@private
    AppDelegate *appDelegate;
    NSManagedObjectContext *context;
@public
    NSArray *arrayDicNames; //описание справочника
    NSArray *arrayDicNamesTech;      //тех.название справочника
    NSArray *arrayDicFieldNamesTech; //поля каждого справочника
    NSArray *arrayDicFieldsCnt;  //количество полей в каждом справочнике
    NSArray *arrayDicFieldMsg;   //текст для сообщений (при создании новой словарной статьи того или иного справочника)
    
    //настройки
    NSInteger settingsTennisListRowNum;
    NSString  *settingsTennisListIsEdit;
    
    NSInteger settingsDicId;
    NSInteger settingsDicRowNum;
    
    //iPhone or iPad?
    NSString *isIPad;
}

- (NSArray*) setArrayDicNames;
- (NSArray*) setArrayDicNamesTech;
- (NSArray*) setArrayDicFieldNamesTech;
- (NSArray*) setArrayDicFieldsCnt;
- (NSArray*) setArrayDicFieldMsg;

- (void) getSettingsTennisList;
- (void) setSettingTennisRow:         (int)       l_TennisRow;
- (void) setSettingTennisListIsEdit:  (NSString*) l_TennisListIsEdit;

- (void) getSettingsDic;
- (void) setSettingsDic;
- (void) setSettingDicId:      (int) l_DicId;
- (void) setSettingDicRow:     (int) l_DicRow;

- (void) getUserInterfaceIdiom;

@end
