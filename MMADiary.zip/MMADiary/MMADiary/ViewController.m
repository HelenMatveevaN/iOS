//
//  ViewController.m
//  TennisTraner2
//
//  Created by Helen Matveeva on 27.02.18.
//  Copyright © 2018 Helen Matveeva. All rights reserved.
//  NEXT STEP: добавила код textViewDidBeginEditing, ... - для сдвигания Скролла вверх, но код не работает

#import "AppDelegate.h"
#import "ViewController.h"
#import "DicListVC.h"
#import "Params.h"

@interface ViewController () {
    //нужно для работы с CoreData - взято из https://www.youtube.com/watch?v=gNuXTJoBTEM
    
    AppDelegate *appDelegate;
    NSManagedObjectContext *context;
    
    //объявляем динамические (NSMutableArray) массивы
    NSMutableArray *g_dictFIO;
    NSMutableArray *g_dictGOAL;
    NSMutableArray *g_dictRACKET;
    NSMutableArray *g_dictSNEAKERS;

    NSMutableArray *g_dictMethodicsName;
    NSMutableArray *g_dictMethodicsRowNum;
    
    NSArray *g_dictFIO_sorted;
    NSArray *g_dictGOAL_sorted;
    NSArray *g_dictRACKET_sorted;
    NSArray *g_dictSNEAKERS_sorted;
    
    int g_numFIO;
    int g_numGOAL;
    int g_numRACKET;
    int g_numSNEAKERS;
    
    int g_dicIdFIO;
    int g_dicIdGOAL;
    int g_dicIdRACKET;
    int g_dicIdSNEAKERS;
    
    NSInteger g_tennisDayNum; //номер теннисной тренировки
    NSString *g_selectedString; //выбранная статья в pickerView
    NSString *g_modeTennisDay; //режим работы - ADD (новая тренировка), EDIT (редактирование)
    NSString *g_modeTennisDayAdd;
    NSString *g_modeTennisDayEdit;
    
    //в эти переменные копируем параметры из TennisToday
    NSString *g_fioStrTransfer;
    NSString *g_goalStrTransfer;
    NSString *g_saidStrTransfer;
    NSString *g_tRacketStrTransfer;
    NSString *g_tSneakersStrTransfer;
    NSString *g_tDateStringTransfer;
    NSString *g_tDateDateTransfer;
    NSInteger g_tNumTransfer;
    NSInteger g_tPressLowTransfer;
    NSInteger g_tPressUpTransfer;
    NSInteger g_tPulseBeforeTransfer;
    NSInteger g_tPulseAfterTransfer;

    NSArray *arrayDicFieldMsg;
    NSArray *arrayDicNamesTech;      //тех.название справочника
    NSArray *arrayDicFieldNamesTech;
    
    NSString *g_FIOstr;
    NSString *g_GOALstr;
    NSString *g_RACKETstr;
    NSString *g_SNEAKERSstr;
    
    NSString *g_isIpad;
    
    NSDateFormatter *g_formatter;
    NSDateFormatter *g_formatterDateToStr;
    
}
@end

@implementation ViewController

@synthesize pressUpTextField, pressLowTextField, pulseBeforeTextField, pulseAfterTextField, tennisDayNumLabel, saidOnTheCortTextView, dateSelectionTextField, dateDateSelectionTextField;

@synthesize MyMethodic1ButtonOutlet, MyMethodic2ButtonOutlet, MyMethodic3ButtonOutlet, HelpButtonOutlet, DicButtonGoalOutlet, DicButtonRacketOutlet, DicButtonTrainerOutlet, DicButtonSneakersOutlet, DicButtonMyMethodicsOutlet, BtnNewDayOutlet, BtnSaveDayOutlet, BtnViewTDaysOutlet;

@synthesize goalLabel, pulseLabel, trainerLabel, saidLabel, racketLabel, pressureLabel, sneakersLabel, dateTimeLabel, myMethodicsLabel, methodicsTypeLabel;

@synthesize ScrollView;

//MARK: Views ---------------------------------
- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:NO];
    
    //iPad?
    Params *params = [[Params alloc] init];
    [params getUserInterfaceIdiom];
    g_isIpad = params -> isIPad;
    
    int     l_fontSizeTexts = 20;
    int     l_fontSizeButtons = 20;
    int     l_fontSizeLabels = 22;
    UIFont *l_font     = sneakersLabel.font;
    
    if ([g_isIpad isEqualToString:@"Y"]){
        [sneakersLabel      setFont:[l_font fontWithSize:l_fontSizeLabels]];
        [pressureLabel      setFont:[l_font fontWithSize:l_fontSizeLabels]];
        [racketLabel        setFont:[l_font fontWithSize:l_fontSizeLabels]];
        [saidLabel          setFont:[l_font fontWithSize:l_fontSizeLabels]];
        [trainerLabel       setFont:[l_font fontWithSize:l_fontSizeLabels]];
        [pulseLabel         setFont:[l_font fontWithSize:l_fontSizeLabels]];
        [goalLabel          setFont:[l_font fontWithSize:l_fontSizeLabels]];
        [methodicsTypeLabel setFont:[l_font fontWithSize:l_fontSizeLabels]];
        [myMethodicsLabel   setFont:[l_font fontWithSize:l_fontSizeLabels]];
        [dateTimeLabel      setFont:[l_font fontWithSize:l_fontSizeLabels]];
        [tennisDayNumLabel  setFont:[l_font fontWithSize:l_fontSizeLabels]];
        
        UIFont *l_HELPfont = HelpButtonOutlet.titleLabel.font;
        [HelpButtonOutlet.titleLabel setFont:[l_HELPfont fontWithSize:l_fontSizeButtons]];
        
        UIFont *l_BUTTONSfont = DicButtonGoalOutlet.titleLabel.font;
        [DicButtonGoalOutlet.titleLabel setFont:[l_BUTTONSfont fontWithSize:l_fontSizeButtons]];
        [DicButtonRacketOutlet.titleLabel setFont:[l_BUTTONSfont fontWithSize:l_fontSizeButtons]];
        [DicButtonTrainerOutlet.titleLabel setFont:[l_BUTTONSfont fontWithSize:l_fontSizeButtons]];
        [DicButtonSneakersOutlet.titleLabel setFont:[l_BUTTONSfont fontWithSize:l_fontSizeButtons]];
        [DicButtonMyMethodicsOutlet.titleLabel setFont:[l_BUTTONSfont fontWithSize:l_fontSizeButtons]];
        
        UIFont *l_3ButtonFont = BtnNewDayOutlet.titleLabel.font;
        [BtnNewDayOutlet.titleLabel setFont:[l_3ButtonFont fontWithSize:40]];
        [BtnSaveDayOutlet.titleLabel setFont:[l_3ButtonFont fontWithSize:25]];
        [BtnViewTDaysOutlet.titleLabel setFont:[l_3ButtonFont fontWithSize:25]];
        
        [MyMethodic1ButtonOutlet.titleLabel setFont:[MyMethodic1ButtonOutlet.titleLabel.font fontWithSize:17]];
        [MyMethodic2ButtonOutlet.titleLabel setFont:[MyMethodic2ButtonOutlet.titleLabel.font fontWithSize:17]];
        [MyMethodic3ButtonOutlet.titleLabel setFont:[MyMethodic3ButtonOutlet.titleLabel.font fontWithSize:20]];
        
        UIFont *l_textFont = _fioTextField.font;
        [_fioTextField setFont:[l_textFont fontWithSize:l_fontSizeTexts]];
        [_goalTextField setFont:[l_textFont fontWithSize:l_fontSizeTexts]];
        [pressUpTextField setFont:[l_textFont fontWithSize:l_fontSizeTexts]];
        [pressLowTextField setFont:[l_textFont fontWithSize:l_fontSizeTexts]];
        [pulseAfterTextField setFont:[l_textFont fontWithSize:l_fontSizeTexts]];
        [pulseBeforeTextField setFont:[l_textFont fontWithSize:l_fontSizeTexts]];
        [_racketTextField setFont:[l_textFont fontWithSize:l_fontSizeTexts]];
        [_sneakersTextField setFont:[l_textFont fontWithSize:l_fontSizeTexts]];
        [saidOnTheCortTextView setFont:[l_textFont fontWithSize:l_fontSizeTexts]];
        [dateSelectionTextField setFont:[l_textFont fontWithSize:l_fontSizeTexts]];
    }
}

-(void)viewWillLayoutSubviews{
    [super viewWillLayoutSubviews];
    //прокрутка textview вверх
    [saidOnTheCortTextView setContentOffset:CGPointZero animated:NO];
}

- (void)viewDidLoad { //================================================
    NSLog(@"----------ViewController (viewDidLoad)------------");
    [super viewDidLoad];
    
    g_formatter=[[NSDateFormatter alloc]init];
    [g_formatter setDateFormat:@"dd MMMM YYYY EEEE; HH:mm"];
    g_formatterDateToStr =[[NSDateFormatter alloc]init];
    [g_formatterDateToStr setDateFormat:@"yyyy/MM/dd HH-mm-ss"];
    
    g_modeTennisDayAdd = @"ADD";
    g_modeTennisDayEdit = @"EDIT";
    g_modeTennisDay = g_modeTennisDayEdit; //по умолчанию - редактируем тренировку
    
    //константы, используемые в приложении
    g_FIOstr = @"FIO"; g_GOALstr = @"GOAL"; g_RACKETstr = @"RACKET"; g_SNEAKERSstr = @"SNEAKERS";
    
    /*
     номера кнопок вызова справочника:
     0 тренер
     1 цель
     2 мои методики
     3 ракетка
     4 кроссовки
     */
    g_dicIdFIO      = 0;
    g_dicIdGOAL     = 1;
    g_dicIdRACKET   = 3;
    g_dicIdSNEAKERS = 4;
    
    //инициализация переменных]
    Params *params = [[Params alloc] init];
    [params setArrayDicNamesTech];
    [params setArrayDicFieldMsg]; //сообщения для создания новых статей в словаре
    [params setArrayDicFieldNamesTech];
    
    arrayDicNamesTech  = params -> arrayDicNamesTech;
    arrayDicFieldMsg   = params -> arrayDicFieldMsg;
    arrayDicFieldNamesTech = params -> arrayDicFieldNamesTech;
    
    [params setSettingDicId:-99];
    [params setSettingDicRow:-99];
    [params getSettingsDic];
    
    [self initParams]; //сбрасываем параметры из TennisToday
    
    //загрузить данные из CoreData
    [self loadDicsFromCoreData];
    
    //=================================================================== viewDidLoad
    //set the delegate
    self.pressUpTextField.delegate = self;
    self.pressLowTextField.delegate = self;
    self.pulseBeforeTextField.delegate = self;
    self.pulseAfterTextField.delegate = self;
    self.saidOnTheCortTextView.delegate = self;
    
    //готовим picker-------------------------------------------------------viewDidLoad
    //pickerView
    datePicker=[[UIDatePicker alloc]init];
    datePicker.datePickerMode = UIDatePickerModeDateAndTime;
    
    pickerViewFIO = [[UIPickerView alloc] init];
    pickerViewFIO.delegate = self;
    pickerViewFIO.dataSource = self;
    pickerViewFIO.showsSelectionIndicator = YES;//
    pickerViewFIO.tag = g_dicIdFIO;//
    
    pickerViewGOAL = [[UIPickerView alloc] init];
    pickerViewGOAL.delegate = self;
    pickerViewGOAL.dataSource = self;
    pickerViewGOAL.showsSelectionIndicator = YES;
    pickerViewGOAL.tag = g_dicIdGOAL;
    
    pickerViewRACKET = [[UIPickerView alloc] init];
    pickerViewRACKET.delegate = self;
    pickerViewRACKET.dataSource = self;
    pickerViewRACKET.showsSelectionIndicator = YES;
    pickerViewRACKET.tag = g_dicIdRACKET;
    
    pickerViewSNEAKERS = [[UIPickerView alloc] init];
    pickerViewSNEAKERS.delegate = self;
    pickerViewSNEAKERS.dataSource = self;
    pickerViewSNEAKERS.showsSelectionIndicator = YES;
    pickerViewSNEAKERS.tag = g_dicIdSNEAKERS;

    //======================================viewDidLoad - //создаем ToolBar-s+Pickers
    UIBarButtonItem *flexibleSpaceLeft = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
    UIColor         *backGroundColor   = [UIColor colorWithRed:5.0/255.0 green:110.0/255.0 blue:170.0/255.0 alpha:1];
    UIColor         *tintColor         = [UIColor whiteColor];
    
    //создаем ToolBar с кнопками, на который добавляем и datePicker
    toolbarDate = [[UIToolbar alloc]init];
    [toolbarDate sizeToFit];
    UIBarButtonItem *selectDateBtn =
    [[UIBarButtonItem alloc] initWithTitle:
     NSLocalizedString(@"Choose date-time", @"Choose date-time comment")
     style:UIBarButtonItemStyleDone
     target:self
     action:@selector(ShowSelectedDateViewCont)
     ];
    selectDateBtn.tintColor = tintColor;
    toolbarDate.backgroundColor = backGroundColor;
    [toolbarDate setItems:[NSArray arrayWithObjects:flexibleSpaceLeft, selectDateBtn , nil]];
    [self.dateSelectionTextField setInputAccessoryView:toolbarDate];
    self.dateSelectionTextField.inputView = datePicker;
    [self.dateDateSelectionTextField setInputAccessoryView:toolbarDate];
    self.dateDateSelectionTextField.inputView = datePicker;
    
    toolbarFIO = [[UIToolbar alloc]init];
    [toolbarFIO sizeToFit];
    UIBarButtonItem *selectFIOBtn =
    [
     [UIBarButtonItem alloc]
     initWithTitle: NSLocalizedString(@"Choose coacher", @"Choose coacher comment")
     style:UIBarButtonItemStyleDone target:self
     action:@selector(ShowSelectedTextFIO:)
     ];
    
    selectFIOBtn.tintColor = tintColor;
    UIBarButtonItem *AddFIOBtn =
    [
     [UIBarButtonItem alloc]
     initWithTitle:NSLocalizedString(@"New", @"New comment") //@"Новый"
     style:UIBarButtonItemStyleDone
     target:self action:@selector(NewDicTextFIO)];
    AddFIOBtn.tintColor = tintColor;
    toolbarFIO.backgroundColor = backGroundColor;
    [toolbarFIO setItems:[NSArray arrayWithObjects:flexibleSpaceLeft, selectFIOBtn , AddFIOBtn, nil]];
    [self.fioTextField setInputAccessoryView:toolbarFIO];
    self.fioTextField.inputView = pickerViewFIO;
    
    toolbarGOAL = [[UIToolbar alloc]init];
    [toolbarGOAL sizeToFit];
    UIBarButtonItem *selectGOALBtn =
    [
     [UIBarButtonItem alloc]
     initWithTitle:NSLocalizedString(@"Choose goal", @"Choose goal comment") //@"Выбрать Цель"
     style:UIBarButtonItemStyleDone
     target:self action:@selector(ShowSelectedTextGOAL:)];
    
    selectGOALBtn.tintColor = tintColor;
    UIBarButtonItem *AddGOALBtn =
    [
     [UIBarButtonItem alloc]
     initWithTitle:NSLocalizedString(@"New", @"New comment") //@"Новый"
     style:UIBarButtonItemStyleDone
     target:self action:@selector(NewDicTextGOAL)];
    
    AddGOALBtn.tintColor = tintColor;
    toolbarGOAL.backgroundColor = backGroundColor;
    [toolbarGOAL setItems:[NSArray arrayWithObjects:flexibleSpaceLeft, selectGOALBtn , AddGOALBtn, nil]];
    [self.goalTextField setInputAccessoryView:toolbarGOAL];
    self.goalTextField.inputView = pickerViewGOAL;
    
    toolbarRACKET = [[UIToolbar alloc]init];
    [toolbarRACKET sizeToFit];
    UIBarButtonItem *selectRACKETBtn =
    [
     [UIBarButtonItem alloc]
     initWithTitle:NSLocalizedString(@"Choose protection", @"Choose protection comment") //@"Выбрать Ракетку"
     style:UIBarButtonItemStyleDone
     target:self action:@selector(ShowSelectedTextRACKET:)];
    
    selectRACKETBtn.tintColor = tintColor;
    UIBarButtonItem *AddRACKETBtn =
    [
     [UIBarButtonItem alloc]
     initWithTitle:NSLocalizedString(@"New", @"New comment") //@"Новый"
     style:UIBarButtonItemStyleDone
     target:self
     action:@selector(NewDicTextRACKET)];
    
    AddRACKETBtn.tintColor = tintColor;
    toolbarRACKET.backgroundColor = backGroundColor;
    [toolbarRACKET setItems:[NSArray arrayWithObjects:flexibleSpaceLeft, selectRACKETBtn , AddRACKETBtn, nil]];
    [self.racketTextField setInputAccessoryView:toolbarRACKET];
    self.racketTextField.inputView = pickerViewRACKET;
    
    toolbarSNEAKERS = [[UIToolbar alloc]init];
    [toolbarSNEAKERS sizeToFit];
    UIBarButtonItem *selectSNEAKERSBtn =
    [
     [UIBarButtonItem alloc]
     initWithTitle:NSLocalizedString(@"Choose training gloves", @"Choose training gloves comment") //@"Выбрать Кроссовки"
     style:UIBarButtonItemStyleDone
     target:self
     action:@selector(ShowSelectedTextSNEAKERS:)];
    
    selectSNEAKERSBtn.tintColor = tintColor;
    UIBarButtonItem *AddSNEAKERSBtn =
    [
     [UIBarButtonItem alloc]
     initWithTitle:NSLocalizedString(@"New", @"New comment") //@"Новый"
     style:UIBarButtonItemStyleDone
     target:self
     action:@selector(NewDicTextSNEAKERS)];
    
    AddSNEAKERSBtn.tintColor = tintColor;
    toolbarSNEAKERS.backgroundColor = backGroundColor;
    [toolbarSNEAKERS setItems:[NSArray arrayWithObjects:flexibleSpaceLeft, selectSNEAKERSBtn , AddSNEAKERSBtn, nil]];
    [self.sneakersTextField setInputAccessoryView:toolbarSNEAKERS];
    self.sneakersTextField.inputView = pickerViewSNEAKERS;
    
    //=========================================================================
    //добавляем распознавание жеста tap
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(dismissKeyboard)];
    [self.view addGestureRecognizer:tap];
    
    //загрузка данных из entity TennisToday
    [self loadFromEntityTennisTodayToVar];
    [self fillTennisTodayForm];
}
//-- - (void)viewDidLoad {

//MARK: Buttons ---------------------------------
//создать новую тренировку ===================================================
- (IBAction)BtnNewTennisDay {
    NSLog(@"----------ViewController (BtnNewTennisDay)------------");
    //спрашиваем - действительно ли пользователь хочет создать новую тренировку?
    
    UIAlertController *alert =
    [UIAlertController
     alertControllerWithTitle:NSLocalizedString(@"Create new training?", @"Create new training? comment")  //@"Хотите создать новую тренировку?"
     message:@""
     preferredStyle: UIAlertControllerStyleAlert];
    
    UIAlertAction *actionYes =
    [UIAlertAction
     actionWithTitle:NSLocalizedString(@"Yes", @"Yes comment") //@"Да"
     style:UIAlertActionStyleDefault
     handler:^(UIAlertAction * action )
    {   //создать новую тренировку
        self->g_modeTennisDay = self->g_modeTennisDayAdd;
        self->g_tennisDayNum = self->g_tennisDayNum + 1;
        self.tennisDayNumLabel.text = [[@(self->g_tennisDayNum) stringValue] stringByAppendingString:NSLocalizedString(@" training day", @" training day comment")];
        [self ShowSelectedDateViewCont]; //заполнить поле с датой текущей датой (из дейтпикера, в нужном формате даты)
        self.BtnNewDayOutlet.hidden = TRUE;
    }];
    
    UIAlertAction *actionCancel = [UIAlertAction
                                   actionWithTitle:NSLocalizedString(@"No", @"No comment")//@"Нет"
                                   style:UIAlertActionStyleCancel
                                   handler:^(UIAlertAction * action) {}];
    [alert addAction:actionYes];
    [alert addAction:actionCancel];
    [self presentViewController:alert animated:YES completion:nil];
}//-- (IBAction)BtnNewTennisDay {

//сохранить тренировку ===================================================
- (IBAction)BtnSaveTennisDay {
    NSLog(@"----------ViewController (BtnSaveTennisDay)------------");
    //спрашиваем - действительно ли пользователь хочет сохранить новую тренировку?
    
    UIAlertController *alert = [UIAlertController
                                alertControllerWithTitle: NSLocalizedString(@"Do you really want to keep the training?", @"Do you really want to keep the training? comment")
                                message:@""
                                preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *actionYes = [UIAlertAction
                                actionWithTitle:NSLocalizedString(@"Yes", @"Yes comment")
                                style:UIAlertActionStyleDefault
                                handler:^(UIAlertAction * action)
    {   //сохранить данные о тренировке
        [self saveData];
        self.BtnNewDayOutlet.hidden = FALSE;
    }];
    UIAlertAction *actionNo = [UIAlertAction
                               actionWithTitle:NSLocalizedString(@"No", @"No comment")
                               style:UIAlertActionStyleCancel
                               handler:^(UIAlertAction * action) {}];
    [alert addAction:actionYes];
    [alert addAction:actionNo];
    [self presentViewController:alert animated:YES completion:nil];
    
}//--- (IBAction)BtnSaveTennisDay {

//список тренировок ===================================================
- (IBAction)BtnListTennisDay {
    NSLog(@"----------ViewController (BtnListTennisDay)------------");
    
    //инициализация переменных]
    Params *params = [[Params alloc] init];
    [params setSettingTennisRow:(-1)];
}


//--обработка TextField

//MARK: ShowSelected ---------------------------------

//обработка datepicker =================================================================
//используется для datePicker-а
- (void)ShowSelectedDateViewCont{
    NSLog(@"----------ViewController (ShowSelectedDateViewCont)------------");
    
    self.dateSelectionTextField.text = [NSString stringWithFormat:@"%@",[g_formatter stringFromDate:datePicker.date]];
    self.dateDateSelectionTextField.text = [NSString stringWithFormat:@"%@",[g_formatterDateToStr stringFromDate:datePicker.date]];
    
    [self.dateSelectionTextField resignFirstResponder];//убрать клавиатуру
}

//используется для pickerView
- (void)ShowSelectedTextFIO:(id)sender{
    NSLog(@"----------ViewController (ShowSelectedTextFIO)------------");
    self.fioTextField.text = g_selectedString; [self ShowSelectedText:g_FIOstr];
}
- (void)ShowSelectedTextGOAL:(id)sender{
    NSLog(@"----------ViewController (ShowSelectedTextGOAL)------------");
    self.goalTextField.text = g_selectedString; [self ShowSelectedText:g_GOALstr];
}
- (void)ShowSelectedTextRACKET:(id)sender{
    NSLog(@"----------ViewController (ShowSelectedTextRACKET)------------");
    self.racketTextField.text = g_selectedString; [self ShowSelectedText:g_RACKETstr];
}
- (void)ShowSelectedTextSNEAKERS:(id)sender{
    NSLog(@"----------ViewController (ShowSelectedTextSNEAKERS)------------");
    self.sneakersTextField.text = g_selectedString; [self ShowSelectedText:g_SNEAKERSstr];
}
//-----------
- (void)ShowSelectedText:(NSString*) thema {
    [self leftStringFieldsDismissKeyboard]; //скрыть клавиатуру
}

//MARK: NewDicText ---------------------------------
- (void)NewDicTextFIO      { [self NewDicText: g_FIOstr]; } //вызов для ФИО - FIO
- (void)NewDicTextGOAL     { [self NewDicText: g_GOALstr]; } //вызов для Цели - Goal
- (void)NewDicTextRACKET   { [self NewDicText: g_RACKETstr]; }
- (void)NewDicTextSNEAKERS { [self NewDicText: g_SNEAKERSstr]; }

//ДОБАВЛЯЕМ НОВУЮ СЛОВАРНУЮ СТАТЬЮ В ТАБЛИЦУ ---------------
- (void) NewDicText: (NSString*) thema {
    NSLog(@"----------ViewController (NewDicText)------------");
    //скрываем клавиатуру
    [self leftStringFieldsDismissKeyboard];
    
    //Alert Controller с кнопками и полем для ввода данных в справочник (ДОБАВИТЬ ДАННЫЕ В СПРАВОЧНИК)
    UIAlertController* alert =
    [
       UIAlertController alertControllerWithTitle: NSLocalizedString(@"Set a new value", @"Set a new value comment")
       message:@""
       preferredStyle:UIAlertControllerStyleAlert //стиль кнопок - только для этого стиля можно добавить текстовое поле в Alert
    ];
    
    //добавить текстовое поле в справочник из alert
    [alert addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
        int k = 0;
        if ([thema  isEqual: self->g_FIOstr])      { k = self->g_dicIdFIO; }
        if ([thema  isEqual: self->g_GOALstr])     { k = self->g_dicIdGOAL; }
        if ([thema  isEqual: self->g_RACKETstr])   { k = self->g_dicIdRACKET; }
        if ([thema  isEqual: self->g_SNEAKERSstr]) { k = self->g_dicIdSNEAKERS; }
        
        textField.placeholder = self->arrayDicFieldMsg[k][0];
    }];
    
    //добавить доп.текстовое поле для справочников Ракетка/Кроссовки
    if ([thema  isEqual: g_RACKETstr] || [thema  isEqual: g_SNEAKERSstr]) {
        [alert addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
            int k = 0;
            if ([thema  isEqual: self->g_RACKETstr])   { k = self->g_dicIdRACKET; }
            if ([thema  isEqual: self->g_SNEAKERSstr]) { k = self->g_dicIdSNEAKERS; }
            textField.placeholder = self->arrayDicFieldMsg[k][1];
        }];
    }
    
    UIAlertAction* actionAdd = [UIAlertAction
      actionWithTitle: NSLocalizedString(@"Add", @"Add comment")
      style:UIAlertActionStyleDefault
      handler:^(UIAlertAction * action)
    {
        //добавить новую статью в справочник
        
        //Get Context
        self->appDelegate = (AppDelegate *)[[UIApplication sharedApplication]delegate];
        self->context = self->appDelegate.persistentContainer.viewContext;
        
        //значение из текстового поля алерта
        NSString *newVal = alert.textFields[0].text;
        NSString *newValDop = @"";
        if ([thema  isEqual: self->g_RACKETstr] || [thema  isEqual: self->g_SNEAKERSstr]) {
            newValDop = alert.textFields[1].text;
        }
        
        int k = -1;
        if ([thema  isEqual: self->g_FIOstr])      { k = self->g_dicIdFIO; }
        if ([thema  isEqual: self->g_GOALstr])     { k = self->g_dicIdGOAL; }
        if ([thema  isEqual: self->g_RACKETstr])   { k = self->g_dicIdRACKET; }
        if ([thema  isEqual: self->g_SNEAKERSstr]) { k = self->g_dicIdSNEAKERS; }
        
        if (k > -1) {
            //Save Data
            NSManagedObject *entityObj = [NSEntityDescription insertNewObjectForEntityForName: self->arrayDicNamesTech[k] inManagedObjectContext:self->context];
            [entityObj setValue: newVal forKey:self->arrayDicFieldNamesTech[k][0]]; //добавила в справочник значение из Alert
            
            if ([thema  isEqual: self->g_FIOstr]) {
                [self->g_dictFIO addObject:(newVal)];
                self->g_numFIO = self->g_numFIO+1;
                self.fioTextField.text = newVal;
            }
        
            if ([thema  isEqual: self->g_GOALstr]) {
                [self->g_dictGOAL addObject:(newVal)];
                self->g_numGOAL = self->g_numGOAL+1;
                self.goalTextField.text = newVal;
            }
            
            if ([thema  isEqual: self->g_RACKETstr] || [thema  isEqual: self->g_SNEAKERSstr]) {
                [entityObj setValue: newValDop forKey:self->arrayDicFieldNamesTech[k][1]];
                
                //добавить в массив новый элемент
                NSString *str = @"";
                str = [newVal stringByAppendingString:@" / "];
                str = [str stringByAppendingString: newValDop];
                
                if ([thema  isEqual: self->g_RACKETstr]){
                    [self->g_dictRACKET addObject:(str)];
                    self->g_numRACKET = self->g_numRACKET+1;
                    self.racketTextField.text = str;
                }
                
                if ([thema  isEqual: self->g_SNEAKERSstr]){
                    [self->g_dictSNEAKERS addObject:(str)];
                    self->g_numSNEAKERS = self->g_numSNEAKERS+1;
                    self.sneakersTextField.text = str;
                }
            }
            
            [self sortedDicArrays];
            
            //save data
            [self->appDelegate saveContext];
        }
        
        
    }];

    UIAlertAction* actionCancel = [UIAlertAction
                                   actionWithTitle: NSLocalizedString(@"Cancel", @"Cancel comment")
                                   style:UIAlertActionStyleCancel
                                   handler:^(UIAlertAction * action) {}];
    
    [alert addAction:actionAdd];
    [alert addAction:actionCancel];
    
    [self presentViewController:alert animated:YES completion:nil];
}


//MARK: UIPickerView ---------------------------------
- (NSInteger)numberOfComponentsInPickerView:(nonnull UIPickerView *)pickerView {
    return 1;
}

- (NSInteger)pickerView:(nonnull UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component {
    NSLog(@"----------ViewController (pickerView numberOfRowsInComponent)------------");
    
    int num = 0;
    g_selectedString = @"";
    
    if (pickerView.tag == g_dicIdFIO)      {   num = g_numFIO; if (g_dictFIO.count > 0) {g_selectedString = g_dictFIO[0];} }
    if (pickerView.tag == g_dicIdGOAL)     {   num = g_numGOAL; if (g_dictGOAL.count > 0) {g_selectedString = g_dictGOAL[0];} }
    if (pickerView.tag == g_dicIdRACKET)   {   num = g_numRACKET; if (g_dictRACKET.count > 0) {g_selectedString = g_dictRACKET[0];} }
    if (pickerView.tag == g_dicIdSNEAKERS) {   num = g_numSNEAKERS; if (g_dictSNEAKERS.count > 0) {g_selectedString = g_dictSNEAKERS[0];} }
    
    if ([g_selectedString isEqualToString:@""]) {   g_selectedString = @"..."; }
    
    return num;
}

- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component {
    NSLog(@"----------ViewController (pickerView titleForRow)------------");
    
    if (pickerView.tag == g_dicIdFIO)     { g_selectedString = g_dictFIO_sorted[row];      }
    if (pickerView.tag == g_dicIdGOAL)    { g_selectedString = g_dictGOAL_sorted[row];     }
    if (pickerView.tag == g_dicIdRACKET)  { g_selectedString = g_dictRACKET_sorted[row];   }
    if (pickerView.tag == g_dicIdSNEAKERS){ g_selectedString = g_dictSNEAKERS_sorted[row]; }
    
    return g_selectedString;
}

- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component {
    NSLog(@"----------ViewController (pickerView didSelectRow)------------");
    
    if (pickerView.tag == g_dicIdFIO)      {g_selectedString = g_dictFIO_sorted[row];     }
    if (pickerView.tag == g_dicIdGOAL)     {g_selectedString = g_dictGOAL_sorted[row];    }
    if (pickerView.tag == g_dicIdRACKET)   {g_selectedString = g_dictRACKET_sorted[row];  }
    if (pickerView.tag == g_dicIdSNEAKERS) {g_selectedString = g_dictSNEAKERS_sorted[row];}
    if ([g_selectedString isEqualToString:@""]) {g_selectedString = @"...";}
}

//--MARK: OTHERS -----------------
//  Hide the keyboard (покидая редактируемый textField)
-(void)dismissKeyboard {
    NSLog(@"----------ViewController (dismissKeyboard)------------");
    [self.dateSelectionTextField resignFirstResponder];
    [self leftNumberFieldsDismissKeyboard];
    [self leftStringFieldsDismissKeyboard];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

//Мои методы ============================================================***********************
//покидая поле number, скрываем клавиатуру
-(void)leftNumberFieldsDismissKeyboard {
    NSLog(@"----------ViewController (leftNumberFieldsDismissKeyboard)------------");
    [self.pressUpTextField resignFirstResponder];
    [self.pressLowTextField resignFirstResponder];
    [self.pulseBeforeTextField resignFirstResponder];
    [self.pulseAfterTextField resignFirstResponder];
}

//покидая поле String, скрываем клавиатуру
-(void)leftStringFieldsDismissKeyboard {
    NSLog(@"----------ViewController (leftStringFieldsDismissKeyboard)------------");
    [self.fioTextField resignFirstResponder];
    [self.goalTextField resignFirstResponder];
    [self.saidOnTheCortTextView resignFirstResponder];
    [self.racketTextField resignFirstResponder];
    [self.sneakersTextField resignFirstResponder];
}

/*+ Mark: CoreData*/
-(void)loadDicsFromCoreData {
    NSLog(@"----------ViewController (loadFromCoreData)------------");
    /*---- Mark: Core Data -------*/
    
    //загрузка справочника FIO в массив
    //Get Context
    appDelegate = (AppDelegate *)[[UIApplication sharedApplication]delegate];
    context = appDelegate.persistentContainer.viewContext;
    
    //Fetch (Load) Data ********************************
    NSFetchRequest *requestExamLocationFIO = [NSFetchRequest fetchRequestWithEntityName:@"DicTrainer"];
    // here's where you specify the sort
    NSArray *resultsFIO = [context executeFetchRequest:requestExamLocationFIO error:nil];
    g_numFIO = (int)resultsFIO.count;
    
    [g_dictFIO removeAllObjects];
    g_dictFIO = [[NSMutableArray alloc]initWithCapacity:1];
    for (int i=0; i<resultsFIO.count; i++) { [g_dictFIO addObject:[[resultsFIO objectAtIndex:i] valueForKey:@"fio"]]; }
    
    //загрузка справочника GOAL в массив
    //Fetch (Load) Data ********************************
    NSFetchRequest *requestExamLocationGOAL = [NSFetchRequest fetchRequestWithEntityName:@"Goals"];
    NSArray *resultsGOAL = [context executeFetchRequest:requestExamLocationGOAL error:nil];
    g_numGOAL = (int)resultsGOAL.count;
    [g_dictGOAL removeAllObjects];
    g_dictGOAL = [[NSMutableArray alloc]initWithCapacity:1];
    for (int i=0; i<resultsGOAL.count; i++) { [g_dictGOAL addObject:[[resultsGOAL objectAtIndex:i] valueForKey:@"descr"]]; }
    
    //загрузка справочника RACKET в массив
    //Fetch (Load) Data ********************************
    NSFetchRequest *requestExamLocationRACKET = [NSFetchRequest fetchRequestWithEntityName:@"DicProtect"];
    NSArray *resultsRACKET = [context executeFetchRequest:requestExamLocationRACKET error:nil];
    g_numRACKET = (int)resultsRACKET.count;
    [g_dictRACKET removeAllObjects];
    g_dictRACKET = [[NSMutableArray alloc]initWithCapacity:1];
    for (int i=0; i<resultsRACKET.count; i++) {
        NSString *str = [[resultsRACKET objectAtIndex:i] valueForKey:@"size"];
        if ([str isEqualToString:@""]) {str = @"-";}
        str = [str stringByAppendingString:@" / "];
        str = [str stringByAppendingString: [[resultsRACKET objectAtIndex:i] valueForKey:@"descr"]];
        [g_dictRACKET addObject: str];
    }
    
    //загрузка справочника SNEAKERS в массив
    //Fetch (Load) Data ********************************
    NSFetchRequest *requestExamLocationSNEAKERS = [NSFetchRequest fetchRequestWithEntityName:@"DicGloves"];
    NSArray *resultsSNEAKERS = [context executeFetchRequest:requestExamLocationSNEAKERS error:nil];
    g_numSNEAKERS = (int)resultsSNEAKERS.count;
    [g_dictSNEAKERS removeAllObjects];
    g_dictSNEAKERS = [[NSMutableArray alloc]initWithCapacity:1];
    for (int i=0; i<resultsSNEAKERS.count; i++) {
        NSString *str = [[resultsSNEAKERS objectAtIndex:i] valueForKey:@"size"];
        if ([str isEqualToString:@""]) {str = @"-";}
        str = [str stringByAppendingString:@" / "];
        str = [str stringByAppendingString: [[resultsSNEAKERS objectAtIndex:i] valueForKey:@"descr"]];
        [g_dictSNEAKERS addObject: str];
    }
    
    //сортируем массивы по алфавиту
    [self sortedDicArrays];
    
    //загрузка справочника MyMethodics в массив
    //Fetch (Load) Data ********************************
    NSFetchRequest *requestExamLocationMyMethodics = [NSFetchRequest fetchRequestWithEntityName:@"MyMethodics"];
    NSArray *resultsMyMethodics = [context executeFetchRequest:requestExamLocationMyMethodics error:nil];
    
    [g_dictMethodicsName   removeAllObjects];
    [g_dictMethodicsRowNum removeAllObjects];
    g_dictMethodicsName   = [[NSMutableArray alloc]initWithCapacity:1];//name
    g_dictMethodicsRowNum = [[NSMutableArray alloc]initWithCapacity:1];//rowNum
    
    for (int x =0; x<3; x++) {
        [g_dictMethodicsName   addObject:@""];
        [g_dictMethodicsRowNum addObject:@(-1)];
    }
    
    int k = 0;
    for (int i=0; i<resultsMyMethodics.count; i++) {
        NSString *str = [[resultsMyMethodics objectAtIndex:i] valueForKey:@"isBase"];
        if ([str isEqualToString:@"Y"]) {
            g_dictMethodicsName[k]   = [[resultsMyMethodics objectAtIndex:i] valueForKey:@"name"];
            g_dictMethodicsRowNum[k] = @(i);
            k = k + 1;
        }
        if (k == 3) {break;}
    }
    
}//============================loadFromCoreData

-(void)saveData {
    NSLog(@"----------ViewController (saveData)------------");
    //Get Context
    appDelegate = (AppDelegate *)[[UIApplication sharedApplication]delegate];
    context = appDelegate.persistentContainer.viewContext;
    
    //если сохраняем в режиме Add - то запись из TennisToday копируем в TrainHistory, после чего - переключаемся в режим Edit
    //NSFetchRequest
    //проверяем - есть ли данные в Entity?
    NSFetchRequest *requestExamLocationTennisToday = [NSFetchRequest fetchRequestWithEntityName:@"TrainToday"];
    NSArray *resultsTennisToday = [context executeFetchRequest:requestExamLocationTennisToday error:nil];

    NSManagedObject *entityObjTennisToday = nil;
    //если данных нет, в TennisDay заливаем 1 строку данных
    if ([resultsTennisToday count] == 0) {
        g_modeTennisDay = g_modeTennisDayEdit;
        entityObjTennisToday = [NSEntityDescription insertNewObjectForEntityForName:@"TrainToday" inManagedObjectContext:context];
    }
    //сохраним данные, если в таблице уже есть информация
    else {
        if ([resultsTennisToday count] > 0) {
            entityObjTennisToday = [resultsTennisToday objectAtIndex:0];
        }
    }

    if ([g_modeTennisDay isEqualToString:g_modeTennisDayAdd] ) {[self loadFromEntityTennisTodayToVar];}

    //записываем в текущую тренировку отредактированные данные
    [entityObjTennisToday setValue: self.fioTextField.text                       forKey: @"fioStr"];
    [entityObjTennisToday setValue: self.goalTextField.text                      forKey: @"goalStr"];
    [entityObjTennisToday setValue: self.saidOnTheCortTextView.text              forKey: @"saidStr"];
    [entityObjTennisToday setValue: self.dateSelectionTextField.text             forKey: @"tDateString"];
    
    NSString *str = self.dateDateSelectionTextField.text;
    NSDate   *ldate = [g_formatterDateToStr dateFromString:str];
    [entityObjTennisToday setValue: ldate                                         forKey: @"tDateDate"];
    
    NSLog(@"--1");
    NSLog(@"%@", str);
    NSLog(@"%@", ldate);
    NSLog(@"%@", self.dateSelectionTextField.text);
    NSLog(@"%@", self.dateDateSelectionTextField.text);
    
    [entityObjTennisToday setValue: self.racketTextField.text                    forKey: @"protectStr"];
    [entityObjTennisToday setValue: self.sneakersTextField.text                  forKey: @"glovesStr"];
    if (g_tennisDayNum == 0) {g_tennisDayNum = 1;}
    [entityObjTennisToday setValue: @(g_tennisDayNum)                            forKey: @"tNum"];
    [entityObjTennisToday setValue: @([self.pressUpTextField.text intValue])     forKey: @"tPressUp"];
    [entityObjTennisToday setValue: @([self.pressLowTextField.text intValue])    forKey: @"tPressLow"];
    [entityObjTennisToday setValue: @([self.pulseBeforeTextField.text intValue]) forKey: @"tPulseBefore"];
    [entityObjTennisToday setValue: @([self.pulseAfterTextField.text intValue])  forKey: @"tPulseAfter"];

    [appDelegate saveContext];
    
    //сбрасываем данные о предыдущей тренировке в TennisHistory
    if ([g_modeTennisDay isEqualToString:g_modeTennisDayAdd] ) {
        
        appDelegate = (AppDelegate *)[[UIApplication sharedApplication]delegate];
        context = appDelegate.persistentContainer.viewContext;
        
        NSManagedObject *entityObjTennisHistory = [NSEntityDescription insertNewObjectForEntityForName:@"TrainHistory" inManagedObjectContext:context];
        
        [entityObjTennisHistory setValue:g_fioStrTransfer          forKey:@"fioStr"];
        [entityObjTennisHistory setValue:g_goalStrTransfer         forKey:@"goalStr"];
        [entityObjTennisHistory setValue:g_saidStrTransfer         forKey:@"saidStr"];
        [entityObjTennisHistory setValue:g_tRacketStrTransfer      forKey:@"protectStr"];
        [entityObjTennisHistory setValue:g_tSneakersStrTransfer    forKey:@"glovesStr"];
        [entityObjTennisHistory setValue:g_tDateStringTransfer     forKey:@"tDateString"];
        
        NSDate *date = [g_formatterDateToStr dateFromString:g_tDateDateTransfer];
        [entityObjTennisHistory setValue:date                      forKey:@"tDateDate"];

        NSLog(@"--2");
        NSLog(@"%@", date);
        
        [entityObjTennisHistory setValue:@(g_tNumTransfer)         forKey:@"tNum"];
        [entityObjTennisHistory setValue:@(g_tPressUpTransfer)     forKey:@"tPressUp"];
        [entityObjTennisHistory setValue:@(g_tPressLowTransfer)    forKey:@"tPressLow"];
        [entityObjTennisHistory setValue:@(g_tPulseBeforeTransfer) forKey:@"tPulseBefore"];
        [entityObjTennisHistory setValue:@(g_tPulseAfterTransfer)  forKey:@"tPulseAfter"];
        
        [appDelegate saveContext];
        g_modeTennisDay = g_modeTennisDayEdit;
    }
}//============================saveData


/*+//CoreData*/

- (void) initParams {
    g_fioStrTransfer       = @"...";
    g_goalStrTransfer      = @"...";
    g_saidStrTransfer      = @"...";
    g_tRacketStrTransfer   = @"...";
    g_tSneakersStrTransfer = @"...";
    g_tDateStringTransfer  = [NSString stringWithFormat:@"%@",[g_formatter stringFromDate:[NSDate date]]];
    g_tDateDateTransfer    = [NSString stringWithFormat:@"%@",[g_formatterDateToStr stringFromDate:[NSDate date]]];
    
    NSLog(@"0= --------");
    NSLog(@"%@", g_tDateStringTransfer);
    NSLog(@"%@", g_tDateDateTransfer);
    
    g_tNumTransfer         = 0;
    g_tPressLowTransfer    = 0;
    g_tPressUpTransfer     = 0;
    g_tPulseBeforeTransfer = 0;
    g_tPulseAfterTransfer  = 0;
}

/*загрузить данные из entity TennisToday в переменные*/
- (void) loadFromEntityTennisTodayToVar {
    NSLog(@"----------ViewController (loadFromEntityTennisTodayToVar)------------");
    //[self initParams];
    
    appDelegate = (AppDelegate *)[[UIApplication sharedApplication]delegate];
    context = appDelegate.persistentContainer.viewContext;
    
    NSFetchRequest *requestExamLocationTennisToday = [NSFetchRequest fetchRequestWithEntityName:@"TrainToday"];
    NSArray *resultsTennisToday = [context executeFetchRequest:requestExamLocationTennisToday error:nil];
    
    if ([resultsTennisToday count] > 0) {
        //если есть данные, загружаем их в переменные
        g_fioStrTransfer       = [ [resultsTennisToday objectAtIndex:0] valueForKey:@"fioStr"];
        g_goalStrTransfer      = [ [resultsTennisToday objectAtIndex:0] valueForKey:@"goalStr"];
        g_saidStrTransfer      = [ [resultsTennisToday objectAtIndex:0] valueForKey:@"saidStr"];
        g_tRacketStrTransfer   = [ [resultsTennisToday objectAtIndex:0] valueForKey:@"protectStr"];
        g_tSneakersStrTransfer = [ [resultsTennisToday objectAtIndex:0] valueForKey:@"glovesStr"];
        g_tDateStringTransfer  = [ [resultsTennisToday objectAtIndex:0] valueForKey:@"tDateString"];
        g_tDateDateTransfer    = [g_formatterDateToStr stringFromDate:[ [resultsTennisToday objectAtIndex:0] valueForKey:@"tDateDate"]];

        g_tNumTransfer         = [[[resultsTennisToday objectAtIndex:0] valueForKey:@"tNum"] integerValue];
        g_tPressUpTransfer     = [[[resultsTennisToday objectAtIndex:0] valueForKey:@"tPressUp"] integerValue];
        g_tPressLowTransfer    = [[[resultsTennisToday objectAtIndex:0] valueForKey:@"tPressLow"] integerValue] ;
        g_tPulseBeforeTransfer = [[[resultsTennisToday objectAtIndex:0] valueForKey:@"tPulseBefore"] integerValue] ;
        g_tPulseAfterTransfer  = [[[resultsTennisToday objectAtIndex:0] valueForKey:@"tPulseAfter"] integerValue] ;
    }
}//--loadFromTennisToday

/*загрузить данные из переменных в форму*/
- (void) fillTennisTodayForm {
    NSLog(@"----------ViewController (fillTennisTodayForm)------------");
    self.fioTextField.text           = g_fioStrTransfer;
    self.goalTextField.text          = g_goalStrTransfer;
    self.saidOnTheCortTextView.text  = g_saidStrTransfer;
    self.racketTextField.text        = g_tRacketStrTransfer;
    self.sneakersTextField.text      = g_tSneakersStrTransfer;
    
    self.dateSelectionTextField.text     = g_tDateStringTransfer;
    self.dateDateSelectionTextField.text = g_tDateDateTransfer;
    
    g_tennisDayNum                   = g_tNumTransfer;
    if (g_tNumTransfer == 0) {g_tNumTransfer = 1;}
    self.tennisDayNumLabel.text      = [[@(g_tNumTransfer) stringValue] stringByAppendingString:NSLocalizedString(@" training day", @" training day comment")];
    self.pressUpTextField.text       = [@(g_tPressUpTransfer)  stringValue];
    self.pressLowTextField.text      = [@(g_tPressLowTransfer) stringValue];
    self.pulseBeforeTextField.text   = [@(g_tPulseBeforeTransfer) stringValue];
    self.pulseAfterTextField.text    = [@(g_tPulseAfterTransfer)  stringValue];
    
    if ([g_dictMethodicsRowNum[0] isEqual:@(-1)] == FALSE) {
        [self.MyMethodic1ButtonOutlet setTitle:g_dictMethodicsName[0] forState: normal];
        [self.MyMethodic1ButtonOutlet setHidden: FALSE];
    }
    if ([g_dictMethodicsRowNum[1] isEqual:@(-1)] == FALSE) {
        [self.MyMethodic2ButtonOutlet setTitle:g_dictMethodicsName[1] forState: normal];
        [self.MyMethodic2ButtonOutlet setHidden: FALSE];
    }
    if ([g_dictMethodicsRowNum[2] isEqual:@(-1)] == FALSE) {
        [self.MyMethodic3ButtonOutlet setTitle:g_dictMethodicsName[2] forState: normal];
        [self.MyMethodic3ButtonOutlet setHidden: FALSE];
    }
    
}//--fillTennisTodayForm

/*отсортировать массивы*/
-(void) sortedDicArrays {
    NSLog(@"----------ViewController (sortedArrays)------------");
    g_dictFIO_sorted      = [g_dictFIO      sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
    g_dictGOAL_sorted     = [g_dictGOAL     sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
    g_dictRACKET_sorted   = [g_dictRACKET   sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
    g_dictSNEAKERS_sorted = [g_dictSNEAKERS sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
}

/*переход к другому экрану*/
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    NSLog(@"----------ViewController (prepareForSegue)------------");
    if ([segue.identifier isEqualToString:@"showDicListVC"]) {
        //узнаем, кнопка на какой строке была нажата?
        UIButton *clicked = (UIButton *) sender;
        NSInteger l_selectedButton = (int)clicked.tag;
        
        //нужно передать номер строки для словарей - Методик
        NSInteger l_rowNum = 0;
        //3 мои методики
        if (l_selectedButton == 21 || l_selectedButton == 22 || l_selectedButton == 23)
        {   if (l_selectedButton == 21) {l_rowNum = [g_dictMethodicsRowNum[0] intValue];}
            if (l_selectedButton == 22) {l_rowNum = [g_dictMethodicsRowNum[1] intValue];}
            if (l_selectedButton == 23) {l_rowNum = [g_dictMethodicsRowNum[2] intValue];}
            l_selectedButton = 2;
        }
        
        //непосредственно, передача параметров
        DicListVC *dicViewController = segue.destinationViewController;
        dicViewController.selectedRow = l_rowNum;
        dicViewController.selectedButton = l_selectedButton;
    }
}
//  Hide the keyboard
-(BOOL)textFieldShouldReturn:(UITextField *)textField {
    NSLog(@"----------ViewController (textFieldShouldReturn)------------");
    [self leftNumberFieldsDismissKeyboard]; //вызов метода - актуален только для полей без picker-a
    return true;
}

//--MARK: FOR SCROLL -----------------
//создано для редактирования поля "Сказано на корте"
-(void)textViewDidBeginEditing:(UITextView *)textView{
    NSLog(@"----------textViewDidBeginEditing------------");
    //перемещаем скролл (чтобы клавиатура не перекрывала редактируемое поле)
    if (textView == self.saidOnTheCortTextView) {
        [self.ScrollView setContentOffset:CGPointMake(0, 50)];
    }
}

-(void)textViewDidEndEditing:(UITextView *)textView{
    NSLog(@"----------textViewDidEndEditing------------");
    if (textView == self.saidOnTheCortTextView) {
        [self.ScrollView setContentOffset:CGPointMake(0, 0)];
    }
}

@end
