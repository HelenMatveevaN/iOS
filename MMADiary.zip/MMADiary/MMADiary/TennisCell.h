//
//  TennisCell.h
//  TennisTraner2
//
//  Created by Helen Matveeva on 04.04.18.
//  Copyright © 2018 Helen Matveeva. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TennisCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *TDateLabel;
@property (weak, nonatomic) IBOutlet UILabel *TFioLabel;
@property (weak, nonatomic) IBOutlet UILabel *tNumLabel;
@property (weak, nonatomic) IBOutlet UILabel *tPressLabel;
@property (weak, nonatomic) IBOutlet UILabel *tPulseLabel;
@property (weak, nonatomic) IBOutlet UILabel *tGoalLabel;
@property (weak, nonatomic) IBOutlet UILabel *tSaidLabel;
@property (weak, nonatomic) IBOutlet UILabel *tRacketLabel;
@property (weak, nonatomic) IBOutlet UILabel *tSneakersLabel;
@property (weak, nonatomic) IBOutlet UIButton *tEditButton;

@end
