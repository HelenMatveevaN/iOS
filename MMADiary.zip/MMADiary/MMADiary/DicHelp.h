//
//  DicHelp.h
//  TennisTraner2
//
//  Created by Helen Matveeva on 09.07.18.
//  Copyright © 2018 Helen Matveeva. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DicHelp : UIViewController {
}
@property (weak, nonatomic) IBOutlet UITextView *dicHelpTextView;
@property (weak, nonatomic) IBOutlet UIButton *BtnBackOutlet;
@property (weak, nonatomic) IBOutlet UILabel *LabelTitleOutlet;



@end
